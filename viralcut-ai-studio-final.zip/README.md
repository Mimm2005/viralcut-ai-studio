# ViralCut AI Studio

**Find. Create. Optimize. Publish. Grow.**

A personal, cloud-based creator studio: import a video you have the rights to → analyse it → rank viral-potential moments with an explainable 0–100 score → render vertical Shorts → generate platform metadata with the AI provider *you* configure → approve → schedule → publish through official APIs → track real analytics.

> **Honest status.** All modules are implemented and covered by automated tests (see `docs/TESTING_REPORT.md`), but **live platform integrations (YouTube, Instagram, Facebook, TikTok, X), the Docker image, real Whisper transcription and a real Cloudflare deployment have NOT been verified end to end** in the environment where this was built (no credentials, no Docker, no outbound access to those services). They are verified against mocks only. Treat the first real run as integration testing. Read `docs/TESTING_REPORT.md` and `PROJECT_STATUS.md` first.

## What is inside

| Folder | What | Tech |
|---|---|---|
| `frontend/` | Single-page UI (10 sections, light/dark, responsive) | Vanilla JS, no build step |
| `worker/` | REST API, auth, D1 access, AI gateway, social adapters, durable scheduler. Storage: any S3-compatible bucket (or R2) | Cloudflare Worker (JS) |
| `engine/` | Video processing: FFmpeg, Faster-Whisper, OpenCV, PySceneDetect, scoring, rendering | Python / FastAPI / Docker |
| `migrations/` | D1 schema (25 tables: the 22 required + 3 support) | SQL |
| `docs/` | Setup, architecture, integrations, limits, test report | Markdown |
| `scripts/` | secrets, tests, deploy, packaging, secret scan, doc generation | Bash / Node |

## Quick start (local, no cloud)

```bash
# 1. engine
cd engine && python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements-dev.txt && ENGINE_TOKEN=dev python -m pytest tests -q
# 2. worker + frontend tests
cd ../worker && node --experimental-sqlite --no-warnings --test
cd ../frontend && npm install && node --test test/frontend.test.js
# or everything at once:
./scripts/run-tests.sh
```

Requirements: Python 3.11+, FFmpeg + ffprobe on PATH, Node 22+. Full setup: `docs/INSTALLATION.md`. Cloud deployment: `docs/DEPLOYMENT.md`.

## Design principles (enforced in code and tests)

- **No fake success.** Publishing is `published` only after the platform confirms the post; analytics are `null` ("n/a") when an API does not provide a metric; integrations without credentials show **pending configuration**, never "connected".
- **Honest media states.** *submitted → validated → authorized → imported* are different states; a URL is never treated as a downloadable stream.
- **Scores come from measurable signals** (audio energy, laughter-like bursts, speech cues, motion, scene cuts, boundaries). An LLM may be used to write text, never to invent a score.
- **Review before publishing.** You approve a frozen snapshot; after approval it publishes automatically at the scheduled time, server-side, surviving restarts and worker sleep.
- **Zero-budget by design.** No paid service is required or enabled automatically; Cost Guard blocks paid fallback and enforces limits *before* calling a provider.
- **Secrets stay server-side.** AES-256-GCM at rest, never returned by the API, redacted from logs.

Not production-ready until you have run the live integration checks in `docs/TESTING_REPORT.md` (section "Live verification checklist").
