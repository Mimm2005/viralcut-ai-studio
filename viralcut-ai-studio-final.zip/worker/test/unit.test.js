import test from 'node:test';
import assert from 'node:assert/strict';
import { hashPassword, verifyPassword, encryptSecret, decryptSecret, redact, timingSafeEqual } from '../src/lib/crypto.js';
import { presign } from '../src/lib/r2sign.js';
import { validate } from '../src/lib/validate.js';
import { Router } from '../src/lib/router.js';
import { localToUtc, nextSlots, utcToLocalParts, isValidTimezone } from '../src/lib/time.js';
import { normalizeMetadata, templateMetadata, SPECS, buildPrompt } from '../src/lib/metadata.js';
import { computeInsights, pearson } from '../src/lib/feedback.js';
import { extractJson, validateBaseUrl } from '../src/lib/ai/providers.js';
import { snapshotDue } from '../src/lib/scheduler.js';
import { KEY } from './helpers.js';

test('password hashing: verifies, rejects wrong, salts differ', async () => {
  const h1 = await hashPassword('hunter2hunter2'), h2 = await hashPassword('hunter2hunter2');
  assert.notEqual(h1, h2);
  assert.ok(await verifyPassword('hunter2hunter2', h1));
  assert.ok(!(await verifyPassword('wrong', h1)));
  assert.ok(!(await verifyPassword('x', 'garbage')));
});

test('secrets: AES-GCM round trip, AAD binds ciphertext to its row, tamper detected', async () => {
  const env = { ENCRYPTION_KEY: KEY };
  const c = await encryptSecret(env, 'sk-secret-value', 'ai:1');
  assert.ok(!c.includes('sk-secret'));
  assert.equal(await decryptSecret(env, c, 'ai:1'), 'sk-secret-value');
  await assert.rejects(decryptSecret(env, c, 'ai:2'));                       // swapped between records
  await assert.rejects(decryptSecret(env, c.slice(0, -4) + 'AAAA', 'ai:1'));  // tampered
  await assert.rejects(encryptSecret({}, 'x'));                               // missing key fails closed
  await assert.rejects(encryptSecret({ ENCRYPTION_KEY: 'c2hvcnQ=' }, 'x'));   // wrong key length
});

test('redact removes tokens and keys from log text', () => {
  const t = redact('Authorization: Bearer abcdefghijklmnop1234 and access_token=ya29.a0AfH6SMBxxxxxxxxxxxx key sk-abcdefghijklmnop');
  assert.ok(!/abcdefghijklmnop1234/.test(t) && !/ya29\.a0/.test(t) && !/sk-abcdefghij/.test(t));
});

test('timingSafeEqual', () => { assert.ok(timingSafeEqual('abc', 'abc')); assert.ok(!timingSafeEqual('abc', 'abd')); assert.ok(!timingSafeEqual('abc', 'abcd')); });

test('SigV4 presign matches the AWS documentation test vector', async () => {
  const url = await presign({ method: 'GET', host: 'examplebucket.s3.amazonaws.com', path: '/test.txt', accessKeyId: 'AKIAIOSFODNN7EXAMPLE',
    secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY', region: 'us-east-1', expires: 86400, date: new Date('2013-05-24T00:00:00Z') });
  assert.ok(url.endsWith('X-Amz-Signature=aeeed9bbccd4d02ee5c0109b86d86835f995330da4c265957d157751f604d404'));
});

test('validator: types, bounds, unknown fields, defaults', () => {
  const spec = { name: { type: 'string', required: true, max: 5 }, n: { type: 'integer', min: 1, max: 3 }, f: { type: 'boolean', default: true }, e: { type: 'string', enum: ['a', 'b'] } };
  assert.deepEqual(validate({ name: 'abc' }, spec), { name: 'abc', f: true });
  for (const bad of [{}, { name: 'abcdef' }, { name: 'a', n: 4 }, { name: 'a', n: 1.5 }, { name: 'a', e: 'z' }, { name: 'a', extra: 1 }, { name: 5 }]) assert.throws(() => validate(bad, spec));
  assert.throws(() => validate([], spec));
});

test('router matches params and distinguishes 404 vs 405', () => {
  const r = new Router().get('/a/:id', () => 1).post('/a/:id', () => 2);
  assert.equal(r.match('GET', '/a/x%20y').params.id, 'x y');
  assert.equal(r.match('DELETE', '/a/1').methodNotAllowed, true);
  assert.ok(!r.match('GET', '/zzz').methodNotAllowed);
});

test('time: Asia/Kolkata local -> UTC, DST zones, validity, slots', () => {
  assert.equal(localToUtc('2026-12-01T18:30', 'Asia/Kolkata'), Date.UTC(2026, 11, 1, 13, 0) / 1000);   // UTC+5:30
  assert.equal(localToUtc('2026-07-01T12:00', 'America/New_York'), Date.UTC(2026, 6, 1, 16, 0) / 1000); // EDT
  assert.equal(localToUtc('2026-01-01T12:00', 'America/New_York'), Date.UTC(2026, 0, 1, 17, 0) / 1000); // EST
  assert.deepEqual(utcToLocalParts(Date.UTC(2026, 11, 1, 13, 0) / 1000, 'Asia/Kolkata'), { date: '2026-12-01', time: '18:30', hour: 18, weekday: 3 });
  assert.ok(isValidTimezone('Asia/Kolkata') && !isValidTimezone('Mars/Base'));
  const after = Date.UTC(2026, 11, 1, 13, 0) / 1000;               // 18:30 IST Tuesday
  const s = nextSlots({ kind: 'daily', times: ['09:00', '18:30'], timezone: 'Asia/Kolkata' }, after, 3);
  assert.equal(s.length, 3); assert.ok(s.every((x) => x > after)); assert.equal(utcToLocalParts(s[0], 'Asia/Kolkata').time, '09:00');
  const w = nextSlots({ kind: 'weekly', times: ['10:00'], weekdays: [2], timezone: 'Asia/Kolkata' }, after, 2);   // Mondays
  assert.ok(w.every((x) => utcToLocalParts(x, 'Asia/Kolkata').weekday === 2));
});

test('metadata limits: truncation, hashtag caps, no tags outside YouTube, X 280', () => {
  let r = normalizeMetadata('youtube', { title: 'x'.repeat(150), description: 'd', hashtags: Array.from({ length: 30 }, (_, i) => '#tag' + i), tags: Array.from({ length: 200 }, (_, i) => 'keyword' + i), privacy: 'public' });
  assert.equal(r.value.title.length, 100); assert.equal(r.value.hashtags.length, 15);
  assert.ok(r.value.tags.join(',').length <= 520 && r.warnings.length >= 2);
  r = normalizeMetadata('instagram', { caption: 'c'.repeat(3000), hashtags: Array.from({ length: 40 }, (_, i) => 'h' + i), tags: ['a'] });
  assert.equal(r.value.caption.length, 2200); assert.equal(r.value.hashtags.length, 30); assert.equal(r.value.tags, undefined);
  assert.ok(r.warnings.some((w) => /no tags field/.test(w)));
  r = normalizeMetadata('x', { caption: 'y'.repeat(270), hashtags: ['a', 'b'] });
  assert.ok((r.value.caption + ' ' + r.value.hashtags.map((h) => '#' + h).join(' ')).trim().length <= 280);
  r = normalizeMetadata('tiktok', { caption: 'c', privacy: 'bogus' }); assert.equal(r.value.privacy, 'SELF_ONLY');
  assert.deepEqual(normalizeMetadata('youtube', { title: 't', hashtags: ['#a', 'a', 'A', 'b c!'] }).value.hashtags, ['a', 'bc']);
  assert.throws(() => normalizeMetadata('myspace', {}));
});

test('metadata prompt is platform-aware and template output is labelled', () => {
  const p = buildPrompt({ platform: 'instagram', transcript: 'hello world', durationS: 20 });
  assert.match(p.prompt, /caption/); assert.doesNotMatch(p.prompt, /title_alternatives/); assert.match(p.prompt, /Do not output a tags field/);
  assert.match(buildPrompt({ platform: 'youtube', transcript: 'x', durationS: 20 }).prompt, /title_alternatives/);
  const t = templateMetadata('youtube', { title: 'My clip', transcript: 'amazing gameplay with incredible ending moment' });
  assert.ok(t.hashtags.includes('Shorts')); assert.ok(SPECS.youtube.title >= t.title.length);
});

test('extractJson handles fences and surrounding prose; base URL SSRF guard', () => {
  assert.deepEqual(extractJson('```json\n{"a":1}\n```'), { a: 1 });
  assert.deepEqual(extractJson('Sure! {"a":2} done'), { a: 2 });
  assert.throws(() => extractJson('no json'));
  for (const u of ['http://api.example.com', 'https://localhost/v1', 'https://127.0.0.1', 'https://10.0.0.5', 'https://192.168.1.1', 'https://169.254.169.254', 'https://svc.internal']) assert.throws(() => validateBaseUrl(u), u);
  assert.equal(validateBaseUrl('https://api.groq.com/openai/v1/'), 'https://api.groq.com/openai/v1');
});

test('feedback loop: withholds conclusions without enough data, reports correlation honestly', () => {
  const few = computeInsights(Array.from({ length: 6 }, (_, i) => ({ views: 100 + i, predicted_score: 50 + i, duration_s: 25, moment_type: 'funny', published_hour: 18, title: 't', hook_text: 'so' })));
  assert.equal(few.sufficientData, false); assert.match(few.message, /at least 20/); assert.equal(few.scoreCalibration.correlation, null);
  assert.ok(Object.values(few.sections).every((s) => s.conclusion === null));
  assert.equal(computeInsights([]).postsWithMetric, 0);
  const many = Array.from({ length: 30 }, (_, i) => ({ views: i < 15 ? 1000 + i : 10 + i, predicted_score: i < 15 ? 80 : 40, duration_s: i < 15 ? 20 : 55, moment_type: i < 15 ? 'funny' : 'general', published_hour: 18, title: 'T', hook_text: 'so' }));
  const ins = computeInsights(many);
  assert.equal(ins.sufficientData, true); assert.equal(ins.sections.momentType.conclusion.best, 'funny'); assert.ok(ins.scoreCalibration.correlation > 0.9);
  assert.match(ins.caveat, /do not prove/); assert.equal(pearson([1, 1, 1], [1, 2, 3]), null);
  assert.equal(computeInsights([{ views: null }]).postsWithMetric, 0);       // missing metrics are excluded, not zero-filled
});

test('analytics snapshot cadence', () => {
  const t = 1_000_000;
  assert.equal(snapshotDue(600, null, t), true); assert.equal(snapshotDue(600, t - 100, t), false); assert.equal(snapshotDue(3 * 86400, t - 3 * 3600, t), false);
  assert.equal(snapshotDue(3 * 86400, t - 7 * 3600, t), true); assert.equal(snapshotDue(40 * 86400, null, t), false);
});
