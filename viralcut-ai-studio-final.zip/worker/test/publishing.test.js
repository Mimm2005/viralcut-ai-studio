import test from 'node:test';
import assert from 'node:assert/strict';
import { makeEnv, setupOwner, mockFetch, jsonRes } from './helpers.js';
import { tick, claimDue, runPublishingJob, publishDue, collectAnalytics, applyRetention } from '../src/lib/scheduler.js';
import { saveTokens } from '../src/lib/tokens.js';

const SOC = { GOOGLE_CLIENT_ID: 'g', GOOGLE_CLIENT_SECRET: 's', META_APP_ID: 'm', META_APP_SECRET: 's', R2_ACCOUNT_ID: 'a', R2_ACCESS_KEY_ID: 'k', R2_SECRET_ACCESS_KEY: 's' };
const NOW = () => Math.floor(Date.now() / 1000);
const q = (env, sql, ...a) => env.DB._raw.prepare(sql).get(...a);

/** A rendered clip, connected account with tokens, and metadata, ready for the approval workflow. */
async function seed(platform = 'youtube', { metaOverrides = {} } = {}) {
  const env = makeEnv(SOC); const c = await setupOwner(env); const u = q(env, 'SELECT id FROM users').id; const t = NOW();
  env.DB._raw.prepare("INSERT INTO projects(id,user_id,name,created_at,updated_at) VALUES('p1',?,'x',1,1)").run(u);
  env.DB._raw.prepare("INSERT INTO source_media(id,project_id,user_id,adapter,state,created_at,updated_at) VALUES('s1','p1',?,'upload','imported',1,1)").run(u);
  env.DB._raw.prepare("INSERT INTO processing_jobs(id,project_id,source_id,user_id,status,created_at,updated_at) VALUES('j1','p1','s1',?,'succeeded',1,1)").run(u);
  env.DB._raw.prepare("INSERT INTO detected_moments(id,job_id,project_id,source_id,rank,start_s,end_s,moment_type,transcript,created_at) VALUES('m1','j1','p1','s1',1,0,20,'funny','wait what no way',1)").run();
  env.DB._raw.prepare("INSERT INTO moment_scores(id,moment_id,total,hook,emotion,entertainment,unexpectedness,shareability,storytelling,confidence,explanation,created_at) VALUES('sc1','m1',77,1,1,1,1,1,1,0.7,'e',1)").run();
  env.DB._raw.prepare("INSERT INTO generated_clips(id,user_id,project_id,moment_id,source_id,title,start_s,end_s,status,r2_key,size_bytes,created_at,updated_at) VALUES('c_clip0001',?,'p1','m1','s1','Wait what',0,20,'ready','clips/c1.mp4',3000,1,1)").run(u);
  await env.MEDIA.put('clips/c1.mp4', new Uint8Array(3000).buffer);
  const aid = 'sa_' + platform; const extra = platform === 'instagram' ? { pageId: 'PG', igUserId: 'IG1' } : platform === 'facebook' ? { pageId: 'PG' } : {};
  env.DB._raw.prepare("INSERT INTO social_accounts(id,user_id,platform,external_id,display_name,status,scopes,extra,connected_at,updated_at) VALUES(?,?,?,'ext','Acct','connected','[]',?,?,?)").run(aid, u, platform, JSON.stringify(extra), t, t);
  await saveTokens(env, aid, { access: 'ACCESSTOKEN-123456789', refresh: 'REFRESH-123456789', expiresIn: 7200 });
  const m = { title: 'Approved Title', description: 'desc', caption: 'Approved caption', hashtags: ['fun'], tags: ['a'], privacy: 'private', ...metaOverrides };
  env.DB._raw.prepare('INSERT INTO clip_metadata(id,clip_id,platform,title,description,caption,hashtags,tags,category,language,privacy,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,1)')
    .run('md_' + platform, 'c_clip0001', platform, m.title, m.description, m.caption, JSON.stringify(m.hashtags), JSON.stringify(m.tags), '23', 'en', m.privacy, 'manual');
  return { env, c, u, aid };
}
const approve = (c, platform = 'youtube') => c.post('/api/publishing/approve', { clipId: 'c_clip0001', platform });
const dueNow = (env, id) => env.DB._raw.prepare("UPDATE publishing_jobs SET status='scheduled', run_at=?, next_attempt_at=NULL WHERE id=?").run(NOW() - 5, id);
const future = () => new Date(Date.now() + 2 * 86400e3).toISOString().slice(0, 16);

// -------- YouTube mock platform --------
function yt(opts = {}) {
  const st = { inits: [], puts: 0, uploadStatus: 'processed', ...opts };
  const routes = [
    ['upload/youtube/v3/videos?uploadType=resumable', (u, init) => { if (st.initStatus) return jsonRes({ error: { message: 'backend' } }, st.initStatus); st.inits.push(JSON.parse(init.body)); return new Response('{}', { status: 200, headers: { location: 'https://upload.test/s1' } }); }],
    ['upload.test/s1', (u, init) => { st.puts++; if (st.putStatus) return jsonRes({ error: { message: 'x' } }, st.putStatus); return { id: 'VID123' }; }],
    ['videos?part=status,processingDetails', () => st.missing ? { items: [] } : { items: [{ status: { uploadStatus: st.uploadStatus, privacyStatus: 'private', rejectionReason: 'copyright' } }] }],
    ['channels?part=contentDetails', () => ({ items: [{ contentDetails: { relatedPlaylists: { uploads: 'UU1' } } }] })],
    ['playlistItems', () => ({ items: st.recent ? [{ snippet: { title: 'Approved Title', publishedAt: new Date().toISOString(), resourceId: { videoId: 'EXISTING1' } } }] : [] })],
    ['videos?part=statistics', () => ({ items: [{ statistics: { viewCount: '1234', likeCount: '56', commentCount: '7' } }] })],
    ['youtubeanalytics.googleapis.com', () => st.noAnalytics ? jsonRes({ error: { message: 'Forbidden: missing scope' } }, 403) : { rows: [[42.5, 61.2, 9]] }],
    ['oauth2.googleapis.com/token', () => jsonRes({ error: 'invalid_grant' }, 400)],
  ];
  return { st, ...(() => { const mf = mockFetch(routes); return { mf }; })() };
}

test('approval workflow: needs ready clip, connected account, metadata; duplicates blocked; schedule rules', async () => {
  const { env, c } = await seed();
  env.DB._raw.prepare("UPDATE generated_clips SET status='draft'").run(); assert.equal((await approve(c)).status, 409);
  env.DB._raw.prepare("UPDATE generated_clips SET status='ready'").run();
  assert.equal((await approve(c, 'instagram')).status, 409);                                               // no instagram account
  env.DB._raw.prepare("UPDATE social_accounts SET status='expired'").run(); assert.equal((await approve(c)).status, 409); env.DB._raw.prepare("UPDATE social_accounts SET status='connected'").run();
  env.DB._raw.prepare('DELETE FROM clip_metadata').run(); assert.equal((await approve(c)).status, 409);       // no metadata
  env.DB._raw.prepare("INSERT INTO clip_metadata(id,clip_id,platform,title,language,privacy,source,created_at,updated_at) VALUES('md_youtube','c_clip0001','youtube','Approved Title','en','private','manual',1,1)").run();
  const a = await approve(c); assert.equal(a.status, 201); assert.equal(a.data.job.status, 'approved');
  assert.equal((await approve(c)).status, 409);                                                               // duplicate prevention
  const id = a.data.job.id;
  assert.equal((await c.post('/api/publishing/schedule', { jobId: id, runAt: NOW() + 5 })).status, 400);     // too soon
  assert.equal((await c.post('/api/publishing/schedule', { jobId: id, runAt: NOW() + 400 * 86400 })).status, 400);
  assert.equal((await c.post('/api/publishing/schedule', { jobId: id, localTime: 'tomorrow' })).status, 400);
  assert.equal((await c.post('/api/publishing/schedule', { jobId: id, localTime: future(), timezone: 'Mars/Base' })).status, 400);
  assert.equal((await c.post('/api/publishing/schedule', { jobId: id, slot: 'next' })).status, 400);          // no recurring schedule yet
  const s = await c.post('/api/publishing/schedule', { jobId: id, localTime: future() }); assert.equal(s.status, 200);
  assert.equal(s.data.job.timezone, 'Asia/Kolkata');                                                          // default tz
  assert.equal(new Date(s.data.job.runAt * 1000).toISOString().slice(0, 16), new Date(new Date(future() + ':00Z').getTime() - 19800e3).toISOString().slice(0, 16));   // IST = UTC+5:30
  assert.ok(q(env, "SELECT 1 x FROM notifications WHERE kind='post_scheduled'"));
  // recurring schedule + next slot
  assert.equal((await c.post('/api/publishing/schedules', { platform: 'youtube', kind: 'daily', times: ['25:00'] })).status, 400);
  assert.equal((await c.post('/api/publishing/schedules', { platform: 'youtube', kind: 'weekly', times: ['09:00'] })).status, 400);
  assert.equal((await c.post('/api/publishing/schedules', { platform: 'youtube', kind: 'daily', times: ['09:00', '18:30'] })).status, 201);
  const re = await c.patch(`/api/publishing/jobs/${id}`, { action: 'reschedule', slot: 'next' }); assert.equal(re.status, 200); assert.ok(re.data.job.runAt > NOW());
  assert.ok((await c.get('/api/publishing/schedules')).data.schedules[0].next.length === 3);
  const cal = (await c.get('/api/publishing/calendar')).data; assert.equal(cal.timezone, 'Asia/Kolkata'); assert.equal(Object.values(cal.days).flat().length, 1);
  assert.equal((await c.get('/api/publishing/calendar?tz=Mars/Base')).status, 400);
  assert.equal((await c.patch(`/api/publishing/jobs/${id}`, { action: 'unschedule' })).data.job.status, 'approved');
  assert.equal((await c.del(`/api/publishing/jobs/${id}`)).status, 200); assert.equal((await approve(c)).status, 201);   // cancelled job frees the slot
});

test('YouTube: not early; publishes ONLY after platform confirmation; approved snapshot is what is sent', async () => {
  const { env, c } = await seed(); const p = yt();
  try {
    const id = (await approve(c)).data.job.id; await c.post('/api/publishing/schedule', { jobId: id, runAt: NOW() + 3600 });
    await tick(env); assert.equal(p.st.inits.length, 0); assert.equal(q(env, 'SELECT status FROM publishing_jobs').status, 'scheduled');       // future job untouched
    dueNow(env, id); await tick(env);
    const sent = p.st.inits[0]; assert.equal(sent.snippet.title, 'Approved Title'); assert.equal(sent.status.privacyStatus, 'private'); assert.equal(sent.status.selfDeclaredMadeForKids, false);
    const init = p.mf.calls.find((x) => x.url.includes('uploadType=resumable')); assert.equal(init.init.headers['x-upload-content-length'], '3000'); assert.equal(init.init.headers.authorization, 'Bearer ACCESSTOKEN-123456789');
    const job = q(env, 'SELECT * FROM publishing_jobs'); assert.equal(job.status, 'published'); assert.equal(job.external_ref, 'VID123');
    const post = q(env, 'SELECT * FROM published_posts'); assert.equal(post.external_id, 'VID123'); assert.equal(post.predicted_score, 77); assert.equal(post.moment_type, 'funny'); assert.ok(post.verified_at > 0); assert.match(post.url, /VID123/);
    assert.ok(q(env, "SELECT 1 x FROM notifications WHERE kind='post_published'")); assert.ok(q(env, 'SELECT 1 x FROM publishing_logs'));
    await tick(env); assert.equal(p.st.puts, 1);                                                             // never uploads twice
    // metadata edited after approval does not change anything already approved/published
    const logs = JSON.stringify((await c.get(`/api/publishing/jobs/${id}`)).data); assert.ok(!logs.includes('ACCESSTOKEN'));
  } finally { p.mf.restore(); }
});

test('YouTube: NOT reported as published when the platform has not confirmed; resumes at verify step without re-uploading', async () => {
  const { env, c } = await seed(); const p = yt({ missing: true });
  try {
    const id = (await approve(c)).data.job.id; dueNow(env, id); await tick(env);
    let job = q(env, 'SELECT * FROM publishing_jobs'); assert.equal(job.status, 'publishing'); assert.equal(job.stage, 'uploaded'); assert.equal(job.external_ref, 'VID123');
    assert.equal(q(env, 'SELECT COUNT(*) n FROM published_posts').n, 0);                                     // no success without confirmation
    env.DB._raw.prepare('UPDATE publishing_jobs SET next_attempt_at=? WHERE id=?').run(NOW() - 1, id); p.st.missing = false; p.st.uploadStatus = 'processing';
    await tick(env); assert.equal(q(env, 'SELECT status FROM publishing_jobs').status, 'publishing');
    env.DB._raw.prepare('UPDATE publishing_jobs SET next_attempt_at=? WHERE id=?').run(NOW() - 1, id); p.st.uploadStatus = 'processed';
    await tick(env); assert.equal(q(env, 'SELECT status FROM publishing_jobs').status, 'published'); assert.equal(p.st.puts, 1);
  } finally { p.mf.restore(); }
});

test('YouTube: platform rejection fails permanently with the platform reason', async () => {
  const { env, c } = await seed(); const p = yt({ uploadStatus: 'rejected' });
  try { const id = (await approve(c)).data.job.id; dueNow(env, id); await tick(env);
    const j = q(env, 'SELECT * FROM publishing_jobs'); assert.equal(j.status, 'failed'); assert.match(j.error, /rejected.*copyright/); assert.equal(q(env, 'SELECT COUNT(*) n FROM published_posts').n, 0);
    assert.ok(q(env, "SELECT 1 x FROM notifications WHERE kind='publishing_failed'")); } finally { p.mf.restore(); }
});

test('retry: transient errors back off then fail after max attempts; manual retry restores; crash window never double-uploads', async () => {
  const { env, c } = await seed(); const p = yt({ putStatus: 503 });
  try {
    const id = (await approve(c)).data.job.id; dueNow(env, id); await tick(env);
    let j = q(env, 'SELECT * FROM publishing_jobs'); assert.equal(j.status, 'scheduled'); assert.equal(j.attempts, 1); assert.ok(j.next_attempt_at > NOW() + 30); assert.match(j.error, /503/);
    await tick(env); assert.equal(p.st.puts, 1);                                                              // backoff respected
    for (const n of [2, 3]) { env.DB._raw.prepare('UPDATE publishing_jobs SET next_attempt_at=NULL WHERE id=?').run(id); await tick(env); }
    j = q(env, 'SELECT * FROM publishing_jobs'); assert.equal(j.status, 'failed'); assert.equal(j.attempts, 3);
    // crash after the upload completed but before the id was saved: next attempt finds the existing upload instead of re-uploading
    p.st.putStatus = 0; p.st.recent = true; const puts = p.st.puts;
    const r = await c.patch(`/api/publishing/jobs/${id}`, { action: 'retry' }); assert.equal(r.status, 200);
    env.DB._raw.prepare('UPDATE publishing_jobs SET attempts=1 WHERE id=?').run(id); await tick(env);
    j = q(env, 'SELECT * FROM publishing_jobs'); assert.equal(j.status, 'published'); assert.equal(j.external_ref, 'EXISTING1'); assert.equal(p.st.puts, puts);
  } finally { p.mf.restore(); }
});

test('token problems: 401 => failed with reconnect message, no blind retries; expired account notifies', async () => {
  const { env, c } = await seed(); const p = yt({ initStatus: 401 });
  try { const id = (await approve(c)).data.job.id; dueNow(env, id); await tick(env);
    const j = q(env, 'SELECT * FROM publishing_jobs'); assert.equal(j.status, 'failed'); assert.equal(j.attempts, 1); assert.match(j.error, /reconnect/i); assert.equal(p.st.inits.length, 0);
    env.DB._raw.prepare('UPDATE oauth_tokens SET expires_at=1').run(); dueNow(env, id); env.DB._raw.prepare("UPDATE publishing_jobs SET attempts=0").run(); await tick(env);
    assert.equal(q(env, "SELECT status FROM social_accounts").status, 'expired'); assert.ok(q(env, "SELECT 1 x FROM notifications WHERE kind='token_expired'")); } finally { p.mf.restore(); }
});

test('scheduler safety: concurrent runners claim once; pause respected; leases; missing clip/account fail cleanly', async () => {
  const { env, c } = await seed(); const p = yt();
  try {
    const id = (await approve(c)).data.job.id; dueNow(env, id);
    const [a, b] = await Promise.all([claimDue(env), claimDue(env)]); assert.equal(a.length + b.length, 1);       // exactly one winner
    env.DB._raw.prepare("UPDATE publishing_jobs SET status='scheduled'").run();
    assert.equal((await c.patch('/api/publishing/queue', { paused: true })).data.queuePaused, true);
    await tick(env); assert.equal(p.st.inits.length, 0); assert.equal(q(env, 'SELECT status FROM publishing_jobs').status, 'scheduled');
    await c.patch('/api/publishing/queue', { paused: false });
    // a live lease blocks pick-up; an expired lease (worker died) allows it
    env.DB._raw.prepare("UPDATE publishing_jobs SET status='publishing', lease_expires_at=?, next_attempt_at=NULL").run(NOW() + 200); assert.deepEqual(await claimDue(env), []);
    env.DB._raw.prepare('UPDATE publishing_jobs SET lease_expires_at=?').run(NOW() - 1); assert.equal((await claimDue(env)).length, 1);
    // cannot cancel while publishing; missing file fails permanently
    assert.equal((await c.del(`/api/publishing/jobs/${id}`)).status, 409);
    await env.MEDIA.delete('clips/c1.mp4'); await runPublishingJob(env, id); const j = q(env, 'SELECT * FROM publishing_jobs'); assert.equal(j.status, 'failed'); assert.match(j.error, /missing from storage/);
  } finally { p.mf.restore(); }
});

test('Instagram Reels: container -> poll -> publish -> verified permalink; interrupted publish is NOT retried blindly', async () => {
  const { env, c } = await seed('instagram'); let status = 'IN_PROGRESS'; let publishes = 0;
  const mf = mockFetch([['/IG1/media_publish', () => { publishes++; return { id: 'MEDIA9' }; }], ['/IG1/media', (u, init) => ({ id: 'CONT1' })], ['/CONT1?fields=status_code', () => ({ status_code: status })], ['/MEDIA9?fields=id,permalink', () => ({ id: 'MEDIA9', permalink: 'https://instagram.com/reel/abc', media_product_type: 'REELS' })]]);
  try {
    const id = (await approve(c, 'instagram')).data.job.id; dueNow(env, id); await tick(env);
    const create = mf.calls.find((x) => x.url.endsWith('/IG1/media')); const body = new URLSearchParams(create.init.body); assert.equal(body.get('media_type'), 'REELS'); assert.match(body.get('video_url'), /X-Amz-Signature/); assert.match(body.get('caption'), /Approved caption\n\n#fun/);
    const step = () => { env.DB._raw.prepare('UPDATE publishing_jobs SET next_attempt_at=? WHERE id=?').run(NOW() - 1, id); return tick(env); };
    assert.equal(q(env, 'SELECT stage FROM publishing_jobs').stage, 'container_created');
    await step(); assert.equal(publishes, 0); assert.equal(q(env, 'SELECT status FROM publishing_jobs').status, 'publishing');          // still processing => not published
    status = 'FINISHED'; await step();
    const j = q(env, 'SELECT * FROM publishing_jobs'); assert.equal(j.status, 'published'); assert.equal(publishes, 1); const post = q(env, 'SELECT * FROM published_posts'); assert.equal(post.external_id, 'MEDIA9'); assert.equal(post.url, 'https://instagram.com/reel/abc');
  } finally { mf.restore(); }
  // crash between "publish call sent" and "media id saved"
  const s2 = await seed('instagram'); let pub2 = 0;
  const mf2 = mockFetch([['/media_publish', () => { pub2++; return { id: 'X' }; }]]);
  try {
    const id = (await approve(s2.c, 'instagram')).data.job.id;
    s2.env.DB._raw.prepare("UPDATE publishing_jobs SET status='scheduled', run_at=?, stage='publishing_call', external_ref=?, attempts=1").run(NOW() - 5, JSON.stringify({ container: 'CONT1' }));
    await tick(s2.env); const j = q(s2.env, 'SELECT * FROM publishing_jobs'); assert.equal(j.status, 'needs_verification'); assert.equal(pub2, 0);
    assert.equal((await s2.c.patch(`/api/publishing/jobs/${id}`, { action: 'retry' })).data.job.status, 'scheduled'); assert.equal(q(s2.env, 'SELECT stage FROM publishing_jobs').stage, null);
  } finally { mf2.restore(); }
});

test('Facebook Reels, TikTok and X adapters follow their documented multi-step flows (mock-verified only)', async () => {
  { // Facebook
    const { env, c } = await seed('facebook'); let phase = 'processing';
    const mf = mockFetch([['/PG/video_reels', (u, init) => { const b = new URLSearchParams(init.body); return b.get('upload_phase') === 'start' ? { video_id: 'FV1', upload_url: 'https://rupload.test/FV1' } : { success: true }; }], ['rupload.test/FV1', () => ({ success: true })], ['/FV1?fields=status', () => ({ status: { video_status: phase, publishing_phase: { status: phase === 'ready' ? 'complete' : 'in_progress' } }, permalink_url: '/reel/FV1' })]]);
    try { const id = (await approve(c, 'facebook')).data.job.id; dueNow(env, id); await tick(env);
      for (let i = 0; i < 4; i++) { env.DB._raw.prepare('UPDATE publishing_jobs SET next_attempt_at=?').run(NOW() - 1); await tick(env); }
      assert.equal(q(env, 'SELECT status FROM publishing_jobs').status, 'publishing'); assert.equal(q(env, 'SELECT COUNT(*) n FROM published_posts').n, 0);
      const up = mf.calls.find((x) => x.url.includes('rupload')); assert.equal(up.init.headers.authorization, 'OAuth ACCESSTOKEN-123456789'); assert.match(up.init.headers.file_url, /X-Amz-Signature/);
      const fin = mf.calls.filter((x) => x.url.endsWith('/PG/video_reels')).map((x) => new URLSearchParams(x.init.body)).find((b) => b.get('upload_phase') === 'finish'); assert.equal(fin.get('video_state'), 'PUBLISHED');
      phase = 'ready'; env.DB._raw.prepare('UPDATE publishing_jobs SET next_attempt_at=?').run(NOW() - 1); await tick(env); assert.equal(q(env, 'SELECT status FROM publishing_jobs').status, 'published'); } finally { mf.restore(); }
  }
  { // TikTok: unaudited accounts only allow SELF_ONLY; requested privacy is downgraded, never silently made public
    const { env, c } = await seed('tiktok', { metaOverrides: { privacy: 'PUBLIC_TO_EVERYONE' } }); let st = 'PROCESSING_UPLOAD'; const inits = [];
    const mf = mockFetch([['creator_info/query', () => ({ data: { privacy_level_options: ['SELF_ONLY'] } })], ['publish/video/init', (u, init) => { inits.push(JSON.parse(init.body)); return { data: { publish_id: 'PUB1', upload_url: 'https://tt-upload.test/u' } }; }], ['tt-upload.test', (u, init) => new Response('', { status: 201 })], ['status/fetch', () => ({ data: { status: st, publicaly_available_post_id: st === 'PUBLISH_COMPLETE' ? [777] : [] } })]]);
    try { const id = (await approve(c, 'tiktok')).data.job.id; dueNow(env, id); await tick(env);
      for (let i = 0; i < 3; i++) { env.DB._raw.prepare('UPDATE publishing_jobs SET next_attempt_at=?').run(NOW() - 1); await tick(env); }
      assert.equal(inits[0].post_info.privacy_level, 'SELF_ONLY'); assert.equal(inits[0].source_info.video_size, 3000); assert.equal(q(env, 'SELECT status FROM publishing_jobs').status, 'publishing');
      const put = mf.calls.find((x) => x.url.includes('tt-upload')); assert.equal(put.init.headers['content-range'], 'bytes 0-2999/3000');
      st = 'PUBLISH_COMPLETE'; env.DB._raw.prepare('UPDATE publishing_jobs SET next_attempt_at=?').run(NOW() - 1); await tick(env); assert.equal(q(env, 'SELECT external_id FROM published_posts').external_id, '777'); } finally { mf.restore(); }
  }
  { // X
    const { env, c } = await seed('x'); const posted = [];
    const mf = mockFetch([['/media/upload/initialize', () => ({ data: { id: 'MED1' } })], ['/MED1/append', () => ({})], ['/MED1/finalize', () => ({ data: { processing_info: { state: 'pending', check_after_secs: 1 } } })], ['command=STATUS', () => ({ data: { processing_info: { state: 'succeeded' } } })], ['api.x.com/2/tweets', (u, init) => { posted.push(JSON.parse(init.body)); return { data: { id: 'TW1' } }; }]]);
    try { const id = (await approve(c, 'x')).data.job.id; dueNow(env, id); await tick(env);
      for (let i = 0; i < 2; i++) { env.DB._raw.prepare('UPDATE publishing_jobs SET next_attempt_at=?').run(NOW() - 1); await tick(env); }
      assert.deepEqual(posted[0].media.media_ids, ['MED1']); assert.ok(posted[0].text.length <= 280); assert.equal(q(env, 'SELECT url FROM published_posts').url, 'https://x.com/i/status/TW1'); } finally { mf.restore(); }
  }
});

test('analytics: real API numbers only; unavailable metrics are explicit nulls with reasons; ranges, platforms, insights', async () => {
  const { env, c } = await seed(); const p = yt();
  try {
    const id = (await approve(c)).data.job.id; dueNow(env, id); await tick(env);
    env.DB._raw.prepare('DELETE FROM analytics_snapshots').run();     // tick already took the first snapshot; remove it to prove nothing is invented without one
    let ov = (await c.get('/api/analytics/overview?range=24h')).data; assert.equal(ov.posts, 1); assert.equal(ov.totals.views, null); assert.match(ov.note, /no analytics snapshot/);   // nothing invented before a snapshot exists
    assert.equal(await collectAnalytics(env), 1);
    ov = (await c.get('/api/analytics/overview?range=24h')).data; assert.equal(ov.totals.views, 1234); assert.equal(ov.totals.shares, 9); assert.equal(ov.totals.reach, null); assert.equal(ov.bestClips[0].views, 1234);
    const posts = (await c.get('/api/analytics/posts?range=7d')).data.posts; assert.equal(posts[0].metrics.reach, null); assert.match(posts[0].unavailable.reach, /not provided/); assert.ok(Math.abs(posts[0].engagementRate - (56 + 7 + 9) / 1234) < 1e-9); assert.equal(posts[0].history.length, 1);
    p.st.noAnalytics = true; env.DB._raw.prepare('UPDATE analytics_snapshots SET captured_at=captured_at-7200'); env.DB._raw.prepare('UPDATE analytics_snapshots SET captured_at=1').run(); assert.equal(await collectAnalytics(env), 1);
    const last = (await c.get('/api/analytics/posts?range=24h')).data.posts[0]; assert.match(last.unavailable.avgViewPercentage, /analytics API/); assert.equal(last.metrics.avgViewPercentage, null);   // partial data labelled, not zero-filled
    assert.equal((await c.get('/api/analytics/platforms?range=30d')).data.platforms[0].platform, 'youtube');
    assert.equal((await c.get('/api/analytics/overview?range=custom&from=1&to=2')).data.posts, 0);                   // date filter
    assert.equal((await c.get('/api/analytics/overview?range=bogus')).status, 400);
    const ins = (await c.get('/api/analytics/insights')).data; assert.equal(ins.sufficientData, false); assert.match(ins.caveat, /correlations/);
    env.DB._raw.prepare('INSERT INTO analytics_snapshots(id,post_id,captured_at,metrics,unavailable,source) VALUES(?,?,?,?,?,?)').run('err', q(env, 'SELECT id FROM published_posts').id, NOW() + 5, '{}', '{"all":"boom"}', 'error');
    assert.equal((await c.get('/api/analytics/overview?range=24h')).data.totals.views, 1234);                         // failed collection never overwrites real data
  } finally { p.mf.restore(); }
});

test('retention: old sources and clip files are removed; fresh files and clips with live posts are kept; usage drops', async () => {
  const { env, c, u } = await seed(); const day = 86400, t = NOW();
  await env.MEDIA.put('src/old.mp4', new Uint8Array(500).buffer); await env.MEDIA.put('src/new.mp4', new Uint8Array(500).buffer); await env.MEDIA.put('clips/old.mp4', new Uint8Array(100).buffer); await env.MEDIA.put('clips/live.mp4', new Uint8Array(100).buffer);
  const db = env.DB._raw;
  db.prepare("INSERT INTO source_media(id,project_id,user_id,adapter,state,r2_key,size_bytes,created_at,updated_at) VALUES('old','p1',?,'upload','imported','src/old.mp4',500,?,?)").run(u, t - 40 * day, t);
  db.prepare("INSERT INTO source_media(id,project_id,user_id,adapter,state,r2_key,size_bytes,created_at,updated_at) VALUES('new','p1',?,'upload','imported','src/new.mp4',500,?,?)").run(u, t - 2 * day, t);
  db.prepare("INSERT INTO generated_clips(id,user_id,project_id,source_id,start_s,end_s,status,r2_key,size_bytes,created_at,updated_at) VALUES('c_old',?,'p1','s1',0,10,'ready','clips/old.mp4',100,?,?)").run(u, t - 40 * day, t);
  db.prepare("INSERT INTO generated_clips(id,user_id,project_id,source_id,start_s,end_s,status,r2_key,size_bytes,created_at,updated_at) VALUES('c_live',?,'p1','s1',0,10,'ready','clips/live.mp4',100,?,?)").run(u, t - 40 * day, t);
  db.prepare("INSERT INTO clip_metadata(id,clip_id,platform,title,language,privacy,source,created_at,updated_at) VALUES('mdl','c_live','youtube','t','en','private','manual',1,1)").run();
  db.prepare("INSERT INTO publishing_jobs(id,user_id,clip_id,metadata_id,account_id,platform,status,run_at,created_at,updated_at) VALUES('pj_live1',?,'c_live','mdl','sa_youtube','youtube','scheduled',?,1,1)").run(u, t + 3600);
  assert.equal((await c.patch('/api/settings', { retentionDays: 30 })).status, 200);
  assert.equal(await applyRetention(env), 3);   // old source, old clip, and the (also ancient) seeded base clip
  assert.equal(env.MEDIA._m.has('src/old.mp4'), false); assert.equal(env.MEDIA._m.has('clips/old.mp4'), false);
  assert.equal(env.MEDIA._m.has('src/new.mp4'), true); assert.equal(env.MEDIA._m.has('clips/live.mp4'), true);          // fresh + live-scheduled survive
  assert.equal(q(env, "SELECT status FROM generated_clips WHERE id='c_old'").status, 'draft'); assert.match(q(env, "SELECT message FROM source_media WHERE id='old'").message, /retention/);
  assert.equal(q(env, "SELECT size_bytes s FROM source_media WHERE id='old'").s, 0); assert.equal(await applyRetention(env), 0);   // idempotent
  db.prepare("INSERT INTO projects(id,user_id,name,created_at,updated_at) VALUES('proj_ret01',?,'r',1,1)").run(u);
  db.prepare("INSERT INTO source_media(id,project_id,user_id,adapter,state,r2_key,created_at,updated_at) VALUES('src_rem001','proj_ret01',?,'upload','imported',NULL,1,1)").run(u);
  assert.equal((await c.post('/api/analyze', { projectId: 'proj_ret01', sourceId: 'src_rem001' })).status, 409);                  // cannot analyse a removed source
});
