import test from 'node:test';
import assert from 'node:assert/strict';
import { makeEnv, Client, setupOwner, mockFetch, jsonRes } from './helpers.js';
import { tick, persistAnalysis } from '../src/lib/scheduler.js';

const bytes = (n, seed = 1) => { const b = new Uint8Array(n); for (let i = 0; i < n; i++) b[i] = (i * seed) % 251; return b.buffer; };

test('auth: setup needs token, is one-time, login/logout/me, wrong password, no public registration', async () => {
  const env = makeEnv(); const c = new Client(env);
  assert.equal((await c.get('/api/auth/me')).data.setupRequired, true);
  assert.equal((await c.post('/api/auth/setup', { email: 'a@b.co', password: 'long enough password', setupToken: 'nope' })).status, 403);
  assert.equal((await c.post('/api/auth/setup', { email: 'a@b.co', password: 'short', setupToken: env.SETUP_TOKEN })).status, 400);
  assert.equal((await c.post('/api/auth/setup', { email: 'a@b.co', password: 'long enough password', setupToken: env.SETUP_TOKEN })).status, 201);
  assert.equal((await c.post('/api/auth/setup', { email: 'x@b.co', password: 'long enough password', setupToken: env.SETUP_TOKEN })).status, 409);   // already set up
  assert.equal((await c.post('/api/auth/login', { email: 'a@b.co', password: 'wrong wrong wrong' })).status, 401);
  assert.equal((await c.get('/api/projects')).status, 401);
  const l = await c.post('/api/auth/login', { email: 'A@B.co', password: 'long enough password' });
  assert.equal(l.status, 200); assert.match(l.headers.get('set-cookie'), /HttpOnly; Secure; SameSite=Lax/);
  assert.equal((await c.get('/api/auth/me')).data.user.email, 'a@b.co');
  const stored = env.DB._raw.prepare('SELECT password_hash FROM users').get().password_hash; assert.ok(stored.startsWith('pbkdf2$') && !stored.includes('long enough'));
  const sess = env.DB._raw.prepare('SELECT id FROM sessions').get().id; assert.ok(!c.cookie.includes(sess));   // DB holds only a hash of the cookie token
  await c.post('/api/auth/logout'); assert.equal((await c.get('/api/auth/me')).status, 401);
});

test('auth: login is rate limited', async () => {
  const env = makeEnv(); await setupOwner(env); const c = new Client(env); let last;
  for (let i = 0; i < 12; i++) last = await c.post('/api/auth/login', { email: 'owner@example.com', password: 'bad bad bad bad' });
  assert.equal(last.status, 429); assert.ok(last.headers.get('retry-after'));
});

test('CSRF and origin checks block cross-site writes', async () => {
  const env = makeEnv(); const c = await setupOwner(env);
  assert.equal((await c.req('POST', '/api/projects', { name: 'x' }, { 'x-csrf-token': 'wrong' })).status, 403);
  assert.equal((await c.req('POST', '/api/projects', { name: 'x' }, { origin: 'https://evil.example' })).status, 403);
  assert.equal((await c.req('POST', '/api/projects', { name: 'x' })).status, 201);
  assert.equal((await c.get('/api/projects')).status, 200);
});

test('authorization: another user cannot read, modify or delete my resources (IDs reveal nothing)', async () => {
  const env = makeEnv(); const a = await setupOwner(env);
  const now = Math.floor(Date.now() / 1000);
  env.DB._raw.prepare("INSERT INTO users(id,email,display_name,password_hash,role,created_at,updated_at) VALUES('u_b','b@x.co','B','x','member',?,?)").run(now, now);
  env.DB._raw.prepare('INSERT INTO user_settings(user_id,updated_at) VALUES(?,?)').run('u_b', now);
  const p = (await a.post('/api/projects', { name: 'mine' })).data.project;
  // second session for user B
  const { createSession } = await import('../src/lib/auth.js'); const sb = await createSession(env, 'u_b', new Request('https://app.test'));
  const b = new Client(env); b.cookie = `vc_session=${sb.token}`; b.csrf = sb.csrf;
  assert.equal((await b.get(`/api/projects/${p.id}`)).status, 404);
  assert.equal((await b.del(`/api/projects/${p.id}`)).status, 404);
  assert.equal((await b.post('/api/media/upload/init', { projectId: p.id, filename: 'a.mp4', size: 10 })).status, 404);
  assert.deepEqual((await b.get('/api/projects')).data.projects, []);
  assert.equal((await a.get(`/api/projects/${p.id}`)).status, 200);
});

test('upload: validation, quota, proxy upload, completion, duplicate detection, signed file access', async () => {
  const env = makeEnv(); const c = await setupOwner(env);
  const p = (await c.post('/api/projects', { name: 'v' })).data.project;
  assert.equal((await c.post('/api/media/upload/init', { projectId: p.id, filename: 'evil.exe', size: 10 })).status, 400);
  assert.equal((await c.post('/api/media/upload/init', { projectId: p.id, filename: 'a.mp4', size: 10, contentType: 'text/html' })).status, 400);
  assert.equal((await c.post('/api/media/upload/init', { projectId: p.id, filename: 'a.mp4', size: 5 * 1024 ** 3 })).status, 413);
  assert.equal((await c.post('/api/media/upload/init', { projectId: p.id, filename: 'a.mp4', size: 200 * 1024 * 1024 })).status, 503);   // too big for proxy without S3 creds
  const init = await c.post('/api/media/upload/init', { projectId: p.id, filename: 'clip.mp4', size: 4096, contentType: 'video/mp4' });
  assert.equal(init.status, 201); assert.equal(init.data.mode, 'proxy');
  assert.equal((await c.post('/api/media/upload/complete', { sourceId: init.data.sourceId })).status, 400);     // nothing uploaded yet
  const put = await c.req('PUT', init.data.uploadUrl, bytes(4096), { 'content-type': 'video/mp4' }); assert.equal(put.status, 200);
  const done = await c.post('/api/media/upload/complete', { sourceId: init.data.sourceId });
  assert.equal(done.status, 200); assert.equal(done.data.source.state, 'validated');          // validated, NOT imported/authorized
  // same bytes again => duplicate
  const init2 = await c.post('/api/media/upload/init', { projectId: p.id, filename: 'copy.mp4', size: 4096 });
  await c.req('PUT', init2.data.uploadUrl, bytes(4096));
  const dup = await c.post('/api/media/upload/complete', { sourceId: init2.data.sourceId }); assert.equal(dup.status, 409);
  assert.equal(env.MEDIA._m.size, 1);                                                          // duplicate object removed
  // signed preview url: works, tamper/expiry rejected
  const m = await c.get(`/api/media/${init.data.sourceId}`); const url = m.data.source.previewUrl; assert.ok(url);
  const anon = new Client(env); assert.equal((await anon.get(url)).status, 200);
  assert.equal((await anon.get(url.replace(/sig=[0-9a-f]{6}/, 'sig=000000'))).status, 403);
  assert.equal((await anon.get(url.replace(/exp=\d+/, 'exp=1'))).status, 403);
  assert.equal((await anon.get('/api/media/file?key=u/x&exp=9999999999&sig=abc')).status, 403);
  assert.equal(m.data.source.r2_key, undefined);                                               // internal key not leaked
});

test('import adapters: honest states, never claims access it has not verified', async () => {
  const env = makeEnv(); const c = await setupOwner(env); const p = (await c.post('/api/projects', { name: 'i' })).data.project;
  const imp = (adapter, url) => c.post('/api/media/import', { projectId: p.id, adapter, url });
  assert.equal((await imp('youtube', 'https://evil.com/watch?v=dQw4w9WgXcQ')).data.source.state, 'rejected');
  const y = await imp('youtube', 'https://youtu.be/dQw4w9WgXcQ');
  assert.equal(y.data.source.state, 'pending_configuration'); assert.deepEqual(y.data.source.missing_config, ['youtube_account']);
  assert.equal((await imp('youtube', 'https://youtu.be/dQw4w9WgXcQ')).status, 409);          // duplicate source
  assert.equal((await imp('livestream', 'https://x.example/live')).data.source.state, 'unsupported');
  assert.equal((await imp('cloud', 'http://drive.google.com/x')).data.source.state, 'unsupported');
  assert.equal((await imp('cloud', 'https://drive.google.com/file/d/1/view')).data.source.state, 'pending_configuration');
  // with a connected channel: owned video is 'authorized' but still not 'imported'
  const t = Math.floor(Date.now() / 1000);
  env.DB._raw.prepare("INSERT INTO social_accounts(id,user_id,platform,external_id,status,connected_at,updated_at) SELECT 'sa1',id,'youtube','UCmine','connected',?,? FROM users").run(t, t);
  const { saveTokens } = await import('../src/lib/tokens.js'); await saveTokens(env, 'sa1', { access: 'tok', refresh: 'r', expiresIn: 3600 });
  const mf = mockFetch([['videos?part=snippet&id=AAAAAAAAAAA', () => ({ items: [{ snippet: { channelId: 'UCmine' } }] })], ['videos?part=snippet&id=BBBBBBBBBBB', () => ({ items: [{ snippet: { channelId: 'UCother' } }] })]]);
  try {
    const own = await imp('youtube', 'https://youtu.be/AAAAAAAAAAA'); assert.equal(own.data.source.state, 'authorized'); assert.match(own.data.source.message, /not been imported/);
    const other = await imp('youtube', 'https://youtu.be/BBBBBBBBBBB'); assert.equal(other.data.source.state, 'rejected');
  } finally { mf.restore(); }
  const an = await c.post('/api/analyze', { projectId: p.id, sourceId: y.data.source.id }); assert.equal(an.status, 409);   // cannot analyse a URL-only source
});

async function seedAnalysed(env, c) {
  const p = (await c.post('/api/projects', { name: 'p' })).data.project;
  const init = await c.post('/api/media/upload/init', { projectId: p.id, filename: 'v.mp4', size: 2048 });
  await c.req('PUT', init.data.uploadUrl, bytes(2048, 3)); await c.post('/api/media/upload/complete', { sourceId: init.data.sourceId });
  return { p, sourceId: init.data.sourceId };
}
const engineResult = () => ({ media: { duration: 120, width: 1920, height: 1080, fps: 30, has_audio: true, size_bytes: 2048 }, language: 'en',
  transcript: { segments: [{ start: 21, end: 24, text: 'wait what no way!', words: [{ start: 21, end: 21.4, text: 'wait' }, { start: 21.5, end: 21.9, text: 'what' }] }] },
  moments: [1, 2, 3].map((i) => ({ start: i * 20, end: i * 20 + 25, score: 90 - i * 10, factors: { hook: 80, emotion: 70, entertainment: 60, unexpectedness: 50, shareability: 70, storytelling: 40 }, confidence: 0.8,
    explanation: 'because', moment_type: 'funny', transcript: 'wait what', suggested_title: 'Wait what', signals: { a: 1 } })) });

test('analysis flow: engine unreachable keeps job queued; cron submits, syncs and persists results; moments editing', async () => {
  const env = makeEnv({ ENGINE_URL: 'https://engine.test', ENGINE_TOKEN: 'etok', R2_ACCOUNT_ID: '', });
  const c = await setupOwner(env); const { p, sourceId } = await seedAnalysed(env, c);
  let engineUp = false; const created = [];
  const mf = mockFetch([[/engine\.test\/jobs$/, (u, init) => { if (!engineUp) throw new Error('asleep'); created.push(JSON.parse(init.body)); return jsonRes({ id: JSON.parse(init.body).id, status: 'queued' }, 202); }],
    [/engine\.test\/jobs\/j_/, () => jsonRes({ status: 'succeeded', progress: 1, result: engineResult() })]]);
  try {
    // R2 S3 creds are absent so presigning (needed to hand the file to the engine) must fail loudly, not silently skip
    Object.assign(env, { R2_ACCOUNT_ID: 'acc', R2_ACCESS_KEY_ID: 'k', R2_SECRET_ACCESS_KEY: 's' });
    const an = await c.post('/api/analyze', { projectId: p.id, sourceId, config: { max_candidates: 5 } });
    assert.equal(an.status, 202); assert.equal(an.data.job.submitted, false);
    assert.equal((await c.post('/api/analyze', { projectId: p.id, sourceId })).status, 409);       // already queued
    engineUp = true;
    const r1 = await tick(env); assert.ok(!String(r1.engine).startsWith('error'), JSON.stringify(r1));
    assert.equal(created.length, 1); assert.match(created[0].payload.source_url, /X-Amz-Signature=/); assert.equal(created[0].payload.config.max_candidates, 5);
    await tick(env);
    const job = (await c.get(`/api/jobs/${an.data.job.id}`)).data.job; assert.equal(job.status, 'succeeded');
    const mom = (await c.get(`/api/jobs/${an.data.job.id}/moments`)).data.moments;
    assert.equal(mom.length, 3); assert.equal(mom[0].rank, 1); assert.ok(mom.every((m) => m.score >= 0 && m.score <= 100 && m.explanation));
    assert.equal((await c.get(`/api/projects/${p.id}`)).data.project.status, 'analyzed');
    assert.equal((await c.get('/api/notifications')).data.notifications[0].kind, 'analysis_completed');
    assert.ok((await c.get(`/api/jobs/${an.data.job.id}/events`)).data.events.length >= 2);
    // edit
    assert.equal((await c.patch(`/api/moments/${mom[0].id}`, { start: 30, end: 31 })).status, 400);        // too short
    assert.equal((await c.patch(`/api/moments/${mom[0].id}`, { start: 30, end: 500 })).status, 400);       // beyond video
    const ed = await c.patch(`/api/moments/${mom[0].id}`, { start: 21, end: 50, selected: true }); assert.equal(ed.data.moment.edited, true);
    // merge
    const mg = await c.post('/api/moments/merge', { ids: [mom[1].id, mom[2].id] });
    assert.equal(mg.status, 200); assert.equal(mg.data.moment.start, 40); assert.equal(mg.data.moment.end, 85);
    assert.equal((await c.get(`/api/jobs/${an.data.job.id}/moments`)).data.moments.length, 2);
    assert.equal((await c.post('/api/moments/merge', { ids: [mom[0].id] })).status, 400);
  } finally { mf.restore(); }
});

test('render flow: queued clip -> engine -> verified in R2 -> ready; failures surface; preview URL only when ready', async () => {
  const env = makeEnv({ ENGINE_URL: 'https://engine.test', ENGINE_TOKEN: 'etok', R2_ACCOUNT_ID: 'acc', R2_ACCESS_KEY_ID: 'k', R2_SECRET_ACCESS_KEY: 's' });
  const c = await setupOwner(env); const { p, sourceId } = await seedAnalysed(env, c);
  const u = env.DB._raw.prepare('SELECT id FROM users').get().id; const t = 1;
  env.DB._raw.prepare("INSERT INTO processing_jobs(id,project_id,source_id,user_id,status,created_at,updated_at) VALUES('j_x1234567',?,?,?,'succeeded',?,?)").run(p.id, sourceId, u, t, t);
  await persistAnalysis(env, { id: 'j_x1234567', project_id: p.id, source_id: sourceId, user_id: u }, engineResult());
  const mid = env.DB._raw.prepare('SELECT id FROM detected_moments ORDER BY rank LIMIT 1').get().id;
  let status = 'running'; const jobs = [];
  const mf = mockFetch([[/engine\.test\/jobs$/, (url, init) => { jobs.push(JSON.parse(init.body)); return jsonRes({ id: 'x', status: 'queued' }, 202); }], [/engine\.test\/jobs\/r_/, () => jsonRes({ status, progress: 0.5, error: 'ffmpeg exploded', result: { info: { duration: 25, width: 1080, height: 1920 } } })]]);
  try {
    assert.equal((await c.post(`/api/moments/${mid}/render`, { resolution: '4k' })).status, 400);
    assert.equal((await c.post(`/api/moments/${mid}/render`, { subtitles: { mode: 'highlight', color: 'red' } })).status, 400);
    const r = await c.post(`/api/moments/${mid}/render`, { resolution: '720p', crop: { mode: 'manual', x: 0.3 }, subtitles: { mode: 'highlight' }, titleOverlay: 'Hello' });
    assert.equal(r.status, 202); const id = r.data.clipId;
    assert.equal(jobs[0].payload.request.resolution, '720p'); assert.equal(jobs[0].payload.request.crop.x, 0.3); assert.equal(jobs[0].payload.request.words.length, 2); assert.match(jobs[0].payload.output_upload_url, /X-Amz-Algorithm/);
    await tick(env); let clip = (await c.get(`/api/clips/${id}`)).data.clip; assert.equal(clip.status, 'rendering'); assert.equal(clip.previewUrl, null);
    status = 'succeeded'; await tick(env);
    clip = (await c.get(`/api/clips/${id}`)).data.clip; assert.equal(clip.status, 'failed'); assert.match(clip.error, /not in storage/);     // engine claims success but nothing landed in R2
    await env.MEDIA.put(clip.id ? `u/${u}/${p.id}/clips/${id}.mp4` : '', bytes(5000));
    assert.equal((await c.post(`/api/clips/${id}/render`)).status, 202); await tick(env);
    clip = (await c.get(`/api/clips/${id}`)).data.clip; assert.equal(clip.status, 'ready'); assert.equal(clip.size_bytes, 5000); assert.ok(clip.previewUrl && clip.downloadUrl);
    assert.equal((await c.patch(`/api/clips/${id}`, { start_s: 1, end_s: 2 })).status, 400);
    assert.equal((await c.patch(`/api/clips/${id}`, { title: 'New' })).data.needsRender, false);
    status = 'failed'; assert.equal((await c.post(`/api/clips/${id}/render`)).status, 202); await tick(env);
    assert.equal((await c.get(`/api/clips/${id}`)).data.clip.status, 'failed');
    assert.equal((await c.del(`/api/clips/${id}`)).status, 200); assert.equal(env.MEDIA._m.has(`u/${u}/${p.id}/clips/${id}.mp4`), false);
    assert.equal((await c.del(`/api/projects/${p.id}`)).status, 200); assert.equal(env.MEDIA._m.size, 0);   // project delete purges R2
  } finally { mf.restore(); }
});

test('settings: validation, timezone, notifications preferences honoured, dashboard & costguard', async () => {
  const env = makeEnv(); const c = await setupOwner(env);
  assert.equal((await c.patch('/api/settings', { timezone: 'Mars/Base' })).status, 400);
  assert.equal((await c.patch('/api/settings', { notifications: { bogus: true } })).status, 400);
  assert.equal((await c.patch('/api/settings', { retentionDays: 0 })).status, 400);
  const s = await c.patch('/api/settings', { timezone: 'America/New_York', notifications: { storage_warning: false } }); assert.equal(s.data.settings.timezone, 'America/New_York');
  const u = env.DB._raw.prepare('SELECT id FROM users').get().id; const { notify } = await import('../src/lib/notify.js');
  assert.equal(await notify(env, u, 'storage_warning', 't'), null); assert.ok(await notify(env, u, 'clip_rendered', 't'));
  const d = await c.get('/api/dashboard'); assert.equal(d.status, 200); assert.equal(d.data.storage.usedBytes, 0);
  const g = await c.get('/api/costguard'); assert.equal(g.data.engine.configured, false); assert.equal(g.data.integrations.find((i) => i.platform === 'youtube').missing.length, 2);
  assert.equal((await c.post('/api/auth/password', { current: 'wrong', next: 'another long password' })).status, 403);
  assert.equal((await c.post('/api/auth/password', { current: 'correct horse battery', next: 'another long password' })).status, 200);
});

test('unknown routes: 404/405, errors never leak internals', async () => {
  const env = makeEnv(); const c = await setupOwner(env);
  assert.equal((await c.get('/api/nope')).status, 404); assert.equal((await c.req('PUT', '/api/projects', {})).status, 405);
  env.DB.prepare = () => { throw new Error('SQL secret detail sk-abcdefghijklmnopqrstuv'); };
  const bad = await c.get('/api/projects'); assert.equal(bad.status, 500); assert.ok(!JSON.stringify(bad.data).includes('secret'));
});
