import test from 'node:test';
import assert from 'node:assert/strict';
import { makeEnv, setupOwner, mockFetch } from './helpers.js';
import { store, objectUrl, s3Configured, storageConfigured } from '../src/lib/storage.js';
import { signedSourceUrl } from '../src/lib/engine.js';

const S3 = { S3_ENDPOINT: 'https://s3.us-west-004.backblazeb2.com', S3_BUCKET: 'vc-bucket', S3_ACCESS_KEY_ID: 'keyid', S3_SECRET_ACCESS_KEY: 'secretsecret', S3_REGION: 'us-west-004' };

/** In-memory S3 behind fetch. Verifies every request is a signed (presigned) one. */
function fakeS3() {
  const objs = new Map(); const log = [];
  const routes = [[/s3\.us-west-004\.backblazeb2\.com/, async (u, init) => {
    const url = new URL(u); const method = init.method || 'GET';
    log.push({ method, path: url.pathname, query: Object.fromEntries(url.searchParams) });
    if (!url.searchParams.get('X-Amz-Signature') || !url.searchParams.get('X-Amz-Credential').includes('/us-west-004/s3/aws4_request')) return new Response('unsigned', { status: 403 });
    const parts = url.pathname.split('/').filter(Boolean); if (parts[0] !== 'vc-bucket') return new Response('NoSuchBucket', { status: 404 });
    const key = decodeURIComponent(parts.slice(1).join('/'));
    if (!key && method === 'GET' && url.searchParams.get('list-type') === '2') {
      const prefix = url.searchParams.get('prefix') || ''; const all = [...objs.keys()].filter((k) => k.startsWith(prefix)).sort(); const start = Number(url.searchParams.get('continuation-token') || 0); const page = all.slice(start, start + 2); const more = start + 2 < all.length;
      return new Response(`<?xml version="1.0"?><ListBucketResult><IsTruncated>${more}</IsTruncated>${more ? `<NextContinuationToken>${start + 2}</NextContinuationToken>` : ''}${page.map((k) => `<Contents><Key>${k.replace(/&/g, '&amp;')}</Key></Contents>`).join('')}</ListBucketResult>`, { status: 200 });
    }
    if (method === 'PUT') { objs.set(key, { data: await new Response(init.body).arrayBuffer(), ct: init.headers?.['content-type'] }); return new Response('', { status: 200, headers: { etag: '"abc123"' } }); }
    const o = objs.get(key); if (!o) return new Response('<Error><Code>NoSuchKey</Code></Error>', { status: 404 });
    if (method === 'DELETE') { objs.delete(key); return new Response(null, { status: 204 }); }
    const h = { 'content-length': String(o.data.byteLength), etag: '"abc123"', 'content-type': o.ct || 'video/mp4' };
    if (method === 'HEAD') return new Response(null, { status: 200, headers: h });
    const rg = init.headers?.range && /bytes=(\d+)-(\d+)/.exec(init.headers.range);
    if (rg) { const a = +rg[1], b = Math.min(+rg[2], o.data.byteLength - 1); return new Response(o.data.slice(a, b + 1), { status: 206, headers: { ...h, 'content-length': String(b - a + 1), 'content-range': `bytes ${a}-${b}/${o.data.byteLength}` } }); }
    return new Response(o.data, { status: 200, headers: h });
  }]];
  return { objs, log, routes };
}

test('storage selection: R2 binding wins; otherwise S3; otherwise a clear 503; keys never needed in code', () => {
  assert.equal(storageConfigured({}), false); assert.equal(s3Configured({}), false); assert.throws(() => store({}), (e) => e.status === 503 && /S3_/.test(e.message));
  const r2 = { MEDIA: {} }; assert.equal(store(r2), r2.MEDIA); assert.equal(s3Configured(S3), true); assert.equal(storageConfigured(S3), true);
  assert.throws(() => objectUrl({}, 'GET', 'k'), (e) => e.status === 503);
});

test('S3 client: put/head/get/range/list(pagination)/delete against an S3-compatible API using presigned requests', async () => {
  const env = { ...S3 }; const f = fakeS3(); const mf = mockFetch(f.routes);
  try {
    const s = store(env); const data = new Uint8Array(1000).map((_, i) => i % 256);
    assert.equal(await s.head('a/b c.mp4'), null); assert.equal(await s.get('missing'), null);
    await s.put('a/b c.mp4', data.buffer, { httpMetadata: { contentType: 'video/mp4' } });
    const h = await s.head('a/b c.mp4'); assert.equal(h.size, 1000); assert.equal(h.etag, 'abc123'); assert.equal(h.httpMetadata.contentType, 'video/mp4');
    const full = await s.get('a/b c.mp4'); assert.equal((await full.arrayBuffer()).byteLength, 1000); assert.equal(full.size, 1000);
    const r = await s.get('a/b c.mp4', { range: { offset: 10, length: 5 } }); assert.deepEqual([...new Uint8Array(await r.arrayBuffer())], [10, 11, 12, 13, 14]); assert.deepEqual(r.range, { offset: 10, length: 5 }); assert.equal(r.size, 1000);
    const hr = await s.get('a/b c.mp4', { range: new Headers({ range: 'bytes=0-3' }) }); assert.equal(hr.range.length, 4);
    // stream upload without FixedLengthStream falls back to buffering
    await s.put('s/stream.mp4', new Blob([data]).stream(), { size: 1000 }); assert.equal((await s.head('s/stream.mp4')).size, 1000);
    for (const k of ['p/1', 'p/2', 'p/3', 'p/4&5']) await s.put(k, new Uint8Array(3).buffer);
    const seen = []; let cursor; do { const l = await s.list({ prefix: 'p/', cursor }); seen.push(...l.objects.map((o) => o.key)); cursor = l.truncated ? l.cursor : undefined; } while (cursor);
    assert.deepEqual(seen, ['p/1', 'p/2', 'p/3', 'p/4&5']);                                   // pagination + XML entity decoding
    await s.delete(seen); assert.equal(await s.head('p/1'), null); await s.delete('does-not-exist');   // deleting a missing key is not an error
    assert.ok(f.log.every((x) => x.query['X-Amz-Expires'] === '300'));                         // short-lived signatures only
  } finally { mf.restore(); }
});

test('S3 errors are reported, secrets never appear in them', async () => {
  const mf = mockFetch([[/backblazeb2/, () => new Response('<Error><Code>AccessDenied</Code></Error>', { status: 403 })]]);
  try { await assert.rejects(store({ ...S3 }).put('k', new ArrayBuffer(1)), (e) => e.status === 502 && /403/.test(e.message) && !e.message.includes('secretsecret') && !e.message.includes('X-Amz-Signature')); } finally { mf.restore(); }
});

test('presigned URLs for the engine/browser use the S3 endpoint, bucket path and region', async () => {
  const u = new URL(await signedSourceUrl({ ...S3 }, 'u/1/clip.mp4', 600)); assert.equal(u.host, 's3.us-west-004.backblazeb2.com'); assert.equal(u.pathname, '/vc-bucket/u/1/clip.mp4');
  assert.match(u.searchParams.get('X-Amz-Credential'), /^keyid\/\d{8}\/us-west-004\/s3\/aws4_request$/); assert.equal(u.searchParams.get('X-Amz-Expires'), '600'); assert.ok(!u.href.includes('secretsecret'));
});

test('full flow on S3 with NO R2 binding: direct-upload URL, forced proxy upload, complete, duplicate, signed range stream, project purge', async () => {
  const f = fakeS3(); const mf = mockFetch(f.routes);
  try {
    const env = makeEnv({ ...S3 }); delete env.MEDIA; const c = await setupOwner(env); const p = (await c.post('/api/projects', { name: 'x' })).data.project;
    const d = await c.post('/api/media/upload/init', { projectId: p.id, filename: 'v.mp4', size: 4096 });
    assert.equal(d.data.mode, 'direct'); assert.match(d.data.uploadUrl, /^https:\/\/s3\.us-west-004\.backblazeb2\.com\/vc-bucket\/u\/.*X-Amz-Signature=/);       // browser would PUT straight to S3
    env.UPLOAD_MODE = 'proxy'; const bytes = new Uint8Array(4096).map((_, i) => (i * 7) % 251).buffer;
    const init = await c.post('/api/media/upload/init', { projectId: p.id, filename: 'v2.mp4', size: 4096 }); assert.equal(init.data.mode, 'proxy');
    assert.equal((await c.req('PUT', init.data.uploadUrl, bytes, { 'content-type': 'video/mp4' })).status, 200);
    assert.equal(f.objs.size, 1); assert.ok([...f.objs.values()][0].data.byteLength === 4096);
    const done = await c.post('/api/media/upload/complete', { sourceId: init.data.sourceId }); assert.equal(done.status, 200); assert.equal(done.data.source.state, 'validated');
    const init2 = await c.post('/api/media/upload/init', { projectId: p.id, filename: 'copy.mp4', size: 4096 }); await c.req('PUT', init2.data.uploadUrl, bytes);
    assert.equal((await c.post('/api/media/upload/complete', { sourceId: init2.data.sourceId })).status, 409); assert.equal(f.objs.size, 1);       // duplicate removed from S3
    const url = (await c.get(`/api/media/${init.data.sourceId}`)).data.source.previewUrl; const anon = new (c.constructor)(env);
    const full = await anon.get(url); assert.equal(full.status, 200);
    const part = await anon.get(url, { range: 'bytes=0-99' }); assert.equal(part.status, 206); assert.equal(part.headers.get('content-range'), 'bytes 0-99/4096');
    assert.equal((await anon.get(url.replace(/sig=[0-9a-f]{4}/, 'sig=0000'))).status, 403);
    assert.equal((await c.del(`/api/projects/${p.id}`)).status, 200); assert.equal(f.objs.size, 0);                                                     // list + delete purge
  } finally { mf.restore(); }
});
