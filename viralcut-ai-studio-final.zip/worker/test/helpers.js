import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { handle } from '../src/index.js';
import { b64 } from '../src/lib/crypto.js';

/** Minimal Cloudflare D1 stand-in backed by node:sqlite, running the REAL migrations. */
export function makeDb() {
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys = ON');
  const dir = new URL('../../migrations/', import.meta.url);
  for (const f of readdirSync(dir).filter((x) => x.endsWith('.sql')).sort()) db.exec(readFileSync(new URL(f, dir), 'utf8'));
  const stmt = (sql, args = []) => ({
    bind: (...a) => stmt(sql, a),
    run: async () => { const r = db.prepare(sql).run(...args); return { success: true, meta: { changes: Number(r.changes) } }; },
    first: async () => db.prepare(sql).get(...args) ?? null,
    all: async () => ({ results: db.prepare(sql).all(...args) }),
    _exec: () => { const r = db.prepare(sql).run(...args); return { success: true, meta: { changes: Number(r.changes) } }; },
  });
  return { prepare: (sql) => stmt(sql), _raw: db,
    batch: async (stmts) => { db.exec('BEGIN'); try { const out = stmts.map((s) => s._exec()); db.exec('COMMIT'); return out; } catch (e) { db.exec('ROLLBACK'); throw e; } } };
}

export function makeR2() {
  const m = new Map();
  const obj = (k) => { const v = m.get(k); return v && { key: k, size: v.data.byteLength, etag: v.etag, httpMetadata: v.meta, body: new Blob([v.data]).stream(), arrayBuffer: async () => v.data.slice(0), range: undefined }; };
  return { _m: m,
    put: async (k, body, opts) => { const buf = body instanceof ArrayBuffer ? body : body instanceof Uint8Array ? body.buffer.slice(body.byteOffset, body.byteOffset + body.byteLength) : await new Response(body).arrayBuffer();
      m.set(k, { data: buf, meta: opts?.httpMetadata, etag: 'etag' + buf.byteLength + '-' + new Uint8Array(buf).slice(0, 8).join('') }); },
    head: async (k) => { const o = obj(k); return o && { key: k, size: o.size, etag: o.etag }; },
    get: async (k, o) => { const x = obj(k); if (!x) return null; if (o?.range?.offset !== undefined) { const d = x.arrayBuffer; const full = m.get(k).data; const sl = full.slice(o.range.offset, o.range.offset + o.range.length); return { ...x, arrayBuffer: async () => sl, body: new Blob([sl]).stream(), size: full.byteLength, range: o.range }; } return x; },
    delete: async (k) => { for (const key of Array.isArray(k) ? k : [k]) m.delete(key); },
    list: async ({ prefix = '' } = {}) => ({ objects: [...m.keys()].filter((x) => x.startsWith(prefix)).map((key) => ({ key })), truncated: false }) };
}

export const KEY = b64(crypto.getRandomValues(new Uint8Array(32)));
export function makeEnv(extra = {}) {
  return { DB: makeDb(), MEDIA: makeR2(), ENCRYPTION_KEY: KEY, SETUP_TOKEN: 'setup-secret-token', APP_URL: 'https://app.test', FRONTEND_ORIGIN: 'https://app.test',
    R2_BUCKET_NAME: 'bkt', ...extra };
}

export class Client {
  constructor(env) { this.env = env; this.cookie = ''; this.csrf = ''; }
  async req(method, path, body, headers = {}) {
    const h = { origin: 'https://app.test', 'cf-connecting-ip': '1.2.3.4', ...headers };
    if (this.cookie) h.cookie = this.cookie;
    if (this.csrf && !('x-csrf-token' in h)) h['x-csrf-token'] = this.csrf;
    let b; if (body !== undefined && !(body instanceof ArrayBuffer) && typeof body !== 'string') { b = JSON.stringify(body); h['content-type'] = 'application/json'; } else { b = body; if (body instanceof ArrayBuffer) h['content-length'] = String(body.byteLength); }
    const res = await handle(new Request('https://app.test' + path, { method, headers: h, body: b }), this.env, { waitUntil() {} });
    const sc = res.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0].replace(/=$/, '=');
    const text = await res.text(); let data; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    if (data?.csrfToken) this.csrf = data.csrfToken;
    return { status: res.status, data, headers: res.headers };
  }
  get(p, h) { return this.req('GET', p, undefined, h); }
  post(p, b, h) { return this.req('POST', p, b ?? {}, h); }
  patch(p, b) { return this.req('PATCH', p, b); }
  del(p) { return this.req('DELETE', p); }
}

export async function setupOwner(env, email = 'owner@example.com', password = 'correct horse battery') {
  const c = new Client(env);
  const s = await c.post('/api/auth/setup', { email, password, setupToken: env.SETUP_TOKEN });
  if (s.status !== 201 && s.status !== 409) throw new Error('setup failed ' + JSON.stringify(s));
  const l = await c.post('/api/auth/login', { email, password });
  if (l.status !== 200) throw new Error('login failed ' + JSON.stringify(l));
  return c;
}

/** Install a fake global fetch. routes: [[matcher(string|RegExp), (url, init) => Response|object]] ; records every call. */
export function mockFetch(routes) {
  const real = globalThis.fetch; const calls = [];
  globalThis.fetch = async (url, init = {}) => {
    const u = String(url); calls.push({ url: u, init, method: init.method || 'GET' });
    for (const [m, fn] of routes) {
      if (typeof m === 'string' ? u.includes(m) : m.test(u)) {
        const r = await fn(u, init, calls);
        if (r instanceof Response) return r;
        return new Response(JSON.stringify(r), { status: 200, headers: { 'content-type': 'application/json' } });
      }
    }
    return new Response(JSON.stringify({ error: { message: 'unmocked ' + u } }), { status: 599 });
  };
  return { calls, restore: () => { globalThis.fetch = real; } };
}
export const jsonRes = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json', ...headers } });
