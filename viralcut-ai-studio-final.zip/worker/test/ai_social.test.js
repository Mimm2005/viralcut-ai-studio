import test from 'node:test';
import assert from 'node:assert/strict';
import { makeEnv, setupOwner, mockFetch, jsonRes } from './helpers.js';
import { generate } from '../src/lib/ai/gateway.js';
import { getAccessToken } from '../src/lib/tokens.js';
import { b64url, sha256b64url } from '../src/lib/crypto.js';

const addProv = (c, o = {}) => c.post('/api/ai/providers', { kind: 'gemini', model: 'gemini-test', apiKey: 'AIzaSyFAKEKEYFAKEKEYFAKEKEY1234', ...o });
const gemOk = (text, t = [10, 20]) => ({ candidates: [{ content: { parts: [{ text }] } }], usageMetadata: { promptTokenCount: t[0], candidatesTokenCount: t[1] } });

test('providers: keys are encrypted at rest, never returned, SSRF-safe, validated', async () => {
  const env = makeEnv(); const c = await setupOwner(env);
  const r = await addProv(c, { label: 'G' }); assert.equal(r.status, 201);
  assert.ok(!JSON.stringify(r.data).includes('FAKEKEY')); assert.equal(r.data.provider.keyHint, '…1234'); assert.equal(r.data.provider.isDefault, true);
  const row = env.DB._raw.prepare('SELECT api_key_enc FROM ai_providers').get(); assert.ok(!row.api_key_enc.includes('FAKEKEY') && row.api_key_enc.startsWith('v1.'));
  assert.ok(!JSON.stringify((await c.get('/api/ai/providers')).data).includes('FAKEKEY'));
  assert.equal((await addProv(c, { kind: 'custom' })).status, 400);                                  // needs base url
  assert.equal((await addProv(c, { kind: 'custom', baseUrl: 'https://169.254.169.254/v1' })).status, 400);
  assert.equal((await addProv(c, { kind: 'bogus' })).status, 400);
  assert.equal((await addProv(c, { temperature: 9 })).status, 400);
  const upd = await c.patch(`/api/ai/providers/${r.data.provider.id}`, { model: 'm2', costTier: 'free', apiKey: 'AIzaSyNEWKEYNEWKEYNEWKEYNEW9999' }); assert.equal(upd.data.provider.model, 'm2'); assert.equal(upd.data.provider.keyHint, '…9999'); assert.equal(upd.data.provider.status, 'untested');
  assert.equal((await c.del(`/api/ai/providers/${r.data.provider.id}`)).status, 200);
});

test('gateway: exact request shapes for Gemini / OpenAI / Anthropic / custom; usage + cost only when priced', async () => {
  const env = makeEnv(); const c = await setupOwner(env); const u = env.DB._raw.prepare('SELECT id FROM users').get().id;
  const mf = mockFetch([['generativelanguage.googleapis.com', () => gemOk('{"ok":1}')], ['api.openai.com/v1/chat', () => ({ choices: [{ message: { content: 'hi' } }], usage: { prompt_tokens: 5, completion_tokens: 6 } })],
    ['api.anthropic.com/v1/messages', () => ({ content: [{ type: 'text', text: 'claude says' }], usage: { input_tokens: 7, output_tokens: 8 } })], ['llm.example.org/v1/chat', () => ({ choices: [{ message: { content: 'custom' } }] })]]);
  try {
    const g = (await addProv(c, { temperature: 0.4, maxTokens: 300 })).data.provider;
    let out = await generate(env, u, { task: 'metadata', system: 'sys', prompt: 'p', json: true });
    assert.deepEqual(out.parsed, { ok: 1 });
    let call = mf.calls.at(-1); assert.match(call.url, /models\/gemini-test:generateContent$/); assert.equal(call.init.headers['x-goog-api-key'], 'AIzaSyFAKEKEYFAKEKEYFAKEKEY1234');
    let body = JSON.parse(call.init.body); assert.equal(body.generationConfig.responseMimeType, 'application/json'); assert.equal(body.generationConfig.temperature, 0.4); assert.equal(body.generationConfig.maxOutputTokens, 300); assert.equal(body.systemInstruction.parts[0].text, 'sys');
    assert.ok(!call.url.includes('AIza'));                                                              // key in header, not URL
    const o = (await addProv(c, { kind: 'openai', model: 'gpt-x', apiKey: 'sk-openaikeyopenaikey1234', maxTokens: 100, priceInPerMtokInr: 10, priceOutPerMtokInr: 20 })).data.provider;
    out = await generate(env, u, { task: 'x', prompt: 'p', providerId: o.id }); call = mf.calls.at(-1);
    assert.equal(call.url, 'https://api.openai.com/v1/chat/completions'); assert.equal(call.init.headers.authorization, 'Bearer sk-openaikeyopenaikey1234'); assert.equal(JSON.parse(call.init.body).max_completion_tokens, 100);
    const usage = env.DB._raw.prepare('SELECT * FROM ai_usage WHERE provider_id=? ORDER BY id DESC').get(o.id); assert.equal(usage.tokens_in, 5); assert.ok(Math.abs(usage.est_cost_inr - (5 * 10 + 6 * 20) / 1e6) < 1e-12);
    assert.equal(env.DB._raw.prepare('SELECT est_cost_inr e FROM ai_usage WHERE provider_id=?').get(g.id).e, null);   // unpriced => unknown, not invented
    const a = (await addProv(c, { kind: 'anthropic', model: 'claude-x', apiKey: 'sk-ant-keykeykeykey12345' })).data.provider;
    out = await generate(env, u, { task: 'x', system: 'S', prompt: 'p', providerId: a.id }); call = mf.calls.at(-1);
    assert.equal(call.init.headers['x-api-key'], 'sk-ant-keykeykeykey12345'); assert.equal(call.init.headers['anthropic-version'], '2023-06-01'); body = JSON.parse(call.init.body); assert.equal(body.system, 'S'); assert.ok(body.max_tokens > 0); assert.equal(out.text, 'claude says');
    const cu = (await addProv(c, { kind: 'custom', baseUrl: 'https://llm.example.org/v1/', model: 'llama', apiKey: 'custom-key-12345678' })).data.provider;
    out = await generate(env, u, { task: 'x', prompt: 'p', providerId: cu.id }); assert.equal(mf.calls.at(-1).url, 'https://llm.example.org/v1/chat/completions'); assert.equal(JSON.parse(mf.calls.at(-1).init.body).max_tokens, undefined);
  } finally { mf.restore(); }
});

test('Cost Guard: no provider => 409 and zero network calls; routing; no implicit paid fallback; limits block BEFORE calling', async () => {
  const env = makeEnv(); const c = await setupOwner(env); const u = env.DB._raw.prepare('SELECT id FROM users').get().id;
  const mf = mockFetch([['generativelanguage', () => jsonRes({ error: { message: 'quota exceeded for key AIzaSyFAKEKEYFAKEKEYFAKEKEY1234' } }, 429)], ['api.openai.com', () => ({ choices: [{ message: { content: 'paid answer' } }] })], ['api.anthropic.com', () => ({ content: [{ type: 'text', text: 'routed' }] })]]);
  try {
    await assert.rejects(generate(env, u, { task: 'metadata', prompt: 'p' }), (e) => e.status === 409); assert.equal(mf.calls.length, 0);
    const free = (await addProv(c, { costTier: 'free' })).data.provider;
    const paid = (await addProv(c, { kind: 'openai', model: 'gpt', apiKey: 'sk-paidpaidpaidpaid1234', costTier: 'paid' })).data.provider;
    // free default fails (quota) -> the PAID provider must NOT be used silently
    await assert.rejects(generate(env, u, { task: 'metadata', prompt: 'p' }), (e) => e.status === 502 && /All configured providers failed/.test(e.message));
    assert.ok(!mf.calls.some((x) => x.url.includes('openai')));
    const st = (await c.get('/api/ai/providers')).data.providers.find((p) => p.id === free.id); assert.equal(st.status, 'error'); assert.ok(!st.lastError.includes('AIzaSyFAKE'));   // redacted
    // explicit opt-in enables fallback
    await c.patch(`/api/ai/providers/${paid.id}`, { allowFallback: true });
    const ok = await generate(env, u, { task: 'metadata', prompt: 'p' }); assert.equal(ok.text, 'paid answer'); assert.equal(ok.usedFallback, true);
    // task routing beats default
    const cl = (await addProv(c, { kind: 'anthropic', model: 'c', apiKey: 'sk-ant-routedroutedrouted1', taskRoutes: ['reasoning'] })).data.provider;
    assert.equal((await generate(env, u, { task: 'reasoning', prompt: 'p' })).provider, 'anthropic');
    // call limit blocks before any request
    await c.patch(`/api/ai/providers/${cl.id}`, { monthlyCallLimit: 1 });
    const before = mf.calls.length; await assert.rejects(generate(env, u, { task: 'reasoning', prompt: 'p', providerId: cl.id }), (e) => /blocked/.test(e.details.join()));
    assert.equal(mf.calls.length, before);
    // budget limit
    await c.patch(`/api/ai/providers/${paid.id}`, { monthlyBudgetInr: 0.0000001, priceInPerMtokInr: 1e6, priceOutPerMtokInr: 1e6 });
    env.DB._raw.prepare('INSERT INTO ai_usage(provider_id,task,est_cost_inr,ok,created_at) VALUES(?,?,?,1,?)').run(paid.id, 't', 5, Math.floor(Date.now() / 1000));
    await assert.rejects(generate(env, u, { task: 'x', prompt: 'p', providerId: paid.id }), (e) => /budget/.test(e.details.join()));
    // paused provider is never used
    await c.patch(`/api/ai/providers/${free.id}`, { paused: true });
    assert.ok(!(await import('../src/lib/ai/gateway.js')).pickChain(env.DB._raw.prepare('SELECT * FROM ai_providers').all(), 'metadata').some((p) => p.id === free.id));
    const cg = (await c.get('/api/costguard')).data; assert.ok(cg.providers.some((p) => p.warnings.length));
    assert.equal((await c.post('/api/ai/providers/test', { id: paid.id })).status, 409);
  } finally { mf.restore(); }
});

test('metadata: AI generation -> normalised per platform, template mode labelled, regenerate fields, edit freezes on approval', async () => {
  const env = makeEnv(); const c = await setupOwner(env); const u = env.DB._raw.prepare('SELECT id FROM users').get().id;
  const t = 1; env.DB._raw.prepare("INSERT INTO projects(id,user_id,name,created_at,updated_at) VALUES('p1',?,'x',1,1)").run(u);
  env.DB._raw.prepare("INSERT INTO source_media(id,project_id,user_id,adapter,state,created_at,updated_at) VALUES('s1','p1',?,'upload','imported',1,1)").run(u);
  env.DB._raw.prepare("INSERT INTO generated_clips(id,user_id,project_id,source_id,title,start_s,end_s,status,r2_key,created_at,updated_at) VALUES('c_clip0001',?,'p1','s1','Funny bit',0,20,'ready','k',1,1)").run(u);
  assert.equal((await c.post('/api/metadata/generate', { clipId: 'c_clip0001', platforms: ['youtube'] })).status, 409);       // no provider configured: explicit, no silent call
  const tm = await c.post('/api/metadata/generate', { clipId: 'c_clip0001', platforms: ['youtube', 'instagram'], mode: 'template' });
  assert.equal(tm.status, 200); assert.ok(tm.data.metadata.every((m) => m.source === 'template' && m.provider === null));
  await addProv(c);
  let n = 0;
  const mf = mockFetch([['generativelanguage', () => gemOk(JSON.stringify(n++ === 0
    ? { title: 'T'.repeat(160), title_alternatives: ['a', 'b', 'c'], description: 'Desc #Shorts', tags: ['x', 'y'], hashtags: ['#fun', 'Shorts'], category: '23' }
    : { caption: 'cap', hashtags: Array.from({ length: 50 }, (_, i) => 'h' + i), tags: ['ignored'] }))]]);
  try {
    const g = await c.post('/api/metadata/generate', { clipId: 'c_clip0001', platforms: ['youtube'], language: 'hi' });
    const yt = g.data.metadata[0]; assert.equal(yt.title.length, 100); assert.equal(yt.source, 'ai'); assert.equal(yt.provider, 'gemini'); assert.equal(yt.language, 'hi'); assert.deepEqual(yt.titleAlternatives, ['a', 'b', 'c']); assert.ok(g.data.metadata[0].warnings.some((w) => /truncated/.test(w)));
    assert.match(JSON.parse(mf.calls[0].init.body).contents[0].parts[0].text, /Language: hi/);
    const ig = (await c.post('/api/metadata/generate', { clipId: 'c_clip0001', platforms: ['instagram'] })).data.metadata[0]; assert.equal(ig.hashtags.length, 30); assert.deepEqual(ig.tags, []);
    const ed = await c.patch(`/api/metadata/${ig.id}`, { caption: 'my own words', hashtags: ['#a', '#b'] }); assert.equal(ed.data.metadata.source, 'manual'); assert.deepEqual(ed.data.metadata.hashtags, ['a', 'b']);
    assert.equal((await c.patch(`/api/metadata/${ig.id}`, { caption: 'x'.repeat(10001) })).status, 400);
    assert.ok((await c.get('/api/metadata/c_clip0001')).data.metadata.length === 2);
    env.DB._raw.prepare("INSERT INTO social_accounts(id,user_id,platform,status,connected_at,updated_at) VALUES('sa',?,'instagram','connected',1,1)").run(u);
    env.DB._raw.prepare("INSERT INTO publishing_jobs(id,user_id,clip_id,metadata_id,account_id,platform,status,created_at,updated_at) VALUES('pj_frozen1',?,'c_clip0001',?,'sa','instagram','scheduled',1,1)").run(u, ig.id);
    assert.equal((await c.patch(`/api/metadata/${ig.id}`, { caption: 'sneaky change' })).status, 409);
  } finally { mf.restore(); }
});

// ---------------- social OAuth ----------------
const SOCIAL_ENV = { GOOGLE_CLIENT_ID: 'gid', GOOGLE_CLIENT_SECRET: 'gsec', META_APP_ID: 'mid', META_APP_SECRET: 'msec', TIKTOK_CLIENT_KEY: 'tk', TIKTOK_CLIENT_SECRET: 'ts', X_CLIENT_ID: 'xid', X_CLIENT_SECRET: 'xs' };
const ytMocks = () => [['oauth2.googleapis.com/token', (u, init) => jsonRes({ access_token: 'ya29.ACCESSTOKENVALUE1234567', refresh_token: 'REFRESHTOKENVALUE1234567', expires_in: 3600, scope: 'https://www.googleapis.com/auth/youtube.upload' })],
  ['channels?part=snippet&mine=true', () => ({ items: [{ id: 'UC123', snippet: { title: 'My Channel', customUrl: '@me' } }] })]];
const qs = (loc) => Object.fromEntries(new URL(loc).searchParams);

test('social: unconfigured platforms are "pending_configuration", never connected', async () => {
  const env = makeEnv(); const c = await setupOwner(env); const a = (await c.get('/api/social/accounts')).data.accounts;
  assert.equal(a.length, 5); assert.ok(a.every((x) => x.status === 'pending_configuration' && x.missingConfig.length && x.setupGuide && x.redirectUri.startsWith('https://app.test/api/social/')));
  assert.equal((await c.get('/api/social/youtube/connect')).status, 409); assert.equal((await c.get('/api/social/myspace/connect')).status, 400);
});

test('OAuth (YouTube): PKCE + state, one-time state, session binding, tokens encrypted, granted scopes recorded, disconnect', async () => {
  const env = makeEnv(SOCIAL_ENV); const c = await setupOwner(env);
  const con = await c.get('/api/social/youtube/connect'); assert.equal(con.status, 302);
  const loc = con.headers.get('location'); const q = qs(loc); assert.match(loc, /^https:\/\/accounts\.google\.com\//);
  assert.equal(q.redirect_uri, 'https://app.test/api/social/youtube/callback'); assert.equal(q.code_challenge_method, 'S256'); assert.equal(q.access_type, 'offline');
  const st = env.DB._raw.prepare('SELECT * FROM oauth_states').get(); assert.equal(q.state, st.state); assert.equal(q.code_challenge, await sha256b64url(st.code_verifier));
  assert.ok(q.scope.includes('youtube.upload') && !q.scope.includes('youtube.force-ssl'));       // least privilege: no broader write scope
  // callback with a forged state
  let r = await c.get('/api/social/youtube/callback?state=forged&code=abc'); assert.match(r.headers.get('location'), /error=invalid_or_expired_state/);
  // callback without the owner's session
  const anon = new (c.constructor)(env); r = await anon.get(`/api/social/youtube/callback?state=${st.state}&code=abc`); assert.match(r.headers.get('location'), /error=session_mismatch/);
  assert.equal(env.DB._raw.prepare('SELECT COUNT(*) n FROM oauth_states').get().n, 0);           // consumed even on failure
  const q2 = qs((await c.get('/api/social/youtube/connect')).headers.get('location'));
  const mf = mockFetch(ytMocks());
  try {
    r = await c.get(`/api/social/youtube/callback?state=${q2.state}&code=THECODE`); assert.match(r.headers.get('location'), /#\/accounts\?connected=youtube/);
    const tokenCall = mf.calls.find((x) => x.url.includes('oauth2.googleapis.com/token')); assert.match(tokenCall.init.body, /code_verifier=/); assert.match(tokenCall.init.body, /code=THECODE/);
    // replay
    r = await c.get(`/api/social/youtube/callback?state=${q2.state}&code=THECODE`); assert.match(r.headers.get('location'), /error=/);
  } finally { mf.restore(); }
  const raw = JSON.stringify(env.DB._raw.prepare('SELECT * FROM oauth_tokens').all()); assert.ok(!raw.includes('ACCESSTOKENVALUE') && !raw.includes('REFRESHTOKENVALUE'));
  const acc = (await c.get('/api/social/accounts')).data.accounts.find((a) => a.platform === 'youtube'); assert.equal(acc.status, 'connected'); assert.equal(acc.account.displayName, 'My Channel'); assert.deepEqual(acc.account.grantedScopes, ['https://www.googleapis.com/auth/youtube.upload']);
  assert.ok(!JSON.stringify(acc).includes('ya29'));
  // pending post blocks disconnect unless explicitly cancelled
  const u = env.DB._raw.prepare('SELECT id FROM users').get().id; const aid = env.DB._raw.prepare('SELECT id FROM social_accounts').get().id;
  env.DB._raw.prepare("INSERT INTO projects(id,user_id,name,created_at,updated_at) VALUES('p1',?,'x',1,1)").run(u);
  env.DB._raw.prepare("INSERT INTO source_media(id,project_id,user_id,adapter,state,created_at,updated_at) VALUES('s1','p1',?,'upload','imported',1,1)").run(u);
  env.DB._raw.prepare("INSERT INTO generated_clips(id,user_id,project_id,source_id,start_s,end_s,created_at,updated_at) VALUES('c1',?,'p1','s1',0,10,1,1)").run(u);
  env.DB._raw.prepare("INSERT INTO clip_metadata(id,clip_id,platform,created_at,updated_at) VALUES('m1','c1','youtube',1,1)").run();
  env.DB._raw.prepare("INSERT INTO publishing_jobs(id,user_id,clip_id,metadata_id,account_id,platform,status,created_at,updated_at) VALUES('pj1',?,'c1','m1',?,'youtube','scheduled',1,1)").run(u, aid);
  const mf2 = mockFetch([['oauth2.googleapis.com/revoke', () => ({})]]);
  try {
    assert.equal((await c.del('/api/social/youtube/disconnect')).status, 409);
    assert.equal((await c.del('/api/social/youtube/disconnect?cancelPending=1')).status, 200); assert.ok(mf2.calls.some((x) => x.url.includes('revoke')));
  } finally { mf2.restore(); }
  assert.equal(env.DB._raw.prepare("SELECT status FROM publishing_jobs WHERE id='pj1'").get().status, 'cancelled'); assert.equal(env.DB._raw.prepare('SELECT COUNT(*) n FROM oauth_tokens').get().n, 0);
  assert.equal((await c.get('/api/social/accounts')).data.accounts.find((a) => a.platform === 'youtube').status, 'disconnected');
});

test('OAuth (Instagram via Meta): resolves IG business account from Page; refuses when none linked; Facebook picks Page token', async () => {
  const env = makeEnv(SOCIAL_ENV); const c = await setupOwner(env);
  const meta = (pages) => [['/oauth/access_token', (u) => jsonRes({ access_token: u.includes('fb_exchange_token') ? 'LONGUSERTOKEN123456' : 'SHORTTOKEN12345678' })], ['/me/permissions', () => ({ data: [{ permission: 'instagram_content_publish', status: 'granted' }, { permission: 'pages_show_list', status: 'granted' }, { permission: 'read_insights', status: 'declined' }] })], ['/me/accounts', () => ({ data: pages })]];
  const run = async (platform, pages) => { const q = qs((await c.get(`/api/social/${platform}/connect`)).headers.get('location')); assert.equal(q.code_challenge, undefined); const mf = mockFetch(meta(pages)); try { return (await c.get(`/api/social/${platform}/callback?state=${q.state}&code=C`)).headers.get('location'); } finally { mf.restore(); } };
  assert.match(await run('instagram', [{ id: 'PG1', name: 'Page', access_token: 'PAGETOKEN123456789' }]), /error=.*Instagram/);
  assert.match(await run('instagram', [{ id: 'PG1', name: 'Page', access_token: 'PAGETOKEN123456789', instagram_business_account: { id: 'IG9', username: 'creator' } }]), /connected=instagram/);
  const a = env.DB._raw.prepare("SELECT * FROM social_accounts WHERE platform='instagram'").get(); assert.equal(a.external_id, 'IG9'); assert.deepEqual(JSON.parse(a.extra), { pageId: 'PG1', igUserId: 'IG9' }); assert.deepEqual(JSON.parse(a.scopes), ['instagram_content_publish', 'pages_show_list']);   // declined scope not recorded
  assert.match(await run('facebook', [{ id: 'PG1', name: 'Page', access_token: 'PAGETOKEN123456789' }]), /connected=facebook/);
  assert.match(await run('facebook', []), /error=.*Pages/);
});

test('tokens: refreshes before expiry, keeps old refresh token, marks account expired on revocation and notifies', async () => {
  const env = makeEnv(SOCIAL_ENV); const c = await setupOwner(env); const u = env.DB._raw.prepare('SELECT id FROM users').get().id; const { saveTokens } = await import('../src/lib/tokens.js');
  env.DB._raw.prepare("INSERT INTO social_accounts(id,user_id,platform,status,connected_at,updated_at) VALUES('sa',?,'youtube','connected',1,1)").run(u);
  await saveTokens(env, 'sa', { access: 'OLDACCESSTOKEN12345', refresh: 'REFRESHKEEP12345678', expiresIn: 100 });                // expires in <5 min
  let revoked = false; const mf = mockFetch([['oauth2.googleapis.com/token', (url, init) => revoked ? jsonRes({ error: 'invalid_grant', error_description: 'Token has been expired or revoked.' }, 400) : jsonRes({ access_token: 'NEWACCESSTOKEN12345', expires_in: 3600 })]]);
  try {
    const acc = env.DB._raw.prepare("SELECT * FROM social_accounts WHERE id='sa'").get();
    assert.equal(await getAccessToken(env, acc), 'NEWACCESSTOKEN12345'); assert.match(mf.calls[0].init.body, /refresh_token=REFRESHKEEP12345678/);
    assert.equal(await getAccessToken(env, acc), 'NEWACCESSTOKEN12345'); assert.equal(mf.calls.length, 1);                              // fresh: no second refresh
    assert.ok(env.DB._raw.prepare('SELECT refresh_token_enc FROM oauth_tokens').get().refresh_token_enc);                               // old refresh token retained
    env.DB._raw.prepare('UPDATE oauth_tokens SET expires_at=1').run(); revoked = true;
    await assert.rejects(getAccessToken(env, acc), (e) => e.tokenExpired === true);
    assert.equal(env.DB._raw.prepare("SELECT status FROM social_accounts WHERE id='sa'").get().status, 'expired');
    assert.equal(env.DB._raw.prepare("SELECT kind FROM notifications WHERE kind='token_expired'").get().kind, 'token_expired');
    assert.equal((await c.get('/api/social/accounts')).data.accounts.find((a) => a.platform === 'youtube').status, 'expired');
  } finally { mf.restore(); }
});
