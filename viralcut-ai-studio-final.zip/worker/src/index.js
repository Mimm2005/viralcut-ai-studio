import { Router } from './lib/router.js';
import { HttpError, json, corsHeaders, SECURITY_HEADERS } from './lib/http.js';
import { loadSession, checkCsrf } from './lib/auth.js';
import { redact } from './lib/crypto.js';
import { tick } from './lib/scheduler.js';
import { register as auth } from './routes/auth.js';
import { register as settings } from './routes/settings.js';
import { register as projects } from './routes/projects.js';
import { register as ai } from './routes/ai.js';
import { register as social } from './routes/social.js';
import { register as publishing } from './routes/publishing.js';
import { register as analytics } from './routes/analytics.js';

export const router = new Router();
for (const m of [auth, settings, projects, ai, social, publishing, analytics]) m(router);
router.get('/api/health', async () => json({ ok: true, time: Math.floor(Date.now() / 1000) }), { auth: false });

export async function handle(req, env, ctxExec) {
  const url = new URL(req.url);
  const cors = corsHeaders(env, req);
  const finish = (res) => { const h = new Headers(res.headers); for (const [k, v] of Object.entries({ ...SECURITY_HEADERS, ...cors })) if (!h.has(k)) h.set(k, v); return new Response(res.body, { status: res.status, headers: h }); };
  if (req.method === 'OPTIONS') return finish(new Response(null, { status: 204 }));
  try {
    if (env.REQUIRE_HTTPS !== 'false' && url.protocol === 'http:' && !['localhost', '127.0.0.1'].includes(url.hostname)) {
      return finish(new Response(null, { status: 308, headers: { location: url.href.replace('http:', 'https:') } }));
    }
    const { route, params, methodNotAllowed } = router.match(req.method, url.pathname);
    if (!route) throw new HttpError(methodNotAllowed ? 405 : 404, methodNotAllowed ? 'Method not allowed' : 'Not found');
    const session = await loadSession(env, req);
    if (route.opts.auth !== false && !session) throw new HttpError(401, 'Authentication required');
    if (route.opts.csrf !== false && session) checkCsrf(env, req, session);
    const res = await route.handler({ env, req, url, params, session, waitUntil: ctxExec?.waitUntil?.bind(ctxExec) });
    return finish(res);
  } catch (e) {
    if (e instanceof HttpError) {
      const h = e.retryAfter ? { 'retry-after': String(e.retryAfter) } : {};
      return finish(json({ error: e.message, details: e.details }, e.status, h));
    }
    console.error('unhandled', redact(e.stack || e.message));
    return finish(json({ error: 'Internal error' }, 500));          // never leak internals or secrets
  }
}

export default {
  fetch: (req, env, ctx) => handle(req, env, ctx),
  // Cron Trigger: persistent scheduler. Survives restarts because all state lives in D1.
  async scheduled(event, env, ctx) { ctx.waitUntil(tick(env, event.cron === '*/5 * * * *' ? 'slow' : 'fast')); },
};
