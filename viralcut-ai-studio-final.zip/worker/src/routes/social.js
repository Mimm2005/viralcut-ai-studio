import { json, now, uid, HttpError, conflict, badRequest } from '../lib/http.js';
import { requireUser, allowedOrigins } from '../lib/auth.js';
import { randomToken, sha256b64url } from '../lib/crypto.js';
import { ADAPTERS, adapter, missingConfig } from '../lib/social/index.js';
import { saveTokens } from '../lib/tokens.js';
import { PLATFORMS } from '../lib/validate.js';
import { audit } from '../lib/audit.js';
import { redact } from '../lib/crypto.js';
import { rateLimit } from '../lib/ratelimit.js';

const SETUP_DOCS = { youtube: 'docs/YOUTUBE_INTEGRATION.md', instagram: 'docs/META_INTEGRATION.md', facebook: 'docs/META_INTEGRATION.md', tiktok: 'docs/TIKTOK_INTEGRATION.md', x: 'docs/X_INTEGRATION.md' };
const redirectUri = (env, p) => `${env.APP_URL.replace(/\/$/, '')}/api/social/${p}/callback`;
const home = (env) => (env.FRONTEND_ORIGIN || env.APP_URL).replace(/\/$/, '');

export function register(r) {
  r.get('/api/social/accounts', async (ctx) => {
    const u = requireUser(ctx);
    const { results } = await ctx.env.DB.prepare('SELECT a.*, t.expires_at FROM social_accounts a LEFT JOIN oauth_tokens t ON t.account_id=a.id WHERE a.user_id=?').bind(u.id).all();
    const by = Object.fromEntries(results.map((a) => [a.platform, a]));
    return json({ accounts: PLATFORMS.map((p) => {
      const ad = ADAPTERS[p], a = by[p], missing = missingConfig(ctx.env, p);
      // 'pending_configuration': this deployment has no developer-app credentials yet. Never shown as connected.
      const live = a && a.status !== 'revoked' ? a : null;
      const status = missing.length ? 'pending_configuration' : live ? live.status : 'disconnected';
      return { platform: p, label: ad.label, status, missingConfig: missing, setupGuide: SETUP_DOCS[p], capabilities: ad.capabilities, notes: ad.notes, requestedScopes: ad.scopes, redirectUri: redirectUri(ctx.env, p),
        account: live ? { displayName: live.display_name, handle: live.handle, avatar: live.avatar_url, grantedScopes: JSON.parse(live.scopes || '[]'), connectedAt: live.connected_at, tokenExpiresAt: live.expires_at, lastError: live.last_error } : null };
    }) });
  });

  // GET so the browser can navigate here; the Worker 302s to the provider's consent screen.
  r.get('/api/social/:platform/connect', async (ctx) => {
    const u = requireUser(ctx); const p = ctx.params.platform;
    if (!PLATFORMS.includes(p)) throw badRequest('Unknown platform');
    await rateLimit(ctx.env, `oauth:${u.id}`, 20, 3600);
    const miss = missingConfig(ctx.env, p);
    if (miss.length) throw new HttpError(409, `Not configured: set ${miss.join(', ')} (see ${SETUP_DOCS[p]})`);
    const ad = adapter(p); const state = randomToken(24); const verifier = ad.usesPkce ? randomToken(48) : null;
    await ctx.env.DB.prepare('INSERT INTO oauth_states(state,user_id,platform,code_verifier,expires_at) VALUES(?,?,?,?,?)').bind(state, u.id, p, verifier, now() + 600).run();
    const url = ad.authUrl(ctx.env, { state, redirectUri: redirectUri(ctx.env, p), challenge: verifier ? await sha256b64url(verifier) : undefined });
    return new Response(null, { status: 302, headers: { location: url } });
  });

  r.get('/api/social/:platform/callback', async (ctx) => {
    const { env, url, params, session } = ctx; const p = params.platform;
    const back = (q) => new Response(null, { status: 302, headers: { location: `${home(env)}/#/accounts?${q}` } });
    if (!PLATFORMS.includes(p)) return back('error=unknown_platform');
    const state = url.searchParams.get('state'), code = url.searchParams.get('code'), err = url.searchParams.get('error');
    if (!state) return back('error=missing_state');
    const st = await env.DB.prepare('SELECT * FROM oauth_states WHERE state=?').bind(state).first();
    await env.DB.prepare('DELETE FROM oauth_states WHERE state=?').bind(state).run();                // one-time use
    if (!st || st.expires_at < now() || st.platform !== p) return back('error=invalid_or_expired_state');
    if (!session || session.user.id !== st.user_id) return back('error=session_mismatch');
    if (err) return back(`error=${encodeURIComponent(redact(err).slice(0, 80))}`);
    if (!code) return back('error=missing_code');
    try {
      const r2 = await adapter(p).exchangeCode(env, { code, redirectUri: redirectUri(env, p), verifier: st.code_verifier });
      const a = r2.account, t = now();
      const existing = await env.DB.prepare('SELECT id FROM social_accounts WHERE user_id=? AND platform=?').bind(st.user_id, p).first();
      const id = existing?.id || uid('sa_');
      await env.DB.prepare(`INSERT INTO social_accounts(id,user_id,platform,external_id,display_name,handle,avatar_url,status,scopes,extra,connected_at,updated_at) VALUES(?,?,?,?,?,?,?,'connected',?,?,?,?)
        ON CONFLICT(user_id,platform) DO UPDATE SET external_id=excluded.external_id, display_name=excluded.display_name, handle=excluded.handle, avatar_url=excluded.avatar_url, status='connected', scopes=excluded.scopes, extra=excluded.extra, last_error=NULL, updated_at=excluded.updated_at`)
        .bind(id, st.user_id, p, a.externalId, a.displayName, a.handle, a.avatar, JSON.stringify(r2.scopes || []), JSON.stringify(a.extra || {}), t, t).run();
      await saveTokens(env, id, r2);
      await audit(env, st.user_id, 'social.connect', p, ctx.req, { scopes: r2.scopes });
      return back(`connected=${p}`);
    } catch (e) {
      await audit(env, st.user_id, 'social.connect_failed', p, ctx.req, { error: redact(e.message).slice(0, 200) });
      return back(`error=${encodeURIComponent(redact(e.message).slice(0, 120))}`);
    }
  }, { auth: false });

  r.delete('/api/social/:platform/disconnect', async (ctx) => {
    const u = requireUser(ctx); const p = ctx.params.platform;
    const a = await ctx.env.DB.prepare('SELECT * FROM social_accounts WHERE user_id=? AND platform=?').bind(u.id, p).first();
    if (!a) throw new HttpError(404, 'Not connected');
    const live = await ctx.env.DB.prepare("SELECT COUNT(*) n FROM publishing_jobs WHERE account_id=? AND status IN ('approved','scheduled','publishing','needs_verification')").bind(a.id).first();
    if (live.n && ctx.url.searchParams.get('cancelPending') !== '1') throw conflict(`${live.n} scheduled post(s) use this account. Retry with ?cancelPending=1 to cancel them.`, { pending: live.n });
    if (p === 'youtube') {   // best-effort revoke at Google
      try { const { decryptSecret } = await import('../lib/crypto.js'); const row = await ctx.env.DB.prepare('SELECT access_token_enc FROM oauth_tokens WHERE account_id=?').bind(a.id).first();
        if (row) await fetch('https://oauth2.googleapis.com/revoke', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'token=' + encodeURIComponent(await decryptSecret(ctx.env, row.access_token_enc, `tok:${a.id}:a`)) }); } catch { /* local removal still proceeds */ }
    }
    await ctx.env.DB.batch([
      ctx.env.DB.prepare("UPDATE publishing_jobs SET status='cancelled', error='account disconnected', updated_at=? WHERE account_id=? AND status IN ('approved','scheduled','publishing','needs_verification')").bind(now(), a.id),
      ctx.env.DB.prepare('DELETE FROM oauth_tokens WHERE account_id=?').bind(a.id),
      // soft-revoke: keep the row so published-post history and analytics survive a disconnect
      ctx.env.DB.prepare("UPDATE social_accounts SET status='revoked', scopes='[]', last_error=NULL, updated_at=? WHERE id=?").bind(now(), a.id)]);
    await audit(ctx.env, u.id, 'social.disconnect', p, ctx.req);
    return json({ ok: true });
  });
}
