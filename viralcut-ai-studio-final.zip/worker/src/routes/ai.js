import { json, readJson, now, uid, HttpError, conflict, badRequest, notFound } from '../lib/http.js';
import { validate, ID, PLATFORMS } from '../lib/validate.js';
import { requireUser, owned } from '../lib/auth.js';
import { encryptSecret } from '../lib/crypto.js';
import { validateBaseUrl } from '../lib/ai/providers.js';
import { generate, usageThisMonth, TASKS, guardReason } from '../lib/ai/gateway.js';
import { buildPrompt, coerceAiOutput, normalizeMetadata, templateMetadata, SPECS } from '../lib/metadata.js';
import { notify } from '../lib/notify.js';
import { audit } from '../lib/audit.js';
import { rateLimit } from '../lib/ratelimit.js';

const J = (s, d) => { try { return JSON.parse(s) ?? d; } catch { return d; } };
const pub = (p, usage) => ({ id: p.id, kind: p.kind, label: p.label, baseUrl: p.base_url, model: p.model, keyHint: p.key_hint ? `…${p.key_hint}` : null, temperature: p.temperature, maxTokens: p.max_tokens,
  costTier: p.cost_tier, isDefault: !!p.is_default, allowFallback: !!p.allow_fallback, taskRoutes: J(p.task_routes, []), monthlyCallLimit: p.monthly_call_limit, monthlyBudgetInr: p.monthly_budget_inr,
  priceInPerMtokInr: p.price_in_per_mtok_inr, priceOutPerMtokInr: p.price_out_per_mtok_inr, status: p.status, lastError: p.last_error, lastTestedAt: p.last_tested_at, usage });
export const metaRow = (m) => ({ id: m.id, clipId: m.clip_id, platform: m.platform, title: m.title, titleAlternatives: J(m.title_alternatives, []), description: m.description, caption: m.caption, hashtags: J(m.hashtags, []),
  tags: J(m.tags, []), category: m.category, language: m.language, privacy: m.privacy, coverRecommendation: m.cover_recommendation, source: m.source, provider: m.provider, model: m.model, updatedAt: m.updated_at });

const PROV_SPEC = { kind: { type: 'string', enum: ['gemini', 'openai', 'anthropic', 'custom'] }, label: { type: 'string', max: 60 }, baseUrl: { type: 'string', max: 300 }, model: { type: 'string', max: 100 },
  apiKey: { type: 'string', max: 400, trim: true }, temperature: { type: 'number', min: 0, max: 2 }, maxTokens: { type: 'integer', min: 64, max: 32000 }, costTier: { type: 'string', enum: ['free', 'paid', 'unknown'] },
  isDefault: { type: 'boolean' }, allowFallback: { type: 'boolean' }, taskRoutes: { type: 'array', max: 8, items: { type: 'string', enum: TASKS } }, monthlyCallLimit: { type: 'integer', min: 1 },
  monthlyBudgetInr: { type: 'number', min: 0 }, priceInPerMtokInr: { type: 'number', min: 0 }, priceOutPerMtokInr: { type: 'number', min: 0 }, paused: { type: 'boolean' } };

export function register(r) {
  r.get('/api/ai/providers', async (ctx) => {
    const u = requireUser(ctx);
    const { results } = await ctx.env.DB.prepare('SELECT * FROM ai_providers WHERE user_id=? ORDER BY created_at').bind(u.id).all();
    const out = []; for (const p of results) out.push(pub(p, await usageThisMonth(ctx.env, p.id)));
    return json({ providers: out, tasks: TASKS });     // api keys are never returned
  });

  r.post('/api/ai/providers', async (ctx) => {
    const u = requireUser(ctx);
    const b = validate(await readJson(ctx.req), { ...PROV_SPEC, kind: { ...PROV_SPEC.kind, required: true }, model: { ...PROV_SPEC.model, required: true }, apiKey: { ...PROV_SPEC.apiKey, required: true } });
    if (b.kind === 'custom' && !b.baseUrl) throw badRequest('Custom providers need a base URL');
    const baseUrl = b.baseUrl ? validateBaseUrl(b.baseUrl) : null;
    const id = uid('ap_'), t = now();
    const cnt = await ctx.env.DB.prepare('SELECT COUNT(*) n FROM ai_providers WHERE user_id=?').bind(u.id).first();
    if (cnt.n >= 10) throw conflict('Provider limit reached');
    const isDefault = b.isDefault ?? cnt.n === 0;
    const stmts = [];
    if (isDefault) stmts.push(ctx.env.DB.prepare('UPDATE ai_providers SET is_default=0 WHERE user_id=?').bind(u.id));
    stmts.push(ctx.env.DB.prepare(`INSERT INTO ai_providers(id,user_id,kind,label,base_url,model,api_key_enc,key_hint,temperature,max_tokens,cost_tier,is_default,allow_fallback,task_routes,monthly_call_limit,monthly_budget_inr,price_in_per_mtok_inr,price_out_per_mtok_inr,status,created_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(id, u.id, b.kind, b.label || b.kind, baseUrl, b.model, await encryptSecret(ctx.env, b.apiKey, `ai:${id}`), b.apiKey.slice(-4), b.temperature ?? null, b.maxTokens ?? null,
      b.costTier || 'unknown', +isDefault, +(b.allowFallback || false), JSON.stringify(b.taskRoutes || []), b.monthlyCallLimit ?? null, b.monthlyBudgetInr ?? null, b.priceInPerMtokInr ?? null, b.priceOutPerMtokInr ?? null, 'untested', t, t));
    await ctx.env.DB.batch(stmts);
    await audit(ctx.env, u.id, 'ai.provider_add', id, ctx.req, { kind: b.kind, model: b.model });
    return json({ provider: pub(await ctx.env.DB.prepare('SELECT * FROM ai_providers WHERE id=?').bind(id).first(), await usageThisMonth(ctx.env, id)) }, 201);
  });

  r.patch('/api/ai/providers/:id', async (ctx) => {
    const u = requireUser(ctx); const p = await owned(ctx.env, 'ai_providers', ctx.params.id, u.id);
    const { kind, ...spec } = PROV_SPEC; const b = validate(await readJson(ctx.req), spec);
    const sets = [], vals = [];
    const col = { label: 'label', model: 'model', temperature: 'temperature', maxTokens: 'max_tokens', costTier: 'cost_tier', monthlyCallLimit: 'monthly_call_limit', monthlyBudgetInr: 'monthly_budget_inr', priceInPerMtokInr: 'price_in_per_mtok_inr', priceOutPerMtokInr: 'price_out_per_mtok_inr' };
    for (const [k, c] of Object.entries(col)) if (b[k] !== undefined) { sets.push(`${c}=?`); vals.push(b[k]); }
    if (b.baseUrl !== undefined) { if (p.kind !== 'custom' && p.kind !== 'openai') throw badRequest('Base URL only applies to OpenAI-compatible providers'); sets.push('base_url=?'); vals.push(validateBaseUrl(b.baseUrl)); }
    if (b.allowFallback !== undefined) { sets.push('allow_fallback=?'); vals.push(+b.allowFallback); }
    if (b.taskRoutes !== undefined) { sets.push('task_routes=?'); vals.push(JSON.stringify(b.taskRoutes)); }
    if (b.apiKey) { sets.push('api_key_enc=?', 'key_hint=?', "status='untested'", 'last_error=NULL'); vals.push(await encryptSecret(ctx.env, b.apiKey, `ai:${p.id}`), b.apiKey.slice(-4)); }
    if (b.paused !== undefined) { sets.push('status=?'); vals.push(b.paused ? 'paused' : 'untested'); }
    const stmts = [];
    if (b.isDefault) { stmts.push(ctx.env.DB.prepare('UPDATE ai_providers SET is_default=0 WHERE user_id=?').bind(u.id)); sets.push('is_default=1'); }
    if (sets.length) stmts.push(ctx.env.DB.prepare(`UPDATE ai_providers SET ${sets.join(',')}, updated_at=? WHERE id=?`).bind(...vals, now(), p.id));
    if (stmts.length) await ctx.env.DB.batch(stmts);
    await audit(ctx.env, u.id, 'ai.provider_update', p.id, ctx.req, Object.keys(b).filter((k) => k !== 'apiKey'));
    return json({ provider: pub(await ctx.env.DB.prepare('SELECT * FROM ai_providers WHERE id=?').bind(p.id).first(), await usageThisMonth(ctx.env, p.id)) });
  });

  r.post('/api/ai/providers/test', async (ctx) => {
    const u = requireUser(ctx); await rateLimit(ctx.env, `aitest:${u.id}`, 10, 3600);
    const b = validate(await readJson(ctx.req), { id: { type: 'string', required: true, pattern: ID } });
    const p = await owned(ctx.env, 'ai_providers', b.id, u.id);
    const blocked = await guardReason(ctx.env, p); if (blocked) throw conflict(`Cost Guard: ${blocked}`);
    try {
      const out = await generate(ctx.env, u.id, { task: 'test', system: 'Reply with the single word OK.', prompt: 'ping', providerId: p.id });
      await ctx.env.DB.prepare('UPDATE ai_providers SET last_tested_at=? WHERE id=?').bind(now(), p.id).run();
      return json({ ok: true, model: out.model, tokensIn: out.tokensIn, tokensOut: out.tokensOut });
    } catch (e) { await ctx.env.DB.prepare('UPDATE ai_providers SET last_tested_at=? WHERE id=?').bind(now(), p.id).run(); return json({ ok: false, error: e.details?.join('; ') || e.message }, 200); }
  });

  r.delete('/api/ai/providers/:id', async (ctx) => {
    const u = requireUser(ctx); const p = await owned(ctx.env, 'ai_providers', ctx.params.id, u.id);
    await ctx.env.DB.prepare('DELETE FROM ai_providers WHERE id=?').bind(p.id).run();
    if (p.is_default) await ctx.env.DB.prepare('UPDATE ai_providers SET is_default=1 WHERE id=(SELECT id FROM ai_providers WHERE user_id=? ORDER BY created_at LIMIT 1)').bind(u.id).run();
    await audit(ctx.env, u.id, 'ai.provider_remove', p.id, ctx.req);
    return json({ ok: true });
  });

  // ---- metadata ---------------------------------------------------------------------------------------
  r.post('/api/metadata/generate', async (ctx) => {
    const u = requireUser(ctx); await rateLimit(ctx.env, `meta:${u.id}`, 40, 3600);
    const b = validate(await readJson(ctx.req), { clipId: { type: 'string', required: true, pattern: ID }, platforms: { type: 'array', required: true, max: 5, items: { type: 'string', enum: PLATFORMS } },
      language: { type: 'string', max: 10 }, template: { type: 'string', max: 500 }, fields: { type: 'array', max: 10, items: { type: 'string' } }, mode: { type: 'string', enum: ['ai', 'template'], default: 'ai' } });
    const clip = await owned(ctx.env, 'generated_clips', b.clipId, u.id);
    const mo = clip.moment_id ? await ctx.env.DB.prepare('SELECT moment_type, transcript FROM detected_moments WHERE id=?').bind(clip.moment_id).first() : null;
    const settings = await ctx.env.DB.prepare('SELECT language, default_privacy, prompt_templates FROM user_settings WHERE user_id=?').bind(u.id).first();
    const lang = b.language || settings.language || 'en'; const userTemplate = b.template || J(settings.prompt_templates, {}).metadata;
    const results = [];
    for (const platform of b.platforms) {
      const existing = await ctx.env.DB.prepare('SELECT * FROM clip_metadata WHERE clip_id=? AND platform=?').bind(clip.id, platform).first();
      let value, src = 'ai', provider = null, model = null, warnings = [];
      if (b.mode === 'template') { value = templateMetadata(platform, { title: clip.title, transcript: mo?.transcript }); src = 'template'; }
      else {
        const { system, prompt } = buildPrompt({ platform, language: lang, transcript: mo?.transcript, momentType: mo?.moment_type, durationS: clip.end_s - clip.start_s, userTemplate });
        const out = await generate(ctx.env, u.id, { task: 'metadata', system, prompt, json: true });   // throws 409 if nothing is configured: no silent fallback
        value = coerceAiOutput(platform, out.parsed); provider = out.provider; model = out.model;
        if (out.usedFallback) warnings.push(`generated by fallback provider ${out.provider}`);
      }
      value.privacy = existing?.privacy || (SPECS[platform].privacy.includes(settings.default_privacy) ? settings.default_privacy : SPECS[platform].privacy[0] || 'private'); value.language = lang;
      if (b.fields?.length && existing) {      // regenerate only selected fields
        const keep = metaRow(existing); const merged = { ...keep, tags: keep.tags };
        const snake = { coverRecommendation: 'cover_recommendation', titleAlternatives: 'title_alternatives' };
        for (const f of b.fields) { const k = Object.keys(snake).find((x) => snake[x] === f) || f; if (value[f] !== undefined) merged[k] = value[f]; }
        value = { ...merged, title_alternatives: value.title_alternatives ?? merged.titleAlternatives, cover_recommendation: merged.coverRecommendation, privacy: existing.privacy };
      }
      const norm = normalizeMetadata(platform, value); warnings.push(...norm.warnings); const v = norm.value; const t = now();
      await ctx.env.DB.prepare(`INSERT INTO clip_metadata(id,clip_id,platform,title,title_alternatives,description,caption,hashtags,tags,category,language,privacy,cover_recommendation,source,provider,model,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(clip_id,platform) DO UPDATE SET title=excluded.title,title_alternatives=excluded.title_alternatives,description=excluded.description,caption=excluded.caption,hashtags=excluded.hashtags,
        tags=excluded.tags,category=excluded.category,language=excluded.language,cover_recommendation=excluded.cover_recommendation,source=excluded.source,provider=excluded.provider,model=excluded.model,updated_at=excluded.updated_at`)
        .bind(uid('md_'), clip.id, platform, v.title ?? null, JSON.stringify(v.title_alternatives || []), v.description ?? null, v.caption ?? null, JSON.stringify(v.hashtags || []), JSON.stringify(v.tags || []), v.category ?? null, v.language, v.privacy,
          v.cover_recommendation ?? null, src, provider, model, t, t).run();
      results.push({ ...metaRow(await ctx.env.DB.prepare('SELECT * FROM clip_metadata WHERE clip_id=? AND platform=?').bind(clip.id, platform).first()), warnings });
    }
    await notify(ctx.env, u.id, 'approval_required', 'Metadata ready for review', clip.title || '', `#/publishing?clip=${clip.id}`);
    return json({ metadata: results });
  });

  r.get('/api/metadata/:clipId', async (ctx) => {
    const u = requireUser(ctx); const clip = await owned(ctx.env, 'generated_clips', ctx.params.clipId, u.id);
    const { results } = await ctx.env.DB.prepare('SELECT * FROM clip_metadata WHERE clip_id=?').bind(clip.id).all();
    return json({ metadata: results.map(metaRow), specs: SPECS });
  });

  r.patch('/api/metadata/:id', async (ctx) => {
    const u = requireUser(ctx);
    const m = await ctx.env.DB.prepare('SELECT * FROM clip_metadata WHERE id=?').bind(ctx.params.id).first();
    if (!m) throw notFound(); await owned(ctx.env, 'generated_clips', m.clip_id, u.id);
    const live = await ctx.env.DB.prepare("SELECT COUNT(*) n FROM publishing_jobs WHERE metadata_id=? AND status IN ('approved','scheduled','publishing')").bind(m.id).first();
    if (live.n) throw conflict('An approved post uses this metadata. Cancel it first; approvals are frozen so what you approved is what gets published.');
    const b = validate(await readJson(ctx.req), { title: { type: 'string', max: 500 }, description: { type: 'string', max: 10000 }, caption: { type: 'string', max: 10000 }, hashtags: { type: 'array', max: 60, items: { type: 'string', max: 80 } },
      tags: { type: 'array', max: 100, items: { type: 'string', max: 100 } }, category: { type: 'string', max: 10 }, language: { type: 'string', max: 10 }, privacy: { type: 'string', max: 40 }, coverRecommendation: { type: 'string', max: 500 } });
    const cur = metaRow(m); const merged = { ...cur, ...b, cover_recommendation: b.coverRecommendation ?? cur.coverRecommendation };
    const { value, warnings } = normalizeMetadata(m.platform, merged);
    await ctx.env.DB.prepare('UPDATE clip_metadata SET title=?,description=?,caption=?,hashtags=?,tags=?,category=?,language=?,privacy=?,cover_recommendation=?,source=?,updated_at=? WHERE id=?')
      .bind(value.title ?? null, value.description ?? null, value.caption ?? null, JSON.stringify(value.hashtags || []), JSON.stringify(value.tags || []), value.category ?? null, value.language, value.privacy, value.cover_recommendation ?? null, 'manual', now(), m.id).run();
    return json({ metadata: metaRow(await ctx.env.DB.prepare('SELECT * FROM clip_metadata WHERE id=?').bind(m.id).first()), warnings });
  });
}
