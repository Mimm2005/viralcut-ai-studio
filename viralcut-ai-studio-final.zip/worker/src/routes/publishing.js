import { json, readJson, now, uid, HttpError, conflict, badRequest, notFound } from '../lib/http.js';
import { validate, ID, PLATFORMS } from '../lib/validate.js';
import { requireUser, owned } from '../lib/auth.js';
import { normalizeMetadata, SPECS } from '../lib/metadata.js';
import { isValidTimezone, localToUtc, nextSlots, utcToLocalParts } from '../lib/time.js';
import { notify } from '../lib/notify.js';
import { audit } from '../lib/audit.js';
import { runPublishingJob } from '../lib/scheduler.js';
import { metaRow } from './ai.js';

const J = (s, d) => { try { return JSON.parse(s) ?? d; } catch { return d; } };
const MAX_AHEAD = 366 * 86400;
const CANCELLABLE = ['pending_approval', 'approved', 'scheduled', 'needs_verification', 'failed'];

const jobRow = (j) => ({ id: j.id, clipId: j.clip_id, clipTitle: j.clip_title, platform: j.platform, status: j.status, runAt: j.run_at, timezone: j.timezone, attempts: j.attempts, maxAttempts: j.max_attempts,
  stage: j.stage, progress: j.progress, error: j.error, approvedAt: j.approved_at, nextAttemptAt: j.next_attempt_at, postUrl: j.post_url ?? null, externalId: j.post_external_id ?? null });
const SELECT = `SELECT j.*, c.title clip_title, p.url post_url, p.external_id post_external_id FROM publishing_jobs j JOIN generated_clips c ON c.id=j.clip_id LEFT JOIN published_posts p ON p.publishing_job_id=j.id`;

/** Resolve a user-supplied time into UTC epoch seconds. Accepts {runAt} (UTC epoch), {localTime,timezone} or {slot:'next'}. */
export async function resolveRunAt(env, userId, b, platform) {
  const settings = await env.DB.prepare('SELECT timezone FROM user_settings WHERE user_id=?').bind(userId).first();
  const tz = b.timezone || settings.timezone;
  if (!isValidTimezone(tz)) throw badRequest('Unknown timezone');
  let at;
  if (b.slot === 'next') {
    const sch = await env.DB.prepare('SELECT * FROM publishing_schedules WHERE user_id=? AND platform=? AND active=1').bind(userId, platform).all();
    if (!sch.results.length) throw badRequest(`No active schedule for ${platform}. Create one under Calendar > Schedules or choose a time.`);
    let cands = [];
    for (const s of sch.results) cands.push(...nextSlots({ kind: s.kind, times: J(s.times, []), weekdays: J(s.weekdays, [1, 2, 3, 4, 5, 6, 7]), timezone: s.timezone }, now() + 120, 30));
    cands.sort((a, c) => a - c);
    const { results: taken } = await env.DB.prepare("SELECT run_at FROM publishing_jobs WHERE user_id=? AND platform=? AND status IN ('scheduled','publishing')").bind(userId, platform).all();
    const used = new Set(taken.map((t) => t.run_at));
    at = cands.find((c) => !used.has(c));
    if (!at) throw conflict('No free slot in the next schedule window');
  } else if (b.runAt) at = b.runAt;
  else if (b.localTime) { try { at = localToUtc(b.localTime, tz); } catch { throw badRequest('localTime must look like 2026-12-01T18:30'); } }
  else throw badRequest('Provide runAt, localTime (+timezone) or slot:"next"');
  if (at < now() + 60) throw badRequest('Scheduled time must be at least one minute in the future');
  if (at > now() + MAX_AHEAD) throw badRequest('Scheduled time is too far in the future (max 1 year)');
  return { at, tz };
}

function validateForPlatform(platform, m) {
  const { value, warnings } = normalizeMetadata(platform, m);
  const missing = [];
  if (platform === 'youtube' && !value.title) missing.push('title');
  if (platform !== 'youtube' && !value.caption && !value.description) missing.push('caption');
  if (missing.length) throw badRequest(`Metadata incomplete: ${missing.join(', ')} required for ${platform}`);
  return { value, warnings };
}

export function register(r) {
  // Step 5 of the workflow: the user approves exact content. The approved snapshot is frozen.
  r.post('/api/publishing/approve', async (ctx) => {
    const u = requireUser(ctx);
    const b = validate(await readJson(ctx.req), { clipId: { type: 'string', required: true, pattern: ID }, platform: { type: 'string', required: true, enum: PLATFORMS } });
    const clip = await owned(ctx.env, 'generated_clips', b.clipId, u.id);
    if (clip.status !== 'ready' || !clip.r2_key) throw conflict('Render the clip before approving it');
    const acc = await ctx.env.DB.prepare('SELECT * FROM social_accounts WHERE user_id=? AND platform=?').bind(u.id, b.platform).first();
    if (!acc || acc.status !== 'connected') throw conflict(`Connect a working ${b.platform} account first (status: ${acc?.status || 'disconnected'})`);
    const meta = await ctx.env.DB.prepare('SELECT * FROM clip_metadata WHERE clip_id=? AND platform=?').bind(clip.id, b.platform).first();
    if (!meta) throw conflict('Generate or write metadata for this platform first');
    const { value, warnings } = validateForPlatform(b.platform, metaRow(meta));
    const posted = await ctx.env.DB.prepare("SELECT 1 x FROM published_posts WHERE clip_id=? AND platform=?").bind(clip.id, b.platform).first();
    const id = uid('pj_'), t = now();
    try {
      await ctx.env.DB.prepare(`INSERT INTO publishing_jobs(id,user_id,clip_id,metadata_id,account_id,platform,status,approved_at,snapshot,created_at,updated_at) VALUES(?,?,?,?,?,?,'approved',?,?,?,?)`)
        .bind(id, u.id, clip.id, meta.id, acc.id, b.platform, t, JSON.stringify(value), t, t).run();
    } catch (e) { if (/UNIQUE/i.test(e.message)) throw conflict('This clip already has an active publishing job for this platform'); throw e; }
    await audit(ctx.env, u.id, 'publishing.approve', id, ctx.req);
    return json({ job: { id, status: 'approved' }, warnings, alreadyPublishedBefore: !!posted }, 201);
  });

  r.post('/api/publishing/schedule', async (ctx) => {
    const u = requireUser(ctx);
    const b = validate(await readJson(ctx.req), { jobId: { type: 'string', required: true, pattern: ID }, runAt: { type: 'integer', min: 0 }, localTime: { type: 'string', max: 25 }, timezone: { type: 'string', max: 60 }, slot: { type: 'string', enum: ['next'] } });
    const j = await owned(ctx.env, 'publishing_jobs', b.jobId, u.id);
    if (!['approved', 'scheduled'].includes(j.status)) throw conflict(`Only approved jobs can be scheduled (status: ${j.status})`);
    const { at, tz } = await resolveRunAt(ctx.env, u.id, b, j.platform);
    await ctx.env.DB.prepare("UPDATE publishing_jobs SET status='scheduled', run_at=?, timezone=?, next_attempt_at=NULL, error=NULL, updated_at=? WHERE id=?").bind(at, tz, now(), j.id).run();
    const lp = utcToLocalParts(at, tz);
    await notify(ctx.env, u.id, 'post_scheduled', `Scheduled for ${lp.date} ${lp.time} (${tz})`, j.platform, '#/calendar');
    return json({ job: { id: j.id, status: 'scheduled', runAt: at, timezone: tz, local: `${lp.date} ${lp.time}` } });
  });

  r.get('/api/publishing/jobs', async (ctx) => {
    const u = requireUser(ctx); const st = ctx.url.searchParams.get('status'), pl = ctx.url.searchParams.get('platform');
    const { results } = await ctx.env.DB.prepare(`${SELECT} WHERE j.user_id=? ${st ? 'AND j.status=?' : ''} ${pl ? 'AND j.platform=?' : ''} ORDER BY COALESCE(j.run_at, j.created_at) DESC LIMIT 200`).bind(...[u.id, st, pl].filter(Boolean)).all();
    const s = await ctx.env.DB.prepare('SELECT queue_paused FROM user_settings WHERE user_id=?').bind(u.id).first();
    return json({ jobs: results.map(jobRow), queuePaused: !!s.queue_paused });
  });

  r.get('/api/publishing/jobs/:id', async (ctx) => {
    const u = requireUser(ctx); await owned(ctx.env, 'publishing_jobs', ctx.params.id, u.id);
    const j = await ctx.env.DB.prepare(`${SELECT} WHERE j.id=?`).bind(ctx.params.id).first();
    const { results } = await ctx.env.DB.prepare('SELECT ts,level,message,http_status FROM publishing_logs WHERE publishing_job_id=? ORDER BY id DESC LIMIT 100').bind(j.id).all();
    return json({ job: jobRow(j), snapshot: J(j.snapshot, {}), logs: results });
  });

  r.get('/api/publishing/calendar', async (ctx) => {
    const u = requireUser(ctx); const q = ctx.url.searchParams;
    const s = await ctx.env.DB.prepare('SELECT timezone FROM user_settings WHERE user_id=?').bind(u.id).first();
    const tz = q.get('tz') || s.timezone; if (!isValidTimezone(tz)) throw badRequest('Unknown timezone');
    const from = Number(q.get('from')) || now() - 7 * 86400, to = Number(q.get('to')) || now() + 60 * 86400;
    if (to - from > 400 * 86400) throw badRequest('Range too large');
    const { results } = await ctx.env.DB.prepare(`${SELECT} WHERE j.user_id=? AND j.run_at BETWEEN ? AND ? AND j.status<>'cancelled' ORDER BY j.run_at`).bind(u.id, from, to).all();
    const days = {};
    for (const j of results) { const lp = utcToLocalParts(j.run_at, tz); (days[lp.date] ||= []).push({ ...jobRow(j), localTime: lp.time }); }
    return json({ timezone: tz, days });
  });

  r.patch('/api/publishing/jobs/:id', async (ctx) => {
    const u = requireUser(ctx); const j = await owned(ctx.env, 'publishing_jobs', ctx.params.id, u.id);
    const b = validate(await readJson(ctx.req), { action: { type: 'string', required: true, enum: ['reschedule', 'retry', 'run_now', 'unschedule'] }, runAt: { type: 'integer', min: 0 }, localTime: { type: 'string', max: 25 }, timezone: { type: 'string', max: 60 }, slot: { type: 'string', enum: ['next'] } });
    if (b.action === 'reschedule') {
      if (!['scheduled', 'approved', 'failed'].includes(j.status)) throw conflict(`Cannot reschedule a ${j.status} job`);
      const { at, tz } = await resolveRunAt(ctx.env, u.id, b, j.platform);
      await ctx.env.DB.prepare("UPDATE publishing_jobs SET status='scheduled', run_at=?, timezone=?, attempts=CASE WHEN status='failed' THEN 0 ELSE attempts END, next_attempt_at=NULL, error=NULL, updated_at=? WHERE id=?").bind(at, tz, now(), j.id).run();
    } else if (b.action === 'unschedule') {
      if (j.status !== 'scheduled') throw conflict('Only scheduled jobs can be unscheduled');
      await ctx.env.DB.prepare("UPDATE publishing_jobs SET status='approved', run_at=NULL, updated_at=? WHERE id=?").bind(now(), j.id).run();
    } else if (b.action === 'retry') {
      if (!['failed', 'needs_verification'].includes(j.status)) throw conflict('Only failed or needs-verification jobs can be retried');
      // From needs_verification the user attests that the post does not exist; restart from scratch only then.
      const reset = j.status === 'needs_verification';
      await ctx.env.DB.prepare(`UPDATE publishing_jobs SET status='scheduled', run_at=?, attempts=0, next_attempt_at=NULL, error=NULL, ${reset ? 'stage=NULL, external_ref=NULL,' : ''} updated_at=? WHERE id=?`).bind(now(), now(), j.id).run();
      if (reset) await audit(ctx.env, u.id, 'publishing.retry_after_verification', j.id, ctx.req);
    } else if (b.action === 'run_now') {
      if (!['approved', 'scheduled'].includes(j.status)) throw conflict(`Cannot run a ${j.status} job`);
      await ctx.env.DB.prepare("UPDATE publishing_jobs SET status='scheduled', run_at=?, updated_at=? WHERE id=?").bind(now(), now(), j.id).run();   // picked up by the next scheduler tick
    }
    return json({ job: jobRow(await ctx.env.DB.prepare(`${SELECT} WHERE j.id=?`).bind(j.id).first()) });
  });

  r.delete('/api/publishing/jobs/:id', async (ctx) => {
    const u = requireUser(ctx); const j = await owned(ctx.env, 'publishing_jobs', ctx.params.id, u.id);
    if (j.status === 'publishing') throw conflict('This post is being published right now and cannot be cancelled');
    if (j.status === 'published') throw conflict('Already published; delete it on the platform itself');
    if (!CANCELLABLE.includes(j.status)) throw conflict(`Cannot cancel a ${j.status} job`);
    await ctx.env.DB.prepare("UPDATE publishing_jobs SET status='cancelled', updated_at=? WHERE id=?").bind(now(), j.id).run();
    await audit(ctx.env, u.id, 'publishing.cancel', j.id, ctx.req);
    return json({ ok: true });
  });

  r.patch('/api/publishing/queue', async (ctx) => {
    const u = requireUser(ctx);
    const b = validate(await readJson(ctx.req), { paused: { type: 'boolean', required: true } });
    await ctx.env.DB.prepare('UPDATE user_settings SET queue_paused=?, updated_at=? WHERE user_id=?').bind(+b.paused, now(), u.id).run();
    await audit(ctx.env, u.id, b.paused ? 'queue.pause' : 'queue.resume', null, ctx.req);
    return json({ queuePaused: b.paused });
  });

  // ---- recurring schedules (daily / weekly / custom times) ----------------------------------------------------
  r.get('/api/publishing/schedules', async (ctx) => {
    const u = requireUser(ctx);
    const { results } = await ctx.env.DB.prepare('SELECT * FROM publishing_schedules WHERE user_id=? ORDER BY platform').bind(u.id).all();
    return json({ schedules: results.map((s) => ({ id: s.id, platform: s.platform, kind: s.kind, times: J(s.times, []), weekdays: J(s.weekdays, null), timezone: s.timezone, active: !!s.active,
      next: nextSlots({ kind: s.kind, times: J(s.times, []), weekdays: J(s.weekdays, [1, 2, 3, 4, 5, 6, 7]), timezone: s.timezone }, now(), 3) })) });
  });
  r.post('/api/publishing/schedules', async (ctx) => {
    const u = requireUser(ctx);
    const b = validate(await readJson(ctx.req), { platform: { type: 'string', required: true, enum: PLATFORMS }, kind: { type: 'string', required: true, enum: ['daily', 'weekly', 'custom'] },
      times: { type: 'array', required: true, max: 6, items: { type: 'string', pattern: /^([01]\d|2[0-3]):[0-5]\d$/ } }, weekdays: { type: 'array', max: 7, items: { type: 'integer', min: 1, max: 7 } }, timezone: { type: 'string', max: 60 } });
    if (!b.times.length) throw badRequest('Add at least one time');
    if (b.kind === 'weekly' && !b.weekdays?.length) throw badRequest('Weekly schedules need weekdays');
    const s = await ctx.env.DB.prepare('SELECT timezone FROM user_settings WHERE user_id=?').bind(u.id).first(); const tz = b.timezone || s.timezone;
    if (!isValidTimezone(tz)) throw badRequest('Unknown timezone');
    const id = uid('ps_');
    await ctx.env.DB.prepare('INSERT INTO publishing_schedules(id,user_id,platform,kind,times,weekdays,timezone,active,created_at) VALUES(?,?,?,?,?,?,?,1,?)').bind(id, u.id, b.platform, b.kind, JSON.stringify(b.times), b.weekdays ? JSON.stringify(b.weekdays) : null, tz, now()).run();
    return json({ schedule: { id } }, 201);
  });
  r.delete('/api/publishing/schedules/:id', async (ctx) => {
    const u = requireUser(ctx);
    const res = await ctx.env.DB.prepare('DELETE FROM publishing_schedules WHERE id=? AND user_id=?').bind(ctx.params.id, u.id).run();
    if (!res.meta?.changes) throw notFound();
    return json({ ok: true });
  });
}
