import { json, readJson, now, uid, HttpError, unauthorized, forbidden, conflict } from '../lib/http.js';
import { validate } from '../lib/validate.js';
import { hashPassword, verifyPassword, timingSafeEqual } from '../lib/crypto.js';
import { createSession, destroySession, requireUser, sessionCookie } from '../lib/auth.js';
import { rateLimit } from '../lib/ratelimit.js';
import { audit } from '../lib/audit.js';

const DUMMY = 'pbkdf2$100000$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=';
const strong = (p) => typeof p === 'string' && p.length >= 12 && p.length <= 200;

export function register(r) {
  // One-time owner creation. Disabled once any user exists; also requires SETUP_TOKEN, so nobody can register publicly.
  r.post('/api/auth/setup', async ({ env, req }) => {
    if (!env.SETUP_TOKEN) throw new HttpError(503, 'SETUP_TOKEN is not configured');
    const b = validate(await readJson(req), { email: { type: 'string', required: true, max: 200, pattern: /^[^@\s]+@[^@\s]+\.[^@\s]+$/ },
      password: { type: 'string', required: true, trim: false }, setupToken: { type: 'string', required: true, trim: false }, displayName: { type: 'string', max: 80, default: 'Owner' } });
    if (!timingSafeEqual(b.setupToken, env.SETUP_TOKEN)) { await rateLimit(env, `setup:${req.headers.get('cf-connecting-ip')}`, 5, 900); throw forbidden('Invalid setup token'); }
    if (!strong(b.password)) throw new HttpError(400, 'Password must be 12-200 characters');
    const existing = await env.DB.prepare('SELECT COUNT(*) n FROM users').first();
    if (existing.n > 0) throw conflict('Setup already completed');
    const id = uid('u_'); const t = now();
    await env.DB.batch([
      env.DB.prepare('INSERT INTO users(id,email,display_name,password_hash,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').bind(id, b.email.toLowerCase(), b.displayName, await hashPassword(b.password, Number(env.PBKDF2_ITERATIONS) || undefined), 'owner', t, t),
      env.DB.prepare('INSERT INTO user_settings(user_id,updated_at) VALUES(?,?)').bind(id, t)]);
    await audit(env, id, 'auth.setup', id, req);
    return json({ ok: true }, 201);
  }, { auth: false, csrf: false });

  r.post('/api/auth/login', async ({ env, req }) => {
    const b = validate(await readJson(req), { email: { type: 'string', required: true, max: 200 }, password: { type: 'string', required: true, trim: false, max: 200 } });
    const ip = req.headers.get('cf-connecting-ip') || 'unknown';
    await rateLimit(env, `login:ip:${ip}`, 20, 900);
    await rateLimit(env, `login:acct:${b.email.toLowerCase()}`, 8, 900);
    const u = await env.DB.prepare('SELECT * FROM users WHERE email=?').bind(b.email.toLowerCase()).first();
    const ok = await verifyPassword(b.password, u?.password_hash || DUMMY);   // constant work whether or not the user exists
    if (!u || !ok) { await audit(env, u?.id ?? null, 'auth.login_failed', b.email.toLowerCase(), req); throw unauthorized('Invalid email or password'); }
    const s = await createSession(env, u.id, req);
    await audit(env, u.id, 'auth.login', u.id, req);
    return json({ user: { id: u.id, email: u.email, displayName: u.display_name, role: u.role }, csrfToken: s.csrf }, 200, { 'set-cookie': s.cookie });
  }, { auth: false, csrf: false });

  r.post('/api/auth/logout', async ({ env, session, req }) => {
    if (session) { await destroySession(env, session.sid); await audit(env, session.user.id, 'auth.logout', null, req); }
    return json({ ok: true }, 200, { 'set-cookie': sessionCookie('', 0) });
  }, { auth: false });

  r.get('/api/auth/me', async ({ env, session }) => {
    if (!session) {
      const n = await env.DB.prepare('SELECT COUNT(*) n FROM users').first();
      return json({ user: null, setupRequired: n.n === 0 }, 401);
    }
    return json({ user: session.user, csrfToken: session.csrf });
  }, { auth: false });

  r.post('/api/auth/password', async (ctx) => {
    const user = requireUser(ctx);
    const b = validate(await readJson(ctx.req), { current: { type: 'string', required: true, trim: false }, next: { type: 'string', required: true, trim: false } });
    if (!strong(b.next)) throw new HttpError(400, 'Password must be 12-200 characters');
    const u = await ctx.env.DB.prepare('SELECT password_hash FROM users WHERE id=?').bind(user.id).first();
    if (!(await verifyPassword(b.current, u.password_hash))) throw forbidden('Current password is incorrect');
    await ctx.env.DB.batch([
      ctx.env.DB.prepare('UPDATE users SET password_hash=?, updated_at=? WHERE id=?').bind(await hashPassword(b.next, Number(ctx.env.PBKDF2_ITERATIONS) || undefined), now(), user.id),
      ctx.env.DB.prepare('DELETE FROM sessions WHERE user_id=? AND id<>?').bind(user.id, ctx.session.sid)]);   // sign out other devices
    await audit(ctx.env, user.id, 'auth.password_changed', null, ctx.req);
    return json({ ok: true });
  });
}
