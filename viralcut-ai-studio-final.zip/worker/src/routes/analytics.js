import { json, now, badRequest } from '../lib/http.js';
import { requireUser } from '../lib/auth.js';
import { computeInsights } from '../lib/feedback.js';
import { utcToLocalParts } from '../lib/time.js';

const J = (s, d) => { try { return JSON.parse(s) ?? d; } catch { return d; } };
const METRICS = ['views', 'likes', 'comments', 'shares', 'reach', 'impressions', 'saves', 'avgViewDurationSec', 'avgViewPercentage'];
export const RANGES = { '24h': 86400, '7d': 7 * 86400, '30d': 30 * 86400 };

export function range(q) {
  const r = q.get('range') || '7d'; const t = now();
  if (r === 'custom') { const from = Number(q.get('from')), to = Number(q.get('to')); if (!from || !to || to <= from) throw badRequest('custom range needs from and to (epoch seconds)'); return { from, to, label: 'custom' }; }
  if (!RANGES[r]) throw badRequest('range must be 24h, 7d, 30d or custom');
  return { from: t - RANGES[r], to: t, label: r };
}

/** Posts published in range with their latest snapshot. Missing metrics stay null and are labelled unavailable. */
export async function loadPosts(env, userId, { from, to }, platform) {
  const { results } = await env.DB.prepare(`SELECT p.*, s.metrics, s.unavailable, s.captured_at, s.source snap_source FROM published_posts p
    LEFT JOIN analytics_snapshots s ON s.id=(SELECT id FROM analytics_snapshots WHERE post_id=p.id AND source='api' ORDER BY captured_at DESC LIMIT 1)
    WHERE p.user_id=? AND p.published_at BETWEEN ? AND ? ${platform ? 'AND p.platform=?' : ''} ORDER BY p.published_at DESC LIMIT 500`).bind(...[userId, from, to, platform].filter((x) => x !== undefined && x !== null)).all();
  return results.map((p) => {
    const m = J(p.metrics, {}); const un = J(p.unavailable, {});
    const metrics = {}; for (const k of METRICS) metrics[k] = typeof m[k] === 'number' ? m[k] : null;
    const unavailable = {}; for (const k of METRICS) if (metrics[k] === null) unavailable[k] = un[k] || (p.captured_at ? 'not provided by the platform API' : 'no snapshot collected yet');
    const eng = metrics.views > 0 && metrics.likes !== null ? ((metrics.likes + (metrics.comments || 0) + (metrics.shares || 0)) / metrics.views) : null;
    return { id: p.id, platform: p.platform, externalId: p.external_id, url: p.url, title: p.title, publishedAt: p.published_at, predictedScore: p.predicted_score, momentType: p.moment_type, durationS: p.duration_s,
      metrics, engagementRate: eng, unavailable, capturedAt: p.captured_at ?? null, _hookText: p.hook_text };
  });
}

function aggregate(posts) {
  const total = {}, counted = {};
  for (const k of METRICS) { const vals = posts.map((p) => p.metrics[k]).filter((v) => v !== null); counted[k] = vals.length; total[k] = vals.length ? vals.reduce((a, b) => a + b, 0) : null; }
  const er = posts.map((p) => p.engagementRate).filter((v) => v !== null);
  return { posts: posts.length, totals: total, postsWithMetric: counted, avgEngagementRate: er.length ? er.reduce((a, b) => a + b, 0) / er.length : null };
}

export function register(r) {
  r.get('/api/analytics/overview', async (ctx) => {
    const u = requireUser(ctx); const rg = range(ctx.url.searchParams);
    const posts = await loadPosts(ctx.env, u.id, rg);
    const best = [...posts].filter((p) => p.metrics.views !== null).sort((a, b) => b.metrics.views - a.metrics.views).slice(0, 5);
    const bestMeta = [...posts].filter((p) => p.engagementRate !== null && p.metrics.views >= 10).sort((a, b) => b.engagementRate - a.engagementRate).slice(0, 5).map((p) => ({ title: p.title, platform: p.platform, engagementRate: p.engagementRate }));
    const stale = posts.filter((p) => !p.capturedAt).length;
    return json({ range: rg, ...aggregate(posts), bestClips: best.map((p) => ({ id: p.id, title: p.title, platform: p.platform, views: p.metrics.views, url: p.url })), bestMetadata: bestMeta,
      note: posts.length === 0 ? 'No posts were published in this range.' : stale ? `${stale} post(s) have no analytics snapshot yet.` : null });
  });

  r.get('/api/analytics/posts', async (ctx) => {
    const u = requireUser(ctx); const rg = range(ctx.url.searchParams);
    const posts = await loadPosts(ctx.env, u.id, rg, ctx.url.searchParams.get('platform') || undefined);
    const out = [];
    for (const p of posts) {
      const { results } = await ctx.env.DB.prepare("SELECT captured_at, metrics FROM analytics_snapshots WHERE post_id=? AND source='api' ORDER BY captured_at").bind(p.id).all();
      const { _hookText, ...rest } = p; out.push({ ...rest, history: results.map((s) => ({ capturedAt: s.captured_at, metrics: J(s.metrics, {}) })) });
    }
    return json({ range: rg, posts: out });
  });

  r.get('/api/analytics/platforms', async (ctx) => {
    const u = requireUser(ctx); const rg = range(ctx.url.searchParams);
    const posts = await loadPosts(ctx.env, u.id, rg); const by = {};
    for (const p of posts) (by[p.platform] ||= []).push(p);
    return json({ range: rg, platforms: Object.entries(by).map(([platform, ps]) => ({ platform, ...aggregate(ps) })) });
  });

  r.get('/api/analytics/insights', async (ctx) => {
    const u = requireUser(ctx);
    const tz = (await ctx.env.DB.prepare('SELECT timezone FROM user_settings WHERE user_id=?').bind(u.id).first()).timezone;
    const posts = await loadPosts(ctx.env, u.id, { from: 0, to: now() + 1 });
    const rows = posts.map((p) => ({ platform: p.platform, views: p.metrics.views, predicted_score: p.predictedScore, duration_s: p.durationS, moment_type: p.momentType, published_hour: utcToLocalParts(p.publishedAt, tz).hour, title: p.title, hook_text: p._hookText }));
    return json(computeInsights(rows, ctx.url.searchParams.get('metric') || 'views'));
  });
}
