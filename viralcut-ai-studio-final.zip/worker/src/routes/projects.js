import { store } from '../lib/storage.js';
import { json, readJson, now, uid, HttpError, conflict, notFound, badRequest } from '../lib/http.js';
import { validate, ID } from '../lib/validate.js';
import { requireUser, owned } from '../lib/auth.js';
import { hmacHex, timingSafeEqual } from '../lib/crypto.js';
import { signedUploadUrl, engine, engineConfigured } from '../lib/engine.js';
import { submitAnalysis, submitRender } from '../lib/pipeline.js';
import { rateLimit } from '../lib/ratelimit.js';
import { audit } from '../lib/audit.js';
import { jobEvent } from '../lib/scheduler.js';

const EXT = { '.mp4': 'video/mp4', '.mov': 'video/quicktime', '.webm': 'video/webm', '.mkv': 'video/x-matroska', '.m4v': 'video/mp4' };
const maxBytes = (env) => Number(env.MAX_UPLOAD_MB || 1024) * 1024 * 1024;
const PROXY_LIMIT = 95 * 1024 * 1024;     // Workers request-body limit on the free plan is 100 MB
const ytId = (url) => {
  try { const u = new URL(url); const h = u.hostname.toLowerCase();
    if (!['youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtu.be', 'music.youtube.com'].includes(h) || u.protocol !== 'https:') return null;
    const id = h === 'youtu.be' ? u.pathname.slice(1).split('/')[0] : u.pathname === '/watch' ? u.searchParams.get('v') : (u.pathname.match(/^\/(?:shorts|live|embed)\/([^/]+)/) || [])[1];
    return id && /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null; } catch { return null; }
};
export { ytId };

export async function signMedia(env, key, ttl = 3600, download = false) {
  const exp = now() + ttl; const sig = await hmacHex(env.MEDIA_SIGNING_KEY || env.ENCRYPTION_KEY, `${key}|${exp}|${download ? 1 : 0}`);
  return `/api/media/file?key=${encodeURIComponent(key)}&exp=${exp}&dl=${download ? 1 : 0}&sig=${sig}`;
}

async function deleteR2Prefix(env, prefix) {
  let cursor; do { const l = await store(env).list({ prefix, cursor }); if (l.objects.length) await store(env).delete(l.objects.map((o) => o.key)); cursor = l.truncated ? l.cursor : undefined; } while (cursor);
}

async function startAnalysis(env, userId, p, s, cfg) {
    const id = uid('j_'), t = now();
    await env.DB.batch([
      env.DB.prepare("INSERT INTO processing_jobs(id,project_id,source_id,user_id,kind,status,config,created_at,updated_at) VALUES(?,?,?,?,'analyze','queued',?,?,?)").bind(id, p.id, s.id, userId, JSON.stringify(cfg), t, t),
      env.DB.prepare("UPDATE projects SET status='analyzing', updated_at=? WHERE id=?").bind(t, p.id)]);
    await jobEvent(env, id, 'info', 'job created');
    let submitted = false;
    if (engineConfigured(env)) { try { await submitAnalysis(env, { id, source_id: s.id, config: JSON.stringify(cfg) }); submitted = true; await jobEvent(env, id, 'info', 'submitted to engine'); } catch (e) { await jobEvent(env, id, 'warn', `engine not reachable yet (${e.message}); will retry automatically`); } }
    else await jobEvent(env, id, 'warn', 'processing engine is not configured; the job will wait until ENGINE_URL/ENGINE_TOKEN are set');
  return { id, submitted };
}

export function register(r) {
  // ---- projects ------------------------------------------------------------------------
  r.post('/api/projects', async (ctx) => {
    const u = requireUser(ctx);
    const b = validate(await readJson(ctx.req), { name: { type: 'string', required: true, min: 1, max: 120 }, category: { type: 'string', max: 40 } });
    const id = uid('pr_'), t = now();
    await ctx.env.DB.prepare('INSERT INTO projects(id,user_id,name,category,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').bind(id, u.id, b.name, b.category ?? null, 'draft', t, t).run();
    return json({ project: { id, name: b.name, status: 'draft', category: b.category ?? null } }, 201);
  });

  r.get('/api/projects', async (ctx) => {
    const u = requireUser(ctx);
    const { results } = await ctx.env.DB.prepare(`SELECT p.*, (SELECT COUNT(*) FROM detected_moments m WHERE m.project_id=p.id) moments,
      (SELECT COUNT(*) FROM generated_clips c WHERE c.project_id=p.id) clips FROM projects p WHERE p.user_id=? ORDER BY p.created_at DESC LIMIT 200`).bind(u.id).all();
    return json({ projects: results });
  });

  r.get('/api/projects/:id', async (ctx) => {
    const u = requireUser(ctx); const p = await owned(ctx.env, 'projects', ctx.params.id, u.id);
    const [sources, jobs, clips] = await Promise.all([
      ctx.env.DB.prepare('SELECT id,adapter,state,source_url,original_filename,size_bytes,duration_s,width,height,fps,has_audio,message,missing_config,created_at FROM source_media WHERE project_id=? ORDER BY created_at DESC').bind(p.id).all(),
      ctx.env.DB.prepare('SELECT id,source_id,status,progress,step,error,created_at,finished_at FROM processing_jobs WHERE project_id=? ORDER BY created_at DESC LIMIT 10').bind(p.id).all(),
      ctx.env.DB.prepare('SELECT id,title,status,progress,start_s,end_s,created_at FROM generated_clips WHERE project_id=? ORDER BY created_at DESC').bind(p.id).all()]);
    return json({ project: p, sources: sources.results.map((s) => ({ ...s, missing_config: s.missing_config ? JSON.parse(s.missing_config) : [] })), jobs: jobs.results, clips: clips.results });
  });

  r.delete('/api/projects/:id', async (ctx) => {
    const u = requireUser(ctx); const p = await owned(ctx.env, 'projects', ctx.params.id, u.id);
    const live = await ctx.env.DB.prepare(`SELECT COUNT(*) n FROM publishing_jobs j JOIN generated_clips c ON c.id=j.clip_id WHERE c.project_id=? AND j.status IN ('approved','scheduled','publishing','needs_verification')`).bind(p.id).first();
    if (live.n > 0) throw conflict('Cancel this project\'s scheduled posts before deleting it');
    await deleteR2Prefix(ctx.env, `u/${u.id}/${p.id}/`);
    await ctx.env.DB.prepare('DELETE FROM projects WHERE id=?').bind(p.id).run();    // cascades to media, jobs, moments, clips
    await audit(ctx.env, u.id, 'project.delete', p.id, ctx.req);
    return json({ ok: true });
  });

  // ---- media upload ------------------------------------------------------------------------
  r.post('/api/media/upload/init', async (ctx) => {
    const u = requireUser(ctx); await rateLimit(ctx.env, `upl:${u.id}`, 30, 3600);
    const b = validate(await readJson(ctx.req), { projectId: { type: 'string', required: true, pattern: ID }, filename: { type: 'string', required: true, max: 200 },
      size: { type: 'integer', required: true, min: 1 }, contentType: { type: 'string', max: 100 } });
    const p = await owned(ctx.env, 'projects', b.projectId, u.id);
    const ext = (b.filename.match(/\.[A-Za-z0-9]+$/) || [''])[0].toLowerCase();
    if (!EXT[ext]) throw badRequest(`Unsupported file type. Allowed: ${Object.keys(EXT).join(', ')}`);
    if (b.contentType && !/^video\//.test(b.contentType) && b.contentType !== 'application/octet-stream') throw badRequest('Content type must be video/*');
    if (b.size > maxBytes(ctx.env)) throw new HttpError(413, `File exceeds the ${Math.round(maxBytes(ctx.env) / 1048576)} MB limit`);
    const q = await ctx.env.DB.prepare('SELECT (SELECT COALESCE(SUM(size_bytes),0) FROM source_media WHERE user_id=?1)+(SELECT COALESCE(SUM(size_bytes),0) FROM generated_clips WHERE user_id=?1) used, (SELECT storage_quota_mb FROM user_settings WHERE user_id=?1) q').bind(u.id).first();
    if (q.used + b.size > q.q * 1048576) throw conflict('Not enough storage left in your quota. Delete old projects or raise the quota in Settings.');
    const id = uid('sm_'), key = `u/${u.id}/${p.id}/${id}/source${ext}`, t = now();
    await ctx.env.DB.prepare("INSERT INTO source_media(id,project_id,user_id,adapter,state,r2_key,original_filename,size_bytes,mime_type,message,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)")
      .bind(id, p.id, u.id, 'upload', 'upload_pending', key, b.filename, b.size, EXT[ext], 'waiting for upload', t, t).run();
    let url, mode;
    try { if (ctx.env.UPLOAD_MODE === 'proxy' && b.size <= PROXY_LIMIT) throw new Error('proxy mode forced'); url = await signedUploadUrl(ctx.env, key, 3600); mode = 'direct'; }
    catch { if (b.size > PROXY_LIMIT) throw new HttpError(503, 'Files over 95 MB need R2 S3 credentials (R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY). See docs/DEPLOYMENT.md'); url = `/api/media/upload/${id}/put`; mode = 'proxy'; }
    return json({ sourceId: id, uploadUrl: url, method: 'PUT', mode, headers: mode === 'direct' ? {} : { 'content-type': EXT[ext] }, expiresIn: 3600 }, 201);
  });

  r.add('PUT', '/api/media/upload/:id/put', async (ctx) => {
    const u = requireUser(ctx); const s = await owned(ctx.env, 'source_media', ctx.params.id, u.id);
    if (s.state !== 'upload_pending') throw conflict('Upload already completed');
    const len = Number(ctx.req.headers.get('content-length') || 0);
    if (!len || len > PROXY_LIMIT || len > s.size_bytes + 1024) throw new HttpError(413, 'Invalid or oversized upload');
    await store(ctx.env).put(s.r2_key, ctx.req.body, { httpMetadata: { contentType: s.mime_type }, size: len });
    return json({ ok: true });
  });

  r.post('/api/media/upload/complete', async (ctx) => {
    const u = requireUser(ctx);
    const b = validate(await readJson(ctx.req), { sourceId: { type: 'string', required: true, pattern: ID } });
    const s = await owned(ctx.env, 'source_media', b.sourceId, u.id);
    if (s.state !== 'upload_pending') return json({ source: s });
    const head = await store(ctx.env).head(s.r2_key);
    if (!head) throw badRequest('The file has not arrived in storage yet');
    if (head.size > maxBytes(ctx.env)) { await store(ctx.env).delete(s.r2_key); throw new HttpError(413, 'File exceeds the size limit'); }
    const fp = `${head.etag}:${head.size}`;
    const dup = await ctx.env.DB.prepare('SELECT id,project_id FROM source_media WHERE user_id=? AND fingerprint=?').bind(u.id, fp).first();
    if (dup) { await store(ctx.env).delete(s.r2_key); await ctx.env.DB.prepare('DELETE FROM source_media WHERE id=?').bind(s.id).run(); throw conflict('This video was already imported', { existingSourceId: dup.id, projectId: dup.project_id }); }
    await ctx.env.DB.prepare("UPDATE source_media SET state='validated', size_bytes=?, fingerprint=?, message=?, updated_at=? WHERE id=?")
      .bind(head.size, fp, 'Stored. Decoding and stream checks run when analysis starts.', now(), s.id).run();
    await ctx.env.DB.prepare("UPDATE projects SET status='ready', updated_at=? WHERE id=?").bind(now(), s.project_id).run();
    return json({ source: await ctx.env.DB.prepare('SELECT * FROM source_media WHERE id=?').bind(s.id).first() });
  });

  // ---- URL-based import (adapters). Honest states; never claims a stream it has not verified. ----------
  r.post('/api/media/import', async (ctx) => {
    const u = requireUser(ctx);
    const b = validate(await readJson(ctx.req), { projectId: { type: 'string', required: true, pattern: ID }, adapter: { type: 'string', required: true, enum: ['youtube', 'cloud', 'livestream'] }, url: { type: 'string', required: true, max: 500 } });
    const p = await owned(ctx.env, 'projects', b.projectId, u.id);
    const id = uid('sm_'), t = now(); let state = 'submitted', message = '', missing = [], fp = null;
    if (b.adapter === 'livestream') { state = 'unsupported'; message = 'Live-stream ingest is planned but not implemented.'; }
    else if (b.adapter === 'cloud') {
      let h = ''; try { const x = new URL(b.url); h = x.protocol === 'https:' ? x.hostname : ''; } catch { /* invalid */ }
      if (!['drive.google.com', 'docs.google.com'].includes(h)) { state = 'unsupported'; message = 'Only Google Drive HTTPS links are supported.'; }
      else { state = 'pending_configuration'; missing = ['google_drive_connector']; message = 'Drive import needs the Google Drive connector. Upload the file directly instead.'; fp = `cloud:${b.url}`; }
    } else {
      const vid = ytId(b.url);
      if (!vid) { state = 'rejected'; message = 'Not a valid YouTube video URL.'; }
      else {
        fp = `youtube:${vid}`; state = 'validated'; message = 'URL is well formed. Access to the media stream has NOT been verified.';
        const acc = await ctx.env.DB.prepare("SELECT * FROM social_accounts WHERE user_id=? AND platform='youtube' AND status='connected'").bind(u.id).first();
        if (!acc) { state = 'pending_configuration'; missing = ['youtube_account']; message = 'Connect your YouTube account first. Only videos on your own channel can be authorised; for any other footage upload a file you have the rights to.'; }
        else {
          try {
            const { getAccessToken } = await import('../lib/tokens.js');
            const tok = await getAccessToken(ctx.env, acc);
            const res = await fetch(`https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${vid}`, { headers: { authorization: `Bearer ${tok}` } });
            const d = await res.json();
            if (!res.ok) throw new Error(d?.error?.message || `HTTP ${res.status}`);
            if (!d.items?.length) { state = 'rejected'; message = 'Video not found or not visible to your account.'; }
            else if (d.items[0].snippet.channelId !== acc.external_id) { state = 'rejected'; message = 'This video is not on your connected channel. Upload a rights-cleared file instead.'; }
            else { state = 'authorized'; message = 'Video belongs to your channel (authorised). No media provider is configured to fetch the stream, so it has not been imported; upload the original file to analyse it.'; }
          } catch (e) { state = 'validated'; message = `Ownership check failed: ${e.message}`; }
        }
      }
    }
    try {
      await ctx.env.DB.prepare('INSERT INTO source_media(id,project_id,user_id,adapter,state,source_url,fingerprint,message,missing_config,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
        .bind(id, p.id, u.id, b.adapter, state, b.url, fp, message, JSON.stringify(missing), t, t).run();
    } catch (e) { if (/UNIQUE/i.test(e.message)) throw conflict('This source was already added'); throw e; }
    return json({ source: { id, adapter: b.adapter, state, message, missing_config: missing } }, 201);
  });

  // Signed, range-capable media streaming (works inside <video> without cookies).
  r.get('/api/media/file', async ({ env, req, url }) => {
    const key = url.searchParams.get('key') || '', exp = Number(url.searchParams.get('exp')), dl = url.searchParams.get('dl') === '1', sig = url.searchParams.get('sig') || '';
    const want = await hmacHex(env.MEDIA_SIGNING_KEY || env.ENCRYPTION_KEY, `${key}|${exp}|${dl ? 1 : 0}`);
    if (!exp || exp < now() || !timingSafeEqual(sig, want)) throw new HttpError(403, 'Link expired or invalid');
    const range = req.headers.get('range');
    const obj = await store(env).get(key, range ? { range: req.headers } : undefined);
    if (!obj) throw notFound();
    const h = new Headers({ 'content-type': obj.httpMetadata?.contentType || 'video/mp4', 'accept-ranges': 'bytes', 'cache-control': 'private, max-age=300' });
    if (dl) h.set('content-disposition', 'attachment; filename="clip.mp4"');
    let status = 200;
    if (range && obj.range) { status = 206; const o = obj.range.offset ?? 0, l = obj.range.length ?? obj.size - o; h.set('content-range', `bytes ${o}-${o + l - 1}/${obj.size}`); h.set('content-length', String(l)); } else h.set('content-length', String(obj.size));
    return new Response(obj.body, { status, headers: h });
  }, { auth: false });

  r.get('/api/media/:id', async (ctx) => {
    const u = requireUser(ctx); const s = await owned(ctx.env, 'source_media', ctx.params.id, u.id);
    return json({ source: { ...s, r2_key: undefined, missing_config: s.missing_config ? JSON.parse(s.missing_config) : [], previewUrl: s.r2_key && ['validated', 'imported'].includes(s.state) ? await signMedia(ctx.env, s.r2_key) : null } });
  });

  // ---- analysis -----------------------------------------------------------------------------------
  r.post('/api/analyze', async (ctx) => {
    const u = requireUser(ctx); await rateLimit(ctx.env, `an:${u.id}`, 20, 3600);
    const b = validate(await readJson(ctx.req), { projectId: { type: 'string', required: true, pattern: ID }, sourceId: { type: 'string', required: true, pattern: ID },
      config: { type: 'object', props: { min_score: { type: 'number', min: 0, max: 100 }, max_candidates: { type: 'integer', min: 1, max: 50 }, min_duration: { type: 'number', min: 3, max: 180 },
        max_duration: { type: 'number', min: 5, max: 180 }, range_start: { type: 'number', min: 0 }, range_end: { type: 'number', min: 0 }, category: { type: 'string', max: 40 }, preferred_type: { type: 'string', enum: ['funny', 'surprising', 'emotional', 'story', 'action', 'general'] } } } });
    const p = await owned(ctx.env, 'projects', b.projectId, u.id); const s = await owned(ctx.env, 'source_media', b.sourceId, u.id);
    if (s.project_id !== p.id) throw badRequest('Source does not belong to this project');
    if (!s.r2_key || !['validated', 'imported'].includes(s.state)) throw conflict(`Source is "${s.state}" and has no stored media to analyse`, { message: s.message });
    const cfg = b.config || {}; if (cfg.min_duration && cfg.max_duration && cfg.max_duration < cfg.min_duration) throw badRequest('max_duration must be >= min_duration');
    const active = await ctx.env.DB.prepare("SELECT id FROM processing_jobs WHERE source_id=? AND kind='analyze' AND status IN ('queued','running')").bind(s.id).first();
    if (active) throw conflict('An analysis is already running for this source', { jobId: active.id });
    const { id, submitted } = await startAnalysis(ctx.env, u.id, p, s, cfg);
    return json({ job: { id, status: 'queued', submitted } }, 202);
  });

  r.get('/api/jobs/:id', async (ctx) => {
    const u = requireUser(ctx); const j = await owned(ctx.env, 'processing_jobs', ctx.params.id, u.id);
    return json({ job: j });
  });
  r.get('/api/jobs/:id/events', async (ctx) => {
    const u = requireUser(ctx); const j = await owned(ctx.env, 'processing_jobs', ctx.params.id, u.id);
    const after = Number(ctx.url.searchParams.get('after') || 0);
    const { results } = await ctx.env.DB.prepare('SELECT id,ts,level,message FROM job_events WHERE job_id=? AND id>? ORDER BY id LIMIT 200').bind(j.id, after).all();
    return json({ events: results });
  });
  r.post('/api/jobs/:id/cancel', async (ctx) => {
    const u = requireUser(ctx); const j = await owned(ctx.env, 'processing_jobs', ctx.params.id, u.id);
    if (!['queued', 'running'].includes(j.status)) throw conflict('Job is not active');
    if (j.engine_job_id && engineConfigured(ctx.env)) { try { await engine.cancel(ctx.env, j.engine_job_id); } catch { /* engine asleep: marked cancelled locally */ } }
    await ctx.env.DB.prepare("UPDATE processing_jobs SET status='cancelled', finished_at=?, updated_at=? WHERE id=?").bind(now(), now(), j.id).run();
    return json({ ok: true });
  });

  const momentRow = `SELECT m.*, s.total, s.hook, s.emotion, s.entertainment, s.unexpectedness, s.shareability, s.storytelling, s.confidence, s.explanation, s.signals
    FROM detected_moments m LEFT JOIN moment_scores s ON s.moment_id=m.id`;
  const fmtMoment = (m) => ({ id: m.id, rank: m.rank, start: m.start_s, end: m.end_s, duration: +(m.end_s - m.start_s).toFixed(2), type: m.moment_type, title: m.suggested_title, transcript: m.transcript,
    selected: !!m.selected, edited: !!m.user_edited, score: m.total, confidence: m.confidence, explanation: m.explanation,
    factors: { hook: m.hook, emotion: m.emotion, entertainment: m.entertainment, unexpectedness: m.unexpectedness, shareability: m.shareability, storytelling: m.storytelling } });

  r.get('/api/jobs/:id/moments', async (ctx) => {
    const u = requireUser(ctx); const j = await owned(ctx.env, 'processing_jobs', ctx.params.id, u.id);
    const { results } = await ctx.env.DB.prepare(`${momentRow} WHERE m.job_id=? ORDER BY m.rank`).bind(j.id).all();
    return json({ job: { id: j.id, status: j.status }, moments: results.map(fmtMoment) });
  });

  const momentOwned = async (ctx, id) => {
    const m = await ctx.env.DB.prepare(`${momentRow} WHERE m.id=?`).bind(id).first();
    if (!m) throw notFound(); await owned(ctx.env, 'projects', m.project_id, requireUser(ctx).id); return m;
  };

  r.patch('/api/moments/:id', async (ctx) => {
    const m = await momentOwned(ctx, ctx.params.id);
    const b = validate(await readJson(ctx.req), { start: { type: 'number', min: 0 }, end: { type: 'number', min: 0 }, selected: { type: 'boolean' }, title: { type: 'string', max: 200 } });
    const src = await ctx.env.DB.prepare('SELECT duration_s FROM source_media WHERE id=?').bind(m.source_id).first();
    const start = b.start ?? m.start_s, end = b.end ?? m.end_s;
    if (end - start < 3 || end - start > 180) throw badRequest('Clip length must be between 3 and 180 seconds');
    if (src?.duration_s && end > src.duration_s + 0.5) throw badRequest('End is beyond the end of the video');
    await ctx.env.DB.prepare('UPDATE detected_moments SET start_s=?, end_s=?, selected=?, suggested_title=?, user_edited=? WHERE id=?')
      .bind(start, end, b.selected === undefined ? m.selected : +b.selected, b.title ?? m.suggested_title, (b.start !== undefined || b.end !== undefined) ? 1 : m.user_edited, m.id).run();
    return json({ moment: fmtMoment(await ctx.env.DB.prepare(`${momentRow} WHERE m.id=?`).bind(m.id).first()) });
  });

  r.post('/api/moments/merge', async (ctx) => {
    const u = requireUser(ctx);
    const b = validate(await readJson(ctx.req), { ids: { type: 'array', required: true, max: 10, items: { type: 'string' } } });
    if (b.ids.length < 2) throw badRequest('Select at least two moments');
    const ms = []; for (const id of b.ids) ms.push(await momentOwned(ctx, id));
    if (new Set(ms.map((m) => m.job_id)).size > 1) throw badRequest('Moments must come from the same analysis');
    ms.sort((a, c) => a.start_s - c.start_s);
    for (let i = 1; i < ms.length; i++) if (ms[i].start_s - ms[i - 1].end_s > 5) throw badRequest('Only adjacent segments (gap of 5s or less) can be merged');
    const start = ms[0].start_s, end = Math.max(...ms.map((m) => m.end_s));
    if (end - start > 180) throw badRequest('Merged clip would exceed 180 seconds');
    const keep = ms.slice().sort((a, c) => (c.total ?? 0) - (a.total ?? 0))[0];
    await ctx.env.DB.batch([
      ctx.env.DB.prepare('UPDATE detected_moments SET start_s=?, end_s=?, user_edited=1, selected=1, transcript=? WHERE id=?').bind(start, end, ms.map((m) => m.transcript).join(' ').trim(), keep.id),
      ...ms.filter((m) => m.id !== keep.id).map((m) => ctx.env.DB.prepare('DELETE FROM detected_moments WHERE id=?').bind(m.id))]);
    return json({ moment: fmtMoment(await ctx.env.DB.prepare(`${momentRow} WHERE m.id=?`).bind(keep.id).first()), note: 'Scores describe the original window; use Reanalyse to rescore the merged range.' });
  });

  r.post('/api/moments/:id/reanalyse', async (ctx) => {
    const m = await momentOwned(ctx, ctx.params.id); const u = requireUser(ctx); await rateLimit(ctx.env, `an:${u.id}`, 20, 3600);
    const p = await owned(ctx.env, 'projects', m.project_id, u.id); const s = await owned(ctx.env, 'source_media', m.source_id, u.id);
    if (!s.r2_key) throw conflict('Source media is no longer stored');
    const active = await ctx.env.DB.prepare("SELECT id FROM processing_jobs WHERE source_id=? AND kind='analyze' AND status IN ('queued','running')").bind(s.id).first();
    if (active) throw conflict('An analysis is already running for this source', { jobId: active.id });
    const j = await ctx.env.DB.prepare('SELECT config FROM processing_jobs WHERE id=?').bind(m.job_id).first();
    const len = m.end_s - m.start_s;
    const cfg = { ...JSON.parse(j.config || '{}'), range_start: Math.max(0, m.start_s - 2), range_end: m.end_s + 2, min_duration: Math.max(3, Math.floor(len - 5)), max_duration: Math.min(180, Math.ceil(len + 5)) };
    const { id } = await startAnalysis(ctx.env, u.id, p, s, cfg);
    return json({ job: { id, status: 'queued' } }, 202);
  });

  // ---- clips -------------------------------------------------------------------------------------------
  const clipDefaults = async (env, userId) => {
    const s = await env.DB.prepare('SELECT default_resolution, subtitle_style FROM user_settings WHERE user_id=?').bind(userId).first();
    return { resolution: s.default_resolution, crop: { mode: 'smart' }, subtitles: { mode: 'standard', ...JSON.parse(s.subtitle_style || '{}') }, normalizeAudio: true };
  };
  const SETTINGS_SPEC = { resolution: { type: 'string', enum: ['1080p', '720p'] }, fps: { type: 'number', min: 10, max: 60 }, normalizeAudio: { type: 'boolean' }, titleOverlay: { type: 'string', max: 90 },
    crop: { type: 'object', props: { mode: { type: 'string', enum: ['center', 'smart', 'manual'] }, x: { type: 'number', min: 0, max: 1 }, y: { type: 'number', min: 0, max: 1 } } },
    subtitles: { type: 'object', props: { mode: { type: 'string', enum: ['none', 'standard', 'highlight', 'custom'] }, font: { type: 'string', max: 60 }, size: { type: 'integer', min: 16, max: 200 },
      color: { type: 'string', pattern: /^#[0-9A-Fa-f]{6}$/ }, highlight_color: { type: 'string', pattern: /^#[0-9A-Fa-f]{6}$/ }, outline_color: { type: 'string', pattern: /^#[0-9A-Fa-f]{6}$/ },
      outline: { type: 'integer', min: 0, max: 12 }, background: { type: 'boolean' }, position: { type: 'string', enum: ['bottom', 'middle', 'top'] }, max_words_per_line: { type: 'integer', min: 1, max: 10 } } } };

  async function createClip(ctx, m, settings) {
    const u = requireUser(ctx); const id = uid('c_'), t = now();
    const merged = { ...(await clipDefaults(ctx.env, u.id)), ...settings };
    const key = `u/${u.id}/${m.project_id}/clips/${id}.mp4`;
    await ctx.env.DB.prepare("INSERT INTO generated_clips(id,user_id,project_id,moment_id,source_id,title,start_s,end_s,settings,status,r2_key,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,'queued',?,?,?)")
      .bind(id, u.id, m.project_id, m.id, m.source_id, m.suggested_title, m.start_s, m.end_s, JSON.stringify(merged), key, t, t).run();
    const clip = await ctx.env.DB.prepare('SELECT * FROM generated_clips WHERE id=?').bind(id).first();
    if (engineConfigured(ctx.env)) { try { await submitRender(ctx.env, clip); } catch { /* cron retries submission */ } }
    return id;
  }

  r.post('/api/moments/:id/render', async (ctx) => {
    const m = await momentOwned(ctx, ctx.params.id); await rateLimit(ctx.env, `rn:${requireUser(ctx).id}`, 60, 3600);
    const b = validate(await readJson(ctx.req), SETTINGS_SPEC);
    return json({ clipId: await createClip(ctx, m, b) }, 202);
  });
  r.post('/api/moments/render-batch', async (ctx) => {
    requireUser(ctx); await rateLimit(ctx.env, `rn:${ctx.session.user.id}`, 60, 3600);
    const b = validate(await readJson(ctx.req), { ids: { type: 'array', required: true, max: 20, items: { type: 'string' } }, settings: { type: 'object', props: SETTINGS_SPEC } });
    const out = []; for (const id of b.ids) out.push(await createClip(ctx, await momentOwned(ctx, id), b.settings || {}));
    return json({ clipIds: out }, 202);
  });

  r.get('/api/clips', async (ctx) => {
    const u = requireUser(ctx); const pid = ctx.url.searchParams.get('projectId');
    const { results } = await ctx.env.DB.prepare(`SELECT id,project_id,moment_id,title,start_s,end_s,status,progress,duration_s,size_bytes,error,created_at FROM generated_clips WHERE user_id=? ${pid ? 'AND project_id=?' : ''} ORDER BY created_at DESC LIMIT 200`).bind(...(pid ? [u.id, pid] : [u.id])).all();
    return json({ clips: results });
  });
  r.get('/api/clips/:id', async (ctx) => {
    const u = requireUser(ctx); const c = await owned(ctx.env, 'generated_clips', ctx.params.id, u.id);
    const ready = c.status === 'ready' && c.r2_key;
    return json({ clip: { ...c, r2_key: undefined, settings: JSON.parse(c.settings || '{}'), previewUrl: ready ? await signMedia(ctx.env, c.r2_key) : null, downloadUrl: ready ? await signMedia(ctx.env, c.r2_key, 3600, true) : null } });
  });
  r.patch('/api/clips/:id', async (ctx) => {
    const u = requireUser(ctx); const c = await owned(ctx.env, 'generated_clips', ctx.params.id, u.id);
    if (['queued', 'rendering'].includes(c.status)) throw conflict('Clip is rendering');
    const b = validate(await readJson(ctx.req), { title: { type: 'string', max: 200 }, start_s: { type: 'number', min: 0 }, end_s: { type: 'number', min: 0 }, settings: { type: 'object', props: SETTINGS_SPEC } });
    const start = b.start_s ?? c.start_s, end = b.end_s ?? c.end_s;
    if (end - start < 3 || end - start > 180) throw badRequest('Clip length must be between 3 and 180 seconds');
    const live = await ctx.env.DB.prepare("SELECT COUNT(*) n FROM publishing_jobs WHERE clip_id=? AND status IN ('approved','scheduled','publishing')").bind(c.id).first();
    if (live.n && (b.start_s !== undefined || b.end_s !== undefined || b.settings)) throw conflict('This clip has an approved post; cancel it before changing the video');
    const settings = b.settings ? { ...JSON.parse(c.settings), ...b.settings } : JSON.parse(c.settings);
    const changed = b.start_s !== undefined || b.end_s !== undefined || b.settings;
    await ctx.env.DB.prepare('UPDATE generated_clips SET title=?, start_s=?, end_s=?, settings=?, status=?, updated_at=? WHERE id=?').bind(b.title ?? c.title, start, end, JSON.stringify(settings), changed ? 'draft' : c.status, now(), c.id).run();
    return json({ ok: true, needsRender: !!changed });
  });
  r.delete('/api/clips/:id', async (ctx) => {
    const u = requireUser(ctx); const c = await owned(ctx.env, 'generated_clips', ctx.params.id, u.id);
    const live = await ctx.env.DB.prepare("SELECT COUNT(*) n FROM publishing_jobs WHERE clip_id=? AND status IN ('approved','scheduled','publishing','needs_verification')").bind(c.id).first();
    if (live.n) throw conflict('Cancel the scheduled post first');
    if (c.r2_key) await store(ctx.env).delete(c.r2_key);
    await ctx.env.DB.prepare('DELETE FROM generated_clips WHERE id=?').bind(c.id).run();
    await audit(ctx.env, u.id, 'clip.delete', c.id, ctx.req);
    return json({ ok: true });
  });
  r.post('/api/clips/:id/render', async (ctx) => {
    const u = requireUser(ctx); const c = await owned(ctx.env, 'generated_clips', ctx.params.id, u.id);
    if (['queued', 'rendering'].includes(c.status)) throw conflict('Already rendering');
    await ctx.env.DB.prepare("UPDATE generated_clips SET status='queued', progress=0, error=NULL, engine_job_id=NULL, r2_key=COALESCE(r2_key, ?), updated_at=? WHERE id=?").bind(`u/${u.id}/${c.project_id}/clips/${c.id}.mp4`, now(), c.id).run();
    const clip = await ctx.env.DB.prepare('SELECT * FROM generated_clips WHERE id=?').bind(c.id).first();
    if (engineConfigured(ctx.env)) { try { await submitRender(ctx.env, clip); } catch { /* cron retries */ } }
    return json({ ok: true }, 202);
  });
}
