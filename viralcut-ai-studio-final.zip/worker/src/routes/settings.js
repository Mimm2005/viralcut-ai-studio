import { json, readJson, now, HttpError } from '../lib/http.js';
import { validate } from '../lib/validate.js';
import { requireUser } from '../lib/auth.js';
import { isValidTimezone } from '../lib/time.js';
import { audit } from '../lib/audit.js';
import { usageThisMonth } from '../lib/ai/gateway.js';
import { engine, engineConfigured } from '../lib/engine.js';
import { missingConfig } from '../lib/social/index.js';
import { KINDS } from '../lib/notify.js';

const parse = (s, d) => { try { return JSON.parse(s) ?? d; } catch { return d; } };
const fmt = (r) => ({ timezone: r.timezone, currency: r.currency, language: r.language, defaultResolution: r.default_resolution, subtitleStyle: parse(r.subtitle_style, {}),
  defaultPrivacy: r.default_privacy, queuePaused: !!r.queue_paused, retentionDays: r.retention_days, storageQuotaMb: r.storage_quota_mb, notifications: parse(r.notifications, {}), promptTemplates: parse(r.prompt_templates, {}) });

export async function storageUsage(env, userId) {
  const r = await env.DB.prepare('SELECT (SELECT COALESCE(SUM(size_bytes),0) FROM source_media WHERE user_id=?1) src, (SELECT COALESCE(SUM(size_bytes),0) FROM generated_clips WHERE user_id=?1) clips, (SELECT storage_quota_mb FROM user_settings WHERE user_id=?1) q').bind(userId).first();
  return { sourceBytes: r.src, clipBytes: r.clips, usedBytes: r.src + r.clips, quotaBytes: r.q * 1024 * 1024, percent: Math.round(((r.src + r.clips) / (r.q * 1024 * 1024)) * 1000) / 10 };
}

export function register(r) {
  r.get('/api/settings', async (ctx) => {
    const u = requireUser(ctx);
    const row = await ctx.env.DB.prepare('SELECT * FROM user_settings WHERE user_id=?').bind(u.id).first();
    return json({ settings: fmt(row), profile: u });
  });

  r.patch('/api/settings', async (ctx) => {
    const u = requireUser(ctx);
    const b = validate(await readJson(ctx.req), {
      timezone: { type: 'string', max: 60 }, language: { type: 'string', max: 10 }, defaultResolution: { type: 'string', enum: ['1080p', '720p'] },
      subtitleStyle: { type: 'object' }, defaultPrivacy: { type: 'string', enum: ['private', 'unlisted', 'public'] },
      retentionDays: { type: 'integer', min: 1, max: 3650 }, storageQuotaMb: { type: 'integer', min: 100, max: 1000000 },
      notifications: { type: 'object' }, promptTemplates: { type: 'object' }, displayName: { type: 'string', max: 80 } });
    if (b.timezone && !isValidTimezone(b.timezone)) throw new HttpError(400, 'Unknown timezone');
    if (b.notifications) for (const k of Object.keys(b.notifications)) if (!KINDS.includes(k) || typeof b.notifications[k] !== 'boolean') throw new HttpError(400, `Invalid notification setting ${k}`);
    const sets = [], vals = [];
    const map = { timezone: 'timezone', language: 'language', defaultResolution: 'default_resolution', defaultPrivacy: 'default_privacy', retentionDays: 'retention_days', storageQuotaMb: 'storage_quota_mb' };
    for (const [k, col] of Object.entries(map)) if (b[k] !== undefined) { sets.push(`${col}=?`); vals.push(b[k]); }
    for (const [k, col] of [['subtitleStyle', 'subtitle_style'], ['notifications', 'notifications'], ['promptTemplates', 'prompt_templates']]) if (b[k] !== undefined) { sets.push(`${col}=?`); vals.push(JSON.stringify(b[k])); }
    if (sets.length) await ctx.env.DB.prepare(`UPDATE user_settings SET ${sets.join(',')}, updated_at=? WHERE user_id=?`).bind(...vals, now(), u.id).run();
    if (b.displayName) await ctx.env.DB.prepare('UPDATE users SET display_name=?, updated_at=? WHERE id=?').bind(b.displayName, now(), u.id).run();
    await audit(ctx.env, u.id, 'settings.update', null, ctx.req, Object.keys(b));
    return json({ settings: fmt(await ctx.env.DB.prepare('SELECT * FROM user_settings WHERE user_id=?').bind(u.id).first()) });
  });

  r.get('/api/notifications', async (ctx) => {
    const u = requireUser(ctx);
    const { results } = await ctx.env.DB.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100').bind(u.id).all();
    return json({ notifications: results.map((n) => ({ ...n, read: !!n.read })), unread: results.filter((n) => !n.read).length });
  });
  r.post('/api/notifications/read', async (ctx) => {
    const u = requireUser(ctx);
    await ctx.env.DB.prepare('UPDATE notifications SET read=1 WHERE user_id=?').bind(u.id).run();
    return json({ ok: true });
  });

  r.get('/api/dashboard', async (ctx) => {
    const u = requireUser(ctx); const db = ctx.env.DB;
    const [projects, queue, clips, pubs, upcoming, counts, providers] = await Promise.all([
      db.prepare('SELECT id,name,status,created_at FROM projects WHERE user_id=? ORDER BY created_at DESC LIMIT 5').bind(u.id).all(),
      db.prepare("SELECT id,project_id,kind,status,progress,step,created_at FROM processing_jobs WHERE user_id=? AND status IN ('queued','running') ORDER BY created_at LIMIT 10").bind(u.id).all(),
      db.prepare("SELECT id,title,status,duration_s,created_at FROM generated_clips WHERE user_id=? ORDER BY created_at DESC LIMIT 6").bind(u.id).all(),
      db.prepare("SELECT id,platform,status,run_at,error FROM publishing_jobs WHERE user_id=? ORDER BY updated_at DESC LIMIT 6").bind(u.id).all(),
      db.prepare("SELECT COUNT(*) n FROM publishing_jobs WHERE user_id=? AND status IN ('scheduled','approved','publishing')").bind(u.id).first(),
      db.prepare('SELECT (SELECT COUNT(*) FROM projects WHERE user_id=?1) projects, (SELECT COUNT(*) FROM generated_clips WHERE user_id=?1 AND status=\'ready\') clips, (SELECT COUNT(*) FROM published_posts WHERE user_id=?1) posts').bind(u.id).first(),
      db.prepare('SELECT id,label,kind,model,status FROM ai_providers WHERE user_id=?').bind(u.id).all(),
    ]);
    const ai = [];
    for (const p of providers.results) ai.push({ ...p, usage: await usageThisMonth(ctx.env, p.id) });
    return json({ counts: { ...counts, scheduled: upcoming.n }, recentProjects: projects.results, queue: queue.results, recentClips: clips.results, recentPublishing: pubs.results, storage: await storageUsage(ctx.env, u.id), ai });
  });

  r.get('/api/costguard', async (ctx) => {
    const u = requireUser(ctx);
    const { results: providers } = await ctx.env.DB.prepare('SELECT * FROM ai_providers WHERE user_id=?').bind(u.id).all();
    const prov = [];
    for (const p of providers) {
      const usage = await usageThisMonth(ctx.env, p.id);
      const warn = [];
      if (p.monthly_call_limit && usage.calls >= p.monthly_call_limit * 0.8) warn.push('80% of the monthly call limit used');
      if (p.monthly_budget_inr && usage.costInr >= p.monthly_budget_inr * 0.8) warn.push('80% of the monthly budget used');
      if (p.cost_tier !== 'free') warn.push(p.cost_tier === 'paid' ? 'Paid provider: only used when it is the default/routed provider or explicitly allowed as fallback' : 'Cost tier unknown: set it so Cost Guard can protect you');
      if (usage.unpricedCalls) warn.push(`${usage.unpricedCalls} call(s) have no cost estimate because token prices were not entered`);
      prov.push({ id: p.id, label: p.label, kind: p.kind, costTier: p.cost_tier, allowFallback: !!p.allow_fallback, usage, limits: { calls: p.monthly_call_limit, budgetInr: p.monthly_budget_inr }, warnings: warn });
    }
    let eng = { configured: engineConfigured(ctx.env) };
    if (eng.configured) { try { eng = { configured: true, reachable: true, ...(await engine.health(ctx.env)) }; } catch (e) { eng = { configured: true, reachable: false, message: e.message }; } }
    return json({
      providers: prov, storage: await storageUsage(ctx.env, u.id), engine: eng,
      integrations: ['youtube', 'instagram', 'facebook', 'tiktok', 'x'].map((p) => ({ platform: p, missing: missingConfig(ctx.env, p) })),
      freeTierNotice: 'Free tiers have quotas and can change. Reference limits are listed in docs/FREE_TIER_LIMITATIONS.md; verify them on each provider\'s pricing page. This app never creates paid resources automatically.',
    });
  });
}
