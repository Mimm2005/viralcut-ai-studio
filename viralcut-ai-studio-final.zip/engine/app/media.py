"""FFmpeg / ffprobe helpers. All subprocess calls use argument lists (no shell)."""
from __future__ import annotations
import json
import shutil
import subprocess
from .models import MediaInfo

ALLOWED_EXTENSIONS = {".mp4", ".mov", ".webm", ".mkv", ".m4v"}


class MediaError(Exception):
    pass


def run(cmd: list[str], timeout: int = 3600) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as e:
        raise MediaError(f"command timed out: {cmd[0]}") from e
    except FileNotFoundError as e:
        raise MediaError(f"{cmd[0]} is not installed") from e


def probe(path: str) -> MediaInfo:
    r = run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", path], 60)
    if r.returncode != 0:
        raise MediaError(f"ffprobe failed: {r.stderr.strip()[:300]}")
    try:
        data = json.loads(r.stdout)
    except json.JSONDecodeError as e:
        raise MediaError("ffprobe returned invalid JSON") from e
    streams = data.get("streams", [])
    v = next((s for s in streams if s.get("codec_type") == "video"), None)
    a = next((s for s in streams if s.get("codec_type") == "audio"), None)
    fmt = data.get("format", {})
    duration = float(fmt.get("duration") or (v or {}).get("duration") or 0)
    fps = 0.0
    if v and v.get("avg_frame_rate") and v["avg_frame_rate"] != "0/0":
        n, d = v["avg_frame_rate"].split("/")
        fps = float(n) / float(d) if float(d) else 0.0
    return MediaInfo(
        duration=duration,
        width=int((v or {}).get("width", 0)),
        height=int((v or {}).get("height", 0)),
        fps=round(fps, 3),
        has_audio=a is not None,
        has_video=v is not None,
        size_bytes=int(fmt.get("size") or 0),
        video_codec=(v or {}).get("codec_name", ""),
        audio_codec=(a or {}).get("codec_name", ""),
        container=fmt.get("format_name", ""),
    )


def validate_media(info: MediaInfo, max_bytes: int, require_audio: bool = False) -> list[str]:
    """Returns a list of problems; empty list means valid."""
    problems = []
    if not info.has_video:
        problems.append("no video stream")
    if info.duration <= 0:
        problems.append("could not determine duration")
    if require_audio and not info.has_audio:
        problems.append("no audio stream")
    if info.size_bytes and info.size_bytes > max_bytes:
        problems.append(f"file larger than limit ({max_bytes // (1024 * 1024)} MB)")
    return problems


def extract_audio(src: str, dst_wav: str, start: float | None = None, duration: float | None = None) -> None:
    """16 kHz mono PCM WAV, the format Whisper expects."""
    cmd = ["ffmpeg", "-y", "-v", "error"]
    if start is not None:
        cmd += ["-ss", f"{start:.3f}"]
    if duration is not None:
        cmd += ["-t", f"{duration:.3f}"]
    cmd += ["-i", src, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", dst_wav]
    r = run(cmd)
    if r.returncode != 0:
        raise MediaError(f"audio extraction failed: {r.stderr.strip()[:300]}")


def extract_frames(src: str, out_dir: str, fps: float = 1.0, width: int = 320) -> int:
    """Low-resolution analysis frames at a configurable sampling rate."""
    import os
    os.makedirs(out_dir, exist_ok=True)
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", src, "-vf", f"fps={fps},scale={width}:-2",
           "-q:v", "5", os.path.join(out_dir, "f_%06d.jpg")]
    r = run(cmd)
    if r.returncode != 0:
        raise MediaError(f"frame extraction failed: {r.stderr.strip()[:300]}")
    return len([f for f in os.listdir(out_dir) if f.endswith(".jpg")])


def free_disk_mb(path: str) -> int:
    return int(shutil.disk_usage(path).free / (1024 * 1024))
