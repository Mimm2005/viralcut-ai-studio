"""ASS subtitle generation (standard, word-highlight and custom styling)."""
from __future__ import annotations
from .models import SubtitleStyle, Word

_ALIGN = {"bottom": 2, "middle": 5, "top": 8}
_MARGIN_V = {"bottom": 260, "middle": 0, "top": 220}


def ass_color(hex_color: str, alpha: int = 0) -> str:
    h = hex_color.lstrip("#")
    if len(h) != 6:
        raise ValueError(f"invalid colour {hex_color!r}")
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{alpha:02X}{b}{g}{r}".upper()


def _t(sec: float) -> str:
    sec = max(0.0, sec)
    cs = int(round(sec * 100))
    h, rem = divmod(cs, 360000)
    m, rem = divmod(rem, 6000)
    s, c = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{c:02d}"


def _esc(text: str) -> str:
    return text.replace("\\", "").replace("{", "(").replace("}", ")").replace("\n", " ")


def group_words(words: list[Word], max_words: int, max_gap: float = 0.9) -> list[list[Word]]:
    lines, cur = [], []
    for w in words:
        if cur and (len(cur) >= max_words or w.start - cur[-1].end > max_gap):
            lines.append(cur)
            cur = []
        cur.append(w)
    if cur:
        lines.append(cur)
    return lines


def build_ass(words: list[Word], style: SubtitleStyle, clip_start: float, clip_end: float,
              play_w: int = 1080, play_h: int = 1920) -> str:
    """Returns ASS text with times relative to the clip start. Empty string when no subtitles apply."""
    if style.mode == "none" or not words:
        return ""
    ws = [Word(start=max(0.0, w.start - clip_start), end=min(clip_end, w.end) - clip_start, text=_esc(w.text), prob=w.prob)
          for w in words if w.end > clip_start and w.start < clip_end and w.text.strip()]
    ws = [w for w in ws if w.end > w.start]
    if not ws:
        return ""
    scale = play_h / 1920
    border_style = 3 if style.background else 1
    back = ass_color("#000000", 0x60) if style.background else ass_color(style.outline_color)
    primary = ass_color(style.highlight_color if style.mode in ("highlight", "custom") else style.color)
    secondary = ass_color(style.color)
    header = (
        "[Script Info]\nScriptType: v4.00+\n"
        f"PlayResX: {play_w}\nPlayResY: {play_h}\nWrapStyle: 0\nScaledBorderAndShadow: yes\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, "
        "Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, "
        "MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Default,{style.font},{int(style.size * scale)},{primary},{secondary},{ass_color(style.outline_color)},"
        f"{back},-1,0,0,0,100,100,0,0,{border_style},{int(style.outline * scale)},0,{_ALIGN[style.position]},"
        f"60,60,{int(_MARGIN_V[style.position] * scale)},1\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )
    events = []
    for line in group_words(ws, style.max_words_per_line):
        start, end = line[0].start, line[-1].end
        if style.mode == "standard":
            text = " ".join(w.text for w in line)
        else:  # highlight / custom: karaoke sweep word by word
            parts = []
            for i, w in enumerate(line):
                nxt = line[i + 1].start if i + 1 < len(line) else w.end
                cs = max(1, int(round((max(nxt, w.end) - w.start) * 100)))
                parts.append(f"{{\\kf{cs}}}{w.text}")
            text = " ".join(parts)
        events.append(f"Dialogue: 0,{_t(start)},{_t(end)},Default,,0,0,0,,{text}")
    return header + "\n".join(events) + "\n"
