"""Engine configuration. Every value comes from environment variables; nothing is hardcoded."""
from __future__ import annotations
import os
from dataclasses import dataclass, field


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except ValueError:
        return default


@dataclass
class Settings:
    data_dir: str = field(default_factory=lambda: os.environ.get("VC_DATA_DIR", "/tmp/viralcut"))
    engine_token: str = field(default_factory=lambda: os.environ.get("ENGINE_TOKEN", ""))
    whisper_model: str = field(default_factory=lambda: os.environ.get("WHISPER_MODEL", "tiny"))
    whisper_compute: str = field(default_factory=lambda: os.environ.get("WHISPER_COMPUTE", "int8"))
    max_upload_mb: int = field(default_factory=lambda: _int("MAX_UPLOAD_MB", 1024))
    chunk_seconds: int = field(default_factory=lambda: _int("CHUNK_SECONDS", 300))
    frame_sample_fps: float = field(default_factory=lambda: _float("FRAME_SAMPLE_FPS", 1.0))
    lease_seconds: int = field(default_factory=lambda: _int("JOB_LEASE_SECONDS", 120))
    max_attempts: int = field(default_factory=lambda: _int("JOB_MAX_ATTEMPTS", 3))
    min_free_disk_mb: int = field(default_factory=lambda: _int("MIN_FREE_DISK_MB", 500))

    def path(self, *parts: str) -> str:
        p = os.path.join(self.data_dir, *parts)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        return p


def get_settings() -> Settings:
    return Settings()
