"""Measurable audio and visual signals. Everything here is deterministic and testable.

Honesty note: `laughter` is a HEURISTIC proxy (energy bursts modulated at ~3-9 Hz with
broadband content). It is not a trained classifier and carries low confidence.
"""
from __future__ import annotations
import wave
from dataclasses import dataclass, field
import numpy as np

WIN = 0.5  # seconds per audio feature window


@dataclass
class AudioSignals:
    win: float = WIN
    rms: np.ndarray = field(default_factory=lambda: np.zeros(0))
    energy_z: np.ndarray = field(default_factory=lambda: np.zeros(0))
    silence: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=bool))
    laughter: np.ndarray = field(default_factory=lambda: np.zeros(0))
    available: bool = False

    def slice(self, start: float, end: float) -> slice:
        n = len(self.rms)
        a = max(0, min(n, int(start / self.win)))
        b = max(a, min(n, int(np.ceil(end / self.win))))
        return slice(a, b)


@dataclass
class VisualSignals:
    scene_cuts: list[float] = field(default_factory=list)
    motion: np.ndarray = field(default_factory=lambda: np.zeros(0))  # per sample, normalised 0..1
    sample_fps: float = 1.0
    available: bool = False

    def motion_slice(self, start: float, end: float) -> np.ndarray:
        if not len(self.motion):
            return np.zeros(0)
        a = max(0, int(start * self.sample_fps))
        b = min(len(self.motion), max(a + 1, int(np.ceil(end * self.sample_fps))))
        return self.motion[a:b]


def read_wav(path: str) -> tuple[np.ndarray, int]:
    with wave.open(path, "rb") as w:
        sr = w.getframerate()
        n = w.getnframes()
        ch = w.getnchannels()
        sw = w.getsampwidth()
        if sw != 2:
            raise ValueError("expected 16-bit PCM wav")
        raw = w.readframes(n)
    a = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    if ch > 1:
        a = a.reshape(-1, ch).mean(axis=1)
    return a, sr


def audio_signals_from_samples(x: np.ndarray, sr: int, win: float = WIN) -> AudioSignals:
    if len(x) == 0:
        return AudioSignals(win=win)
    hop = int(sr * win)
    n = len(x) // hop
    if n == 0:
        return AudioSignals(win=win)
    frames = x[: n * hop].reshape(n, hop)
    rms = np.sqrt((frames ** 2).mean(axis=1) + 1e-12)
    log = np.log10(rms + 1e-6)
    med = np.median(log)
    mad = np.median(np.abs(log - med)) * 1.4826 + 1e-6
    z = (log - med) / mad
    silence = rms < max(0.003, 0.25 * float(np.median(rms)))
    # laughter proxy: rapid amplitude modulation (3-9 Hz) at high energy
    laugh = np.zeros(n)
    sub = max(1, hop // 20)  # 20 sub-windows per 0.5 s => 40 Hz envelope rate
    for i in range(n):
        f = frames[i][: (hop // sub) * sub].reshape(-1, sub)
        env = np.sqrt((f ** 2).mean(axis=1))
        if env.mean() < 0.01:
            continue
        env = env - env.mean()
        spec = np.abs(np.fft.rfft(env * np.hanning(len(env)))) ** 2
        freqs = np.fft.rfftfreq(len(env), d=sub / sr)
        band = spec[(freqs >= 3) & (freqs <= 9)].sum()
        tot = spec[1:].sum() + 1e-12
        laugh[i] = float(min(1.0, (band / tot) * 1.5)) * float(min(1.0, z[i] / 2 if z[i] > 0 else 0))
    return AudioSignals(win=win, rms=rms, energy_z=z, silence=silence, laughter=laugh, available=True)


def audio_signals(wav_path: str) -> AudioSignals:
    x, sr = read_wav(wav_path)
    return audio_signals_from_samples(x, sr)


def detect_scenes(video_path: str, threshold: float = 27.0) -> list[float]:
    """Scene cut timestamps (seconds). PySceneDetect first, OpenCV histogram fallback."""
    try:
        from scenedetect import detect, ContentDetector
        scenes = detect(video_path, ContentDetector(threshold=threshold))
        return [round(s[0].get_seconds(), 3) for s in scenes[1:]]
    except Exception:
        return _scene_fallback(video_path)


def _scene_fallback(video_path: str, sample_fps: float = 4.0, thresh: float = 0.5) -> list[float]:
    import cv2
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return []
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    step = max(1, int(round(fps / sample_fps)))
    cuts, prev, i = [], None, 0
    while True:
        ok = cap.grab()
        if not ok:
            break
        if i % step == 0:
            ok, frame = cap.retrieve()
            if ok:
                small = cv2.resize(frame, (160, 90))
                hist = cv2.calcHist([small], [0, 1, 2], None, [8, 8, 8], [0, 256] * 3)
                cv2.normalize(hist, hist)
                if prev is not None and cv2.compareHist(prev, hist, cv2.HISTCMP_BHATTACHARYYA) > thresh:
                    cuts.append(round(i / fps, 3))
                prev = hist
        i += 1
    cap.release()
    return cuts


def motion_signal(video_path: str, sample_fps: float = 1.0, width: int = 160) -> np.ndarray:
    """Mean absolute frame difference at sampled frames, normalised to 0..1 by the 95th percentile."""
    import cv2
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return np.zeros(0)
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    step = max(1, int(round(fps / sample_fps)))
    vals, prev, i = [], None, 0
    while True:
        if not cap.grab():
            break
        if i % step == 0:
            ok, frame = cap.retrieve()
            if ok:
                g = cv2.cvtColor(cv2.resize(frame, (width, int(width * 9 / 16))), cv2.COLOR_BGR2GRAY)
                vals.append(0.0 if prev is None else float(np.abs(g.astype(np.int16) - prev.astype(np.int16)).mean()))
                prev = g
        i += 1
    cap.release()
    arr = np.array(vals, dtype=np.float32)
    if not len(arr):
        return arr
    p95 = np.percentile(arr, 95)
    return np.clip(arr / p95, 0, 1) if p95 > 0 else arr


def visual_signals(video_path: str, sample_fps: float = 1.0) -> VisualSignals:
    cuts = detect_scenes(video_path)
    mot = motion_signal(video_path, sample_fps)
    return VisualSignals(scene_cuts=cuts, motion=mot, sample_fps=sample_fps, available=len(mot) > 0)


def saliency_center_x(video_path: str, start: float, end: float, samples: int = 8) -> float:
    """Horizontal centre (0..1) of visual interest for smart crop.

    Uses face detection (OpenCV Haar cascade) when faces are found, otherwise the
    centroid of motion energy, otherwise 0.5. Never assumes a face exists.
    """
    import cv2
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return 0.5
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    cascade = None
    try:
        import os
        path = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
        if os.path.isfile(path):          # some OpenCV builds ship without the cascade: fall back to motion
            cascade = cv2.CascadeClassifier(path)
            if cascade.empty():
                cascade = None
    except Exception:
        cascade = None
    face_x, motion_acc, w_acc, prev = [], None, 0, None
    times = np.linspace(start, max(start, end - 0.05), samples)
    for t in times:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(t * fps))
        ok, frame = cap.read()
        if not ok:
            continue
        h, w = frame.shape[:2]
        scale = 320 / w
        small = cv2.resize(frame, (320, int(h * scale)))
        g = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        if cascade is not None:
            faces = cascade.detectMultiScale(g, 1.2, 5, minSize=(24, 24))
            for (x, y, fw, fh) in faces:
                face_x.append((x + fw / 2) / g.shape[1])
        if prev is not None and prev.shape == g.shape:
            d = np.abs(g.astype(np.int16) - prev.astype(np.int16)).astype(np.float32)
            col = d.sum(axis=0)
            motion_acc = col if motion_acc is None else motion_acc + col
            w_acc += 1
        prev = g
    cap.release()
    if face_x:
        return float(np.clip(np.median(face_x), 0, 1))
    if motion_acc is not None and motion_acc.sum() > 0:
        xs = np.arange(len(motion_acc))
        return float(np.clip((xs * motion_acc).sum() / motion_acc.sum() / len(motion_acc), 0, 1))
    return 0.5
