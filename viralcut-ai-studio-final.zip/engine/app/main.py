"""FastAPI service. The Worker calls this; it is never exposed to browsers directly."""
from __future__ import annotations
import hmac
import logging
import os
import shutil
import threading
import time
from contextlib import asynccontextmanager
from typing import Literal, Optional
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from .config import get_settings
from .jobs import JobStore
from .pipeline import Runner
from . import media, sources

log = logging.getLogger("viralcut")
settings = get_settings()
store: JobStore | None = None
runner: Runner | None = None
_stop = threading.Event()
_last_tick = 0.0


def init(model_factory=None, start_worker=True):
    global store, runner
    os.makedirs(settings.data_dir, exist_ok=True)
    store = JobStore(os.path.join(settings.data_dir, "jobs.db"), settings.lease_seconds, settings.max_attempts)
    runner = Runner(store, settings, model_factory)
    if start_worker:
        threading.Thread(target=_loop, daemon=True, name="job-loop").start()


def _loop():
    global _last_tick
    while not _stop.is_set():
        _last_tick = time.time()
        try:
            store.recover_expired()
            job = store.claim()
            if job:
                runner.run(job)
                continue
        except Exception:  # noqa: BLE001
            log.exception("job loop error")
        _stop.wait(2.0)


@asynccontextmanager
async def lifespan(app: FastAPI):
    if store is None:
        init()
    yield
    _stop.set()


app = FastAPI(title="ViralCut Engine", version="1.0.0", lifespan=lifespan)


def auth(authorization: Optional[str] = Header(None)):
    tok = settings.engine_token
    if not tok:
        raise HTTPException(503, "ENGINE_TOKEN is not configured")
    supplied = (authorization or "").removeprefix("Bearer ").strip()
    if not hmac.compare_digest(supplied, tok):
        raise HTTPException(401, "unauthorized")


class JobIn(BaseModel):
    id: Optional[str] = Field(None, pattern=r"^[A-Za-z0-9_-]{6,64}$")
    kind: Literal["analyze", "render"]
    payload: dict


class ValidateIn(BaseModel):
    adapter: str
    source: dict
    config: dict = Field(default_factory=dict)


@app.get("/health")
def health():
    return {"status": "ok", "version": "1.0.0", "jobs": store.counts(),
            "free_disk_mb": media.free_disk_mb(settings.data_dir),
            "worker_loop_age_s": round(time.time() - _last_tick, 1) if _last_tick else None,
            "whisper_model": settings.whisper_model}


@app.post("/sources/validate", dependencies=[Depends(auth)])
def validate_source(body: ValidateIn):
    try:
        ad = sources.get_adapter(body.adapter)
    except KeyError:
        raise HTTPException(400, "unknown adapter")
    r = ad.authorize(body.source, body.config) if body.config else ad.validate(body.source)
    return {"state": r.state.value, "adapter": r.adapter, "message": r.message, "metadata": r.metadata,
            "fingerprint": r.fingerprint, "missing_config": r.missing_config}


@app.post("/jobs", status_code=202, dependencies=[Depends(auth)])
def create_job(body: JobIn):
    jid = store.enqueue(body.kind, body.payload, body.id)
    return {"id": jid, "status": store.get(jid)["status"]}


@app.get("/jobs/{jid}", dependencies=[Depends(auth)])
def get_job(jid: str, include_result: bool = True):
    j = store.get(jid)
    if not j:
        raise HTTPException(404, "job not found")
    out = {k: j[k] for k in ("id", "kind", "status", "progress", "step", "attempts", "max_attempts", "error",
                             "created_at", "updated_at", "heartbeat")}
    if include_result and j["status"] == "succeeded":
        out["result"] = j["result"]
    return out


@app.get("/jobs/{jid}/events", dependencies=[Depends(auth)])
def job_events(jid: str, after: int = 0):
    if not store.get(jid):
        raise HTTPException(404, "job not found")
    return {"events": store.events(jid, after)}


@app.post("/jobs/{jid}/cancel", dependencies=[Depends(auth)])
def cancel(jid: str):
    if not store.cancel(jid):
        raise HTTPException(409, "job cannot be cancelled")
    return {"ok": True}


@app.get("/jobs/{jid}/output", dependencies=[Depends(auth)])
def output(jid: str):
    j = store.get(jid)
    if not j or j["status"] != "succeeded" or not j.get("result"):
        raise HTTPException(404, "no output")
    p = j["result"].get("output_path")
    if not p or not os.path.isfile(p):
        raise HTTPException(404, "output not stored locally (uploaded to object storage)")
    return FileResponse(p, media_type="video/mp4")


@app.delete("/jobs/{jid}/work", dependencies=[Depends(auth)])
def cleanup(jid: str):
    shutil.rmtree(os.path.join(settings.data_dir, "work", jid), ignore_errors=True)
    return {"ok": True}
