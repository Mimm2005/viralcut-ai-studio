"""Candidate moment generation, scoring, ranking and de-duplication."""
from __future__ import annotations
import re
import numpy as np
from .models import AnalysisConfig, FactorScores, Moment, Transcript, Segment
from .signals import AudioSignals, VisualSignals
from . import scoring

SURPRISE = {"wait", "what", "whoa", "wow", "no way", "oh my god", "omg", "unbelievable", "impossible",
            "didn't expect", "can't believe", "suddenly", "oh no", "what the", "seriously", "holy"}
HUMOR = {"haha", "lol", "funny", "hilarious", "joke", "laughing", "laugh", "lmao", "kidding"}
EMOTION = {"love", "hate", "amazing", "terrible", "scared", "angry", "crying", "happy", "excited", "insane",
           "crazy", "awesome", "worst", "best", "incredible", "shocked", "afraid", "sad", "furious"}
HOOK_OPENERS = {"so", "listen", "imagine", "guess", "you", "never", "nobody", "everyone", "here's", "this",
                "today", "watch", "look", "okay", "ok", "stop", "wait", "what"}
TYPE_RULES = [("funny", "humor_terms", "laughter"), ("surprising", "surprise_terms", "unexpected"),
              ("emotional", "emotion_terms", "emotion")]
_SENT_END = re.compile(r"[.!?…][\"')\]]*$")


def _terms(text: str, vocab: set[str]) -> list[str]:
    t = text.lower()
    found = []
    for v in vocab:
        if " " in v:
            if v in t:
                found.append(v)
        elif re.search(rf"\b{re.escape(v)}\b", t):
            found.append(v)
    return sorted(found)


def _sig(a: float, k: float) -> float:
    """Smooth 0..100 saturation: a/(a+k)."""
    a = max(a, 0.0)
    return 100.0 * a / (a + k)


def boundaries(tr: Transcript) -> tuple[list[float], list[float]]:
    """Candidate start times (segment starts) and end times (segment ends that finish a sentence)."""
    starts = [s.start for s in tr.segments]
    ends = [s.end for s in tr.segments]
    return starts, ends


def window_text(tr: Transcript, start: float, end: float) -> tuple[str, list[Segment]]:
    segs = [s for s in tr.segments if s.end > start and s.start < end]
    return " ".join(s.text for s in segs), segs


def compute_features(tr: Transcript, au: AudioSignals, vis: VisualSignals, start: float, end: float) -> dict:
    dur = end - start
    text, segs = window_text(tr, start, end)
    words = text.split()
    sig: dict = {"word_count": len(words), "duration": round(dur, 2)}
    sig["surprise_terms"] = _terms(text, SURPRISE)
    sig["humor_terms"] = _terms(text, HUMOR)
    sig["emotion_terms"] = _terms(text, EMOTION)
    sig["exclamations"] = text.count("!")
    sig["questions"] = text.count("?")
    sig["starts_at_sentence"] = bool(segs) and abs(segs[0].start - start) < 1.0
    sig["ends_at_sentence"] = bool(segs) and bool(_SENT_END.search(segs[-1].text.strip())) and abs(segs[-1].end - end) < 1.5
    first = segs[0].text.lower().split() if segs else []
    sig["hook_opener"] = bool(first) and first[0].strip(",.!?") in HOOK_OPENERS
    sig["first_is_question"] = bool(segs) and "?" in segs[0].text
    if au.available:
        sl = au.slice(start, end)
        z = au.energy_z[sl]
        if len(z):
            sig["peak_energy_z"] = float(z.max())
            sig["mean_energy_z"] = float(z.mean())
            sig["silence_ratio"] = float(au.silence[sl].mean())
            sig["laughter_max"] = float(au.laughter[sl].max())
            h = au.slice(start, start + 3)
            hz = au.energy_z[h]
            sig["hook_energy_z"] = float(hz.mean()) if len(hz) else 0.0
            pre = au.slice(max(0, start - 10), start)
            pz = au.energy_z[pre]
            sig["energy_jump"] = float(z.max() - (pz.mean() if len(pz) else 0.0))
            third = max(1, len(z) // 3)
            sig["arc"] = float(z[-third:].mean() - z[:third].mean())  # build-up => payoff late
            sig["payoff_late"] = bool(int(np.argmax(z)) >= len(z) * 0.5)
    if vis.available or vis.scene_cuts:
        m = vis.motion_slice(start, end)
        sig["motion_mean"] = float(m.mean()) if len(m) else 0.0
        sig["motion_peak"] = float(m.max()) if len(m) else 0.0
        sig["scene_cuts"] = sum(1 for c in vis.scene_cuts if start <= c <= end)
        sig["early_cut"] = any(start <= c <= start + 3 for c in vis.scene_cuts)
    return sig


def score_features(sig: dict, has_audio: bool, has_visual: bool) -> FactorScores:
    # Hook (first ~3 s)
    hook = 20.0
    hook += 25 if sig.get("hook_opener") else 0
    hook += 20 if sig.get("first_is_question") else 0
    hook += min(25, max(0.0, sig.get("hook_energy_z", 0.0)) * 12)
    hook += 10 if sig.get("early_cut") else 0
    hook += 10 if sig.get("starts_at_sentence") else 0
    # Emotion
    emo = _sig(max(0.0, sig.get("peak_energy_z", 0.0)), 3.0) * 0.55
    emo += min(30, len(sig.get("emotion_terms", [])) * 10 + sig.get("exclamations", 0) * 4)
    emo += 15 * min(1.0, max(0.0, sig.get("mean_energy_z", 0.0)) / 1.5)
    # Entertainment
    ent = 100.0 * sig.get("laughter_max", 0.0) * 0.45
    ent += min(30, len(sig.get("humor_terms", [])) * 15)
    ent += 20 * sig.get("motion_mean", 0.0)
    ent += min(15, sig.get("scene_cuts", 0) * 3)
    ent += 10 * (1 - min(1.0, sig.get("silence_ratio", 0.5)))
    # Unexpectedness
    unx = _sig(max(0.0, sig.get("energy_jump", 0.0)), 3.0) * 0.5
    unx += min(35, len(sig.get("surprise_terms", [])) * 17)
    unx += 25 * sig.get("motion_peak", 0.0)
    # Shareability: self-contained, right length, dense
    d = sig.get("duration", 30)
    fit = 100.0 if 15 <= d <= 45 else max(20.0, 100 - abs(d - 30) * 2.5)
    sh = fit * 0.40
    sh += 20 if sig.get("starts_at_sentence") else 0
    sh += 20 if sig.get("ends_at_sentence") else 0
    wps = sig.get("word_count", 0) / max(d, 1.0)
    sh += 20 if 1.0 <= wps <= 4.0 else 8 if wps > 0 else 0
    # Storytelling: setup -> payoff
    st = 15.0
    st += 30 if sig.get("payoff_late") else 0
    st += 25 * min(1.0, max(0.0, sig.get("arc", 0.0)) / 1.5)
    st += 15 if sig.get("ends_at_sentence") else 0
    st += 15 if sig.get("word_count", 0) >= 25 else 0
    c = scoring.clamp
    return FactorScores(hook=c(hook), emotion=c(emo), entertainment=c(ent), unexpectedness=c(unx),
                        shareability=c(sh), storytelling=c(st))


def classify(sig: dict, f: FactorScores) -> str:
    if sig.get("humor_terms") or sig.get("laughter_max", 0) >= 0.5:
        return "funny"
    if f.unexpectedness >= max(f.emotion, f.storytelling) and f.unexpectedness > 40:
        return "surprising"
    if f.emotion >= 50:
        return "emotional"
    if f.storytelling >= 55:
        return "story"
    if sig.get("motion_mean", 0) >= 0.6:
        return "action"
    return "general"


def make_title(text: str, max_len: int = 70) -> str:
    t = re.sub(r"\s+", " ", text).strip()
    if not t:
        return "Untitled moment"
    first = re.split(r"(?<=[.!?])\s", t)[0]
    if len(first) > max_len:
        first = first[: max_len - 1].rsplit(" ", 1)[0] + "…"
    return first[:1].upper() + first[1:]


def overlap_ratio(a: Moment, b: Moment) -> float:
    inter = max(0.0, min(a.end, b.end) - max(a.start, b.start))
    return inter / max(1e-6, min(a.duration, b.duration))


def dedupe(moments: list[Moment], max_overlap: float = 0.3) -> list[Moment]:
    """Greedy non-maximum suppression by score."""
    kept: list[Moment] = []
    for m in sorted(moments, key=lambda x: x.score, reverse=True):
        if all(overlap_ratio(m, k) <= max_overlap for k in kept):
            kept.append(m)
    return kept


def generate_candidates(tr: Transcript, au: AudioSignals, vis: VisualSignals, total_duration: float,
                        cfg: AnalysisConfig) -> list[Moment]:
    starts, ends = boundaries(tr)
    if not starts:
        # No speech: fall back to fixed-grid windows so visual/audio-only content still works.
        starts = [float(t) for t in np.arange(0, max(0.0, total_duration - cfg.min_duration), 5.0)]
        ends = [s + cfg.min_duration for s in starts]
    target_ds = sorted({cfg.min_duration, (cfg.min_duration + cfg.max_duration) / 2, cfg.max_duration})
    has_tr = bool(tr.segments)
    out: list[Moment] = []
    seen = set()
    for s in starts:
        if cfg.range_start is not None and not (cfg.range_start - 1.0 <= s <= cfg.range_end - cfg.min_duration + 1.0):
            continue
        for d in target_ds:
            e_ideal = min(total_duration, s + d)
            if e_ideal - s < cfg.min_duration - 0.01:
                continue
            # snap end to nearest sentence end within +-4 s (never beyond max)
            cands = [x for x in ends if abs(x - e_ideal) <= 4 and cfg.min_duration <= x - s <= cfg.max_duration]
            e = min(cands, key=lambda x: abs(x - e_ideal)) if cands else e_ideal
            key = (round(s, 1), round(e, 1))
            if cfg.range_end is not None and e > cfg.range_end + 4.0:
                continue
            if key in seen or e - s < cfg.min_duration - 0.01 or e - s > cfg.max_duration + 0.01:
                continue
            seen.add(key)
            sig = compute_features(tr, au, vis, s, e)
            f = score_features(sig, au.available, vis.available)
            total = scoring.total_score(f)
            conf = scoring.confidence(has_tr, au.available, vis.available or bool(vis.scene_cuts),
                                      sig["word_count"], e - s)
            mtype = classify(sig, f)
            text, _ = window_text(tr, s, e)
            out.append(Moment(start=round(s, 2), end=round(e, 2), score=total, factors=f, confidence=conf,
                              explanation=scoring.explain(f, sig, mtype), moment_type=mtype,
                              transcript=text, suggested_title=make_title(text), signals=_jsonable(sig)))
    return out


def _jsonable(d: dict) -> dict:
    return {k: (float(v) if isinstance(v, (np.floating,)) else bool(v) if isinstance(v, np.bool_) else v)
            for k, v in d.items()}


def rank_moments(candidates: list[Moment], cfg: AnalysisConfig) -> list[Moment]:
    pool = [m for m in candidates if m.score >= cfg.min_score]
    if cfg.preferred_type:
        for m in pool:
            if m.moment_type == cfg.preferred_type:
                m.score = round(min(100.0, m.score), 1)  # no artificial boost; filter only below
        typed = [m for m in pool if m.moment_type == cfg.preferred_type]
        pool = typed if len(typed) >= 3 else pool
    kept = dedupe(pool)
    kept.sort(key=lambda m: (m.score, m.confidence), reverse=True)
    return kept[: cfg.max_candidates]


def analyse(tr: Transcript, au: AudioSignals, vis: VisualSignals, total_duration: float,
            cfg: AnalysisConfig | None = None) -> list[Moment]:
    cfg = cfg or AnalysisConfig()
    return rank_moments(generate_candidates(tr, au, vis, total_duration, cfg), cfg)
