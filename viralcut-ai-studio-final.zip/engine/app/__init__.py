"""ViralCut processing engine."""
__version__ = "1.0.0"
