"""Pluggable source adapters.

A submitted URL, a validated source, an authorized stream and a completed import are
four DIFFERENT states. An adapter never claims a later state than it has actually reached.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Protocol


class SourceState(str, Enum):
    SUBMITTED = "submitted"
    VALIDATED = "validated"
    AUTHORIZED = "authorized"
    IMPORTED = "imported"
    PENDING_CONFIGURATION = "pending_configuration"
    REJECTED = "rejected"
    UNSUPPORTED = "unsupported"


@dataclass
class SourceResult:
    state: SourceState
    adapter: str
    message: str = ""
    metadata: dict = field(default_factory=dict)
    local_path: str | None = None
    fingerprint: str | None = None  # used for duplicate source detection
    missing_config: list[str] = field(default_factory=list)


class SourceAdapter(Protocol):
    name: str

    def validate(self, source: dict) -> SourceResult: ...
    def authorize(self, source: dict, config: dict) -> SourceResult: ...
    def fetch(self, source: dict, config: dict, dest_dir: str) -> SourceResult: ...


registry: dict[str, SourceAdapter] = {}


def register(adapter: SourceAdapter) -> SourceAdapter:
    registry[adapter.name] = adapter
    return adapter


def get_adapter(name: str) -> SourceAdapter:
    if name not in registry:
        raise KeyError(f"unknown source adapter: {name}")
    return registry[name]
