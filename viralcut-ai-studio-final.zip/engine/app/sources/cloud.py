"""Authorized cloud media import (Google Drive / S3-compatible). Requires user credentials."""
from __future__ import annotations
from urllib.parse import urlparse
from .base import SourceResult, SourceState, register


class CloudAdapter:
    name = "cloud"
    _hosts = {"drive.google.com", "docs.google.com"}

    def validate(self, source: dict) -> SourceResult:
        u = urlparse(source.get("url", ""))
        if u.scheme != "https" or (u.hostname or "") not in self._hosts:
            return SourceResult(SourceState.UNSUPPORTED, self.name, "only Google Drive HTTPS links are supported")
        return SourceResult(SourceState.VALIDATED, self.name, "URL well formed; access not verified",
                            fingerprint=f"cloud:{u.path}:{u.query}")

    def authorize(self, source: dict, config: dict) -> SourceResult:
        r = self.validate(source)
        if r.state != SourceState.VALIDATED:
            return r
        if not config.get("google_drive_token"):
            r.state = SourceState.PENDING_CONFIGURATION
            r.missing_config = ["google_drive_token"]
            r.message = "connect Google Drive to import this file"
            return r
        r.state = SourceState.AUTHORIZED
        return r

    def fetch(self, source: dict, config: dict, dest_dir: str) -> SourceResult:
        r = self.authorize(source, config)
        if r.state == SourceState.AUTHORIZED:
            r.state = SourceState.PENDING_CONFIGURATION
            r.missing_config = ["drive_download_implementation"]
            r.message = "Drive download is performed by the Worker connector; not available in the engine"
        return r


register(CloudAdapter())
