"""YouTube adapter.

Validating a YouTube URL only proves the URL is well formed. This adapter NEVER downloads
anything by itself and never circumvents access controls. A video becomes AUTHORIZED only
when the owner has connected Google OAuth and the video belongs to the connected channel
(or the owner supplies a rights-cleared file via the upload adapter).

Importing is delegated to a configured, owner-authorized media provider
(`config["media_provider_url"]`), e.g. a Google Drive export of your own footage. Without
it the state stays PENDING_CONFIGURATION.
"""
from __future__ import annotations
import re
from urllib.parse import urlparse, parse_qs
from .base import SourceResult, SourceState, register

_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")
_HOSTS = {"youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "music.youtube.com"}


def extract_video_id(url: str) -> str | None:
    try:
        u = urlparse(url.strip())
    except ValueError:
        return None
    if u.scheme not in ("http", "https") or (u.hostname or "").lower() not in _HOSTS:
        return None
    host = u.hostname.lower()
    vid = None
    if host == "youtu.be":
        vid = u.path.lstrip("/").split("/")[0]
    elif u.path == "/watch":
        vid = (parse_qs(u.query).get("v") or [None])[0]
    else:
        m = re.match(r"^/(?:shorts|live|embed)/([^/?]+)", u.path)
        vid = m.group(1) if m else None
    return vid if vid and _ID.match(vid) else None


class YouTubeAdapter:
    name = "youtube"

    def validate(self, source: dict) -> SourceResult:
        vid = extract_video_id(source.get("url", ""))
        if not vid:
            return SourceResult(SourceState.REJECTED, self.name, "not a valid YouTube video URL")
        return SourceResult(SourceState.VALIDATED, self.name,
                            "URL is well formed. Access to the media stream has NOT been verified.",
                            {"video_id": vid}, fingerprint=f"youtube:{vid}")

    def authorize(self, source: dict, config: dict) -> SourceResult:
        r = self.validate(source)
        if r.state != SourceState.VALIDATED:
            return r
        missing = [k for k in ("google_oauth_connected", "owned_channel_video_ids") if not config.get(k)]
        if missing:
            r.state = SourceState.PENDING_CONFIGURATION
            r.missing_config = missing
            r.message = ("Connect your YouTube account (Settings > Social Accounts). Only videos on your own "
                         "channel can be imported; for other footage upload a file you have rights to.")
            return r
        if r.metadata["video_id"] not in config["owned_channel_video_ids"]:
            r.state = SourceState.REJECTED
            r.message = "video is not on the connected channel; upload a rights-cleared file instead"
            return r
        r.state = SourceState.AUTHORIZED
        r.message = "video belongs to the connected channel"
        return r

    def fetch(self, source: dict, config: dict, dest_dir: str) -> SourceResult:
        r = self.authorize(source, config)
        if r.state != SourceState.AUTHORIZED:
            return r
        provider = config.get("media_provider_url")
        if not provider:
            r.state = SourceState.PENDING_CONFIGURATION
            r.missing_config = ["media_provider_url"]
            r.message = "authorized, but no owner-controlled media provider is configured for download"
            return r
        r.state = SourceState.PENDING_CONFIGURATION
        r.missing_config = ["media_provider_integration"]
        r.message = "provider configured but download not implemented in this build; upload the file instead"
        return r


register(YouTubeAdapter())
