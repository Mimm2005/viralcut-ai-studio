"""Future live-stream ingest. Declared so the interface is stable; intentionally inactive."""
from __future__ import annotations
from .base import SourceResult, SourceState, register


class LiveStreamAdapter:
    name = "livestream"

    def validate(self, source: dict) -> SourceResult:
        return SourceResult(SourceState.UNSUPPORTED, self.name, "live-stream ingest is not implemented yet")

    def authorize(self, source: dict, config: dict) -> SourceResult:
        return self.validate(source)

    def fetch(self, source: dict, config: dict, dest_dir: str) -> SourceResult:
        return self.validate(source)


register(LiveStreamAdapter())
