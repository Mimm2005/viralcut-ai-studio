from __future__ import annotations
import hashlib
import os
from .base import SourceResult, SourceState, register
from .. import media


class UploadAdapter:
    name = "upload"

    def validate(self, source: dict) -> SourceResult:
        path = source.get("path", "")
        ext = os.path.splitext(path)[1].lower()
        if ext not in media.ALLOWED_EXTENSIONS:
            return SourceResult(SourceState.REJECTED, self.name, f"unsupported extension '{ext}'")
        if not os.path.isfile(path):
            return SourceResult(SourceState.REJECTED, self.name, "file not found")
        try:
            info = media.probe(path)
        except media.MediaError as e:
            return SourceResult(SourceState.REJECTED, self.name, str(e))
        max_bytes = int(source.get("max_bytes", 1024 * 1024 * 1024))
        problems = media.validate_media(info, max_bytes)
        if problems:
            return SourceResult(SourceState.REJECTED, self.name, "; ".join(problems), info.model_dump())
        return SourceResult(SourceState.VALIDATED, self.name, "ok", info.model_dump(),
                            fingerprint=self.fingerprint(path))

    def authorize(self, source: dict, config: dict) -> SourceResult:
        # A file the user uploaded themselves needs no third-party authorization.
        r = self.validate(source)
        if r.state == SourceState.VALIDATED:
            r.state = SourceState.AUTHORIZED
        return r

    def fetch(self, source: dict, config: dict, dest_dir: str) -> SourceResult:
        r = self.authorize(source, config)
        if r.state == SourceState.AUTHORIZED:
            r.state = SourceState.IMPORTED
            r.local_path = source["path"]
        return r

    @staticmethod
    def fingerprint(path: str) -> str:
        """Hash of size + first/last 1 MiB. Fast duplicate detection for large files."""
        h = hashlib.sha256()
        size = os.path.getsize(path)
        h.update(str(size).encode())
        with open(path, "rb") as f:
            h.update(f.read(1024 * 1024))
            if size > 2 * 1024 * 1024:
                f.seek(-1024 * 1024, os.SEEK_END)
                h.update(f.read(1024 * 1024))
        return h.hexdigest()


register(UploadAdapter())
