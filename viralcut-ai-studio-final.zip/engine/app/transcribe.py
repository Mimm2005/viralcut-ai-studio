"""Chunked speech recognition with Faster-Whisper.

The model is loaded lazily so the engine (and the test-suite) import without it.
`model_factory` allows dependency injection for tests.
"""
from __future__ import annotations
import os
import tempfile
from typing import Callable, Optional
from .models import Segment, Transcript, Word
from . import media


def load_model(name: str, compute_type: str = "int8"):
    from faster_whisper import WhisperModel
    return WhisperModel(name, device="cpu", compute_type=compute_type)


def parse_whisper_segments(raw_segments, offset: float = 0.0) -> list[Segment]:
    out = []
    for s in raw_segments:
        words = [Word(start=w.start + offset, end=w.end + offset, text=w.word.strip(),
                      prob=float(getattr(w, "probability", 1.0) or 1.0))
                 for w in (getattr(s, "words", None) or []) if w.word.strip()]
        text = s.text.strip()
        if not text:
            continue
        out.append(Segment(start=s.start + offset, end=s.end + offset, text=text, words=words))
    return out


def chunk_ranges(duration: float, chunk: int, overlap: float = 0.0) -> list[tuple[float, float]]:
    if duration <= 0 or chunk <= 0:
        return []
    out, t = [], 0.0
    while t < duration:
        out.append((t, min(chunk, duration - t)))
        t += chunk
    return out


def transcribe(video_path: str, duration: float, chunk_seconds: int, model, language: Optional[str] = None,
               on_chunk: Callable[[int, int, list[Segment]], None] | None = None,
               skip_chunks: int = 0, prior: list[Segment] | None = None) -> Transcript:
    """Transcribes chunk by chunk. `skip_chunks`/`prior` let a recovered job resume from a checkpoint."""
    ranges = chunk_ranges(duration, chunk_seconds)
    segments: list[Segment] = list(prior or [])
    lang = language or "en"
    with tempfile.TemporaryDirectory() as td:
        for i, (start, dur) in enumerate(ranges):
            if i < skip_chunks:
                continue
            wav = os.path.join(td, f"c{i}.wav")
            media.extract_audio(video_path, wav, start, dur)
            raw, info = model.transcribe(wav, language=language, word_timestamps=True, vad_filter=True)
            lang = getattr(info, "language", lang) or lang
            segs = parse_whisper_segments(list(raw), offset=start)
            segments.extend(segs)
            os.remove(wav)
            if on_chunk:
                on_chunk(i + 1, len(ranges), segs)
    segments.sort(key=lambda s: s.start)
    return Transcript(language=lang, segments=segments)
