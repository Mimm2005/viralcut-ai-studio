"""Durable job store (SQLite) with leases, heartbeats, retries with backoff and checkpoints.

Free compute can sleep or restart at any time. Anything that was `running` with an expired
lease is returned to the queue by `recover_expired()` and resumes from its last checkpoint.
"""
from __future__ import annotations
import json
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager

SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs(
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, payload TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued',
  attempts INTEGER NOT NULL DEFAULT 0, max_attempts INTEGER NOT NULL DEFAULT 3,
  progress REAL NOT NULL DEFAULT 0, step TEXT,
  lease_expires REAL, heartbeat REAL, run_after REAL NOT NULL DEFAULT 0,
  checkpoint TEXT, result TEXT, error TEXT,
  cancel_requested INTEGER NOT NULL DEFAULT 0,
  created_at REAL NOT NULL, updated_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status, run_after);
CREATE TABLE IF NOT EXISTS job_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  ts REAL NOT NULL, level TEXT NOT NULL, message TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_events_job ON job_events(job_id, id);
"""

TERMINAL = {"succeeded", "failed", "cancelled"}


class JobStore:
    def __init__(self, path: str, lease_seconds: int = 120, max_attempts: int = 3):
        self.path = path
        self.lease = lease_seconds
        self.max_attempts = max_attempts
        self._lock = threading.Lock()
        with self._conn() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def _conn(self):
        c = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        c.execute("PRAGMA journal_mode=WAL")
        try:
            yield c
        finally:
            c.close()

    # -- producers ---------------------------------------------------------
    def enqueue(self, kind: str, payload: dict, job_id: str | None = None) -> str:
        jid = job_id or uuid.uuid4().hex
        now = time.time()
        with self._lock, self._conn() as c:
            row = c.execute("SELECT id FROM jobs WHERE id=?", (jid,)).fetchone()
            if row:  # idempotent: re-submitting the same job id does not create a duplicate
                return jid
            c.execute("INSERT INTO jobs(id,kind,payload,max_attempts,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                      (jid, kind, json.dumps(payload), self.max_attempts, now, now))
        self.event(jid, "info", f"queued {kind}")
        return jid

    # -- consumers ---------------------------------------------------------
    def claim(self) -> dict | None:
        now = time.time()
        with self._lock, self._conn() as c:
            c.execute("BEGIN IMMEDIATE")
            row = c.execute("SELECT * FROM jobs WHERE status='queued' AND run_after<=? ORDER BY created_at LIMIT 1",
                            (now,)).fetchone()
            if not row:
                c.execute("COMMIT")
                return None
            c.execute("UPDATE jobs SET status='running', attempts=attempts+1, lease_expires=?, heartbeat=?, "
                      "updated_at=? WHERE id=?", (now + self.lease, now, now, row["id"]))
            c.execute("COMMIT")
        return self.get(row["id"])

    def heartbeat(self, jid: str, progress: float | None = None, step: str | None = None) -> bool:
        """Extends the lease. Returns False when cancellation was requested."""
        now = time.time()
        with self._lock, self._conn() as c:
            c.execute("UPDATE jobs SET heartbeat=?, lease_expires=?, updated_at=?, "
                      "progress=COALESCE(?,progress), step=COALESCE(?,step) WHERE id=? AND status='running'",
                      (now, now + self.lease, now, progress, step, jid))
            row = c.execute("SELECT cancel_requested FROM jobs WHERE id=?", (jid,)).fetchone()
        return not (row and row["cancel_requested"])

    def checkpoint(self, jid: str, data: dict) -> None:
        with self._lock, self._conn() as c:
            c.execute("UPDATE jobs SET checkpoint=?, updated_at=? WHERE id=?", (json.dumps(data), time.time(), jid))

    def succeed(self, jid: str, result: dict) -> None:
        with self._lock, self._conn() as c:
            c.execute("UPDATE jobs SET status='succeeded', result=?, progress=1, lease_expires=NULL, error=NULL, "
                      "updated_at=? WHERE id=?", (json.dumps(result), time.time(), jid))
        self.event(jid, "info", "succeeded")

    def fail(self, jid: str, error: str, retryable: bool = True) -> str:
        """Retries with exponential backoff until max_attempts; then marks failed. Returns new status."""
        now = time.time()
        with self._lock, self._conn() as c:
            row = c.execute("SELECT attempts,max_attempts FROM jobs WHERE id=?", (jid,)).fetchone()
            if not row:
                return "missing"
            if retryable and row["attempts"] < row["max_attempts"]:
                delay = min(300, 5 * (2 ** (row["attempts"] - 1)))
                c.execute("UPDATE jobs SET status='queued', error=?, run_after=?, lease_expires=NULL, updated_at=? "
                          "WHERE id=?", (error[:1000], now + delay, now, jid))
                status = "queued"
            else:
                c.execute("UPDATE jobs SET status='failed', error=?, lease_expires=NULL, updated_at=? WHERE id=?",
                          (error[:1000], now, jid))
                status = "failed"
        self.event(jid, "error", f"{status}: {error[:300]}")
        return status

    def cancel(self, jid: str) -> bool:
        with self._lock, self._conn() as c:
            row = c.execute("SELECT status FROM jobs WHERE id=?", (jid,)).fetchone()
            if not row or row["status"] in TERMINAL:
                return False
            if row["status"] == "queued":
                c.execute("UPDATE jobs SET status='cancelled', updated_at=? WHERE id=?", (time.time(), jid))
            else:
                c.execute("UPDATE jobs SET cancel_requested=1, updated_at=? WHERE id=?", (time.time(), jid))
        self.event(jid, "info", "cancel requested")
        return True

    def mark_cancelled(self, jid: str) -> None:
        with self._lock, self._conn() as c:
            c.execute("UPDATE jobs SET status='cancelled', lease_expires=NULL, updated_at=? WHERE id=?",
                      (time.time(), jid))

    def recover_expired(self) -> list[str]:
        """Return running jobs whose lease expired (worker slept/crashed) to the queue."""
        now = time.time()
        recovered = []
        with self._lock, self._conn() as c:
            rows = c.execute("SELECT id,attempts,max_attempts FROM jobs WHERE status='running' AND lease_expires<?",
                             (now,)).fetchall()
            for r in rows:
                if r["attempts"] >= r["max_attempts"]:
                    c.execute("UPDATE jobs SET status='failed', error='lease expired; attempts exhausted', "
                              "updated_at=? WHERE id=?", (now, r["id"]))
                else:
                    c.execute("UPDATE jobs SET status='queued', lease_expires=NULL, updated_at=? WHERE id=?",
                              (now, r["id"]))
                    recovered.append(r["id"])
        for jid in recovered:
            self.event(jid, "warn", "lease expired; job re-queued and will resume from checkpoint")
        return recovered

    # -- queries -----------------------------------------------------------
    def get(self, jid: str) -> dict | None:
        with self._conn() as c:
            row = c.execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
        if not row:
            return None
        d = dict(row)
        for k in ("payload", "checkpoint", "result"):
            d[k] = json.loads(d[k]) if d.get(k) else None
        return d

    def event(self, jid: str, level: str, message: str) -> None:
        with self._lock, self._conn() as c:
            c.execute("INSERT INTO job_events(job_id,ts,level,message) VALUES(?,?,?,?)",
                      (jid, time.time(), level, message[:1000]))

    def events(self, jid: str, after: int = 0) -> list[dict]:
        with self._conn() as c:
            return [dict(r) for r in c.execute(
                "SELECT id,ts,level,message FROM job_events WHERE job_id=? AND id>? ORDER BY id", (jid, after))]

    def counts(self) -> dict:
        with self._conn() as c:
            return {r["status"]: r["n"] for r in c.execute("SELECT status,COUNT(*) n FROM jobs GROUP BY status")}
