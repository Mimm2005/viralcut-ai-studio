from __future__ import annotations
from typing import Literal, Optional
from pydantic import BaseModel, Field, model_validator


class MediaInfo(BaseModel):
    duration: float
    width: int = 0
    height: int = 0
    fps: float = 0.0
    has_audio: bool = False
    has_video: bool = True
    size_bytes: int = 0
    video_codec: str = ""
    audio_codec: str = ""
    container: str = ""


class Word(BaseModel):
    start: float
    end: float
    text: str
    prob: float = 1.0


class Segment(BaseModel):
    start: float
    end: float
    text: str
    words: list[Word] = Field(default_factory=list)


class Transcript(BaseModel):
    language: str = "en"
    segments: list[Segment] = Field(default_factory=list)

    @property
    def full_text(self) -> str:
        return " ".join(s.text.strip() for s in self.segments)


class AnalysisConfig(BaseModel):
    min_score: float = Field(0, ge=0, le=100)
    max_candidates: int = Field(15, ge=1, le=50)
    min_duration: float = Field(10, ge=3, le=180)
    max_duration: float = Field(60, ge=5, le=180)
    category: Optional[str] = None
    preferred_type: Optional[str] = None
    range_start: Optional[float] = Field(None, ge=0)
    range_end: Optional[float] = Field(None, ge=0)

    @model_validator(mode="after")
    def _check(self):
        if self.max_duration < self.min_duration:
            raise ValueError("max_duration must be >= min_duration")
        if (self.range_start is None) != (self.range_end is None):
            raise ValueError("range_start and range_end must be given together")
        if self.range_start is not None and self.range_end <= self.range_start:
            raise ValueError("range_end must be greater than range_start")
        return self


class FactorScores(BaseModel):
    hook: float = Field(ge=0, le=100)
    emotion: float = Field(ge=0, le=100)
    entertainment: float = Field(ge=0, le=100)
    unexpectedness: float = Field(ge=0, le=100)
    shareability: float = Field(ge=0, le=100)
    storytelling: float = Field(ge=0, le=100)


class Moment(BaseModel):
    start: float
    end: float
    score: float = Field(ge=0, le=100)
    factors: FactorScores
    confidence: float = Field(ge=0, le=1)
    explanation: str
    moment_type: str = "general"
    transcript: str = ""
    suggested_title: str = ""
    signals: dict = Field(default_factory=dict)

    @property
    def duration(self) -> float:
        return self.end - self.start


class CropSpec(BaseModel):
    mode: Literal["center", "smart", "manual"] = "smart"
    x: float = Field(0.5, ge=0, le=1)
    y: float = Field(0.5, ge=0, le=1)


class SubtitleStyle(BaseModel):
    mode: Literal["none", "standard", "highlight", "custom"] = "standard"
    font: str = "DejaVu Sans"
    size: int = Field(64, ge=16, le=200)
    color: str = "#FFFFFF"
    highlight_color: str = "#FFD400"
    outline_color: str = "#000000"
    outline: int = Field(4, ge=0, le=12)
    background: bool = False
    position: Literal["bottom", "middle", "top"] = "bottom"
    max_words_per_line: int = Field(4, ge=1, le=10)


class RenderRequest(BaseModel):
    source_path: str
    output_path: str
    start: float = Field(ge=0)
    end: float
    resolution: Literal["1080p", "720p"] = "1080p"
    fps: Optional[float] = Field(None, ge=10, le=60)
    crop: CropSpec = Field(default_factory=CropSpec)
    subtitles: SubtitleStyle = Field(default_factory=SubtitleStyle)
    words: list[Word] = Field(default_factory=list)
    title_overlay: Optional[str] = None
    normalize_audio: bool = True

    @model_validator(mode="after")
    def _check(self):
        if self.end <= self.start:
            raise ValueError("end must be greater than start")
        if self.end - self.start > 180:
            raise ValueError("clip longer than 180 seconds")
        return self
