"""Viral Potential Score. Every factor is derived from measurable features.

An LLM may *explain* a score downstream, but it never produces one.
"""
from __future__ import annotations
from .models import FactorScores

WEIGHTS = {
    "hook": 20,
    "emotion": 20,
    "entertainment": 20,
    "unexpectedness": 15,
    "shareability": 15,
    "storytelling": 10,
}
assert sum(WEIGHTS.values()) == 100

FACTOR_LABELS = {
    "hook": "opening hook", "emotion": "emotional intensity", "entertainment": "entertainment value",
    "unexpectedness": "unexpectedness", "shareability": "shareability", "storytelling": "short-form storytelling",
}


def clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def total_score(f: FactorScores) -> float:
    s = sum(getattr(f, k) * w for k, w in WEIGHTS.items()) / 100.0
    return round(clamp(s), 1)


def confidence(has_transcript: bool, has_audio: bool, has_visual: bool, word_count: int, duration: float) -> float:
    c = 0.15
    c += 0.30 if has_transcript else 0.0
    c += 0.25 if has_audio else 0.0
    c += 0.15 if has_visual else 0.0
    if has_transcript:
        wps = word_count / max(duration, 1.0)
        c += 0.15 if 0.8 <= wps <= 4.5 else 0.05 if word_count > 5 else 0.0
    return round(clamp(c, 0, 1.0), 2)


def explain(f: FactorScores, signals: dict, moment_type: str) -> str:
    ranked = sorted(WEIGHTS, key=lambda k: getattr(f, k) * WEIGHTS[k], reverse=True)
    top = ranked[:2]
    parts = [f"Strongest on {FACTOR_LABELS[top[0]]} ({getattr(f, top[0]):.0f}/100) and "
             f"{FACTOR_LABELS[top[1]]} ({getattr(f, top[1]):.0f}/100)."]
    evidence = []
    if signals.get("peak_energy_z", 0) >= 1.5:
        evidence.append(f"audio peaks {signals['peak_energy_z']:.1f} std-devs above this video's normal level")
    if signals.get("laughter_max", 0) >= 0.4:
        evidence.append("laughter-like audio bursts (heuristic)")
    if signals.get("surprise_terms"):
        evidence.append("surprise words in speech: " + ", ".join(signals["surprise_terms"][:3]))
    if signals.get("humor_terms"):
        evidence.append("humour cues: " + ", ".join(signals["humor_terms"][:3]))
    if signals.get("motion_mean", 0) >= 0.5:
        evidence.append("high visual motion")
    if signals.get("scene_cuts", 0) >= 2:
        evidence.append(f"{signals['scene_cuts']} scene changes")
    if signals.get("starts_at_sentence") and signals.get("ends_at_sentence"):
        evidence.append("starts and ends on sentence boundaries")
    if evidence:
        parts.append("Evidence: " + "; ".join(evidence) + ".")
    weakest = ranked[-1]
    if getattr(f, weakest) < 35:
        parts.append(f"Weakest area: {FACTOR_LABELS[weakest]} ({getattr(f, weakest):.0f}/100).")
    return " ".join(parts)
