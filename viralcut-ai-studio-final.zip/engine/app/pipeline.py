"""Analysis and render pipelines. Each analysis step is checkpointed so a recovered job resumes."""
from __future__ import annotations
import os
import shutil
import httpx
from .config import Settings
from .jobs import JobStore
from .models import AnalysisConfig, RenderRequest, Transcript
from . import media, moments, signals, transcribe, render as renderer
from .moments import analyse


class Cancelled(Exception):
    pass


class PermanentError(Exception):
    """Do not retry (bad input, rejected media)."""


def download(url: str, dest: str, max_bytes: int, on_bytes=None) -> int:
    if not url.startswith("https://") and not url.startswith("http://localhost") and not url.startswith("http://127.0.0.1"):
        raise PermanentError("source_url must be https")
    total = 0
    with httpx.stream("GET", url, timeout=60, follow_redirects=True) as r:
        if r.status_code >= 400:
            raise PermanentError(f"source download failed: HTTP {r.status_code}")
        with open(dest, "wb") as f:
            for chunk in r.iter_bytes(1024 * 256):
                total += len(chunk)
                if total > max_bytes:
                    raise PermanentError("source exceeds size limit")
                f.write(chunk)
                if on_bytes:
                    on_bytes(total)
    return total


def upload(path: str, url: str, content_type: str = "video/mp4") -> None:
    with open(path, "rb") as f:
        r = httpx.put(url, content=f, headers={"Content-Type": content_type}, timeout=600)
    if r.status_code >= 300:
        raise RuntimeError(f"output upload failed: HTTP {r.status_code}")


class Runner:
    def __init__(self, store: JobStore, settings: Settings, model_factory=None):
        self.store, self.s = store, settings
        os.makedirs(settings.data_dir, exist_ok=True)
        self._model_factory = model_factory or (lambda: transcribe.load_model(settings.whisper_model, settings.whisper_compute))
        self._model = None

    def model(self):
        if self._model is None:
            self._model = self._model_factory()
        return self._model

    def work_dir(self, jid: str) -> str:
        d = os.path.join(self.s.data_dir, "work", jid)
        os.makedirs(d, exist_ok=True)
        return d

    def run(self, job: dict) -> None:
        jid = job["id"]
        try:
            if media.free_disk_mb(self.s.data_dir) < self.s.min_free_disk_mb:
                raise RuntimeError("insufficient free disk space; will retry")
            if job["kind"] == "analyze":
                result = self.analyze(job)
            elif job["kind"] == "render":
                result = self.render(job)
            else:
                raise PermanentError(f"unknown job kind {job['kind']}")
            self.store.succeed(jid, result)
        except Cancelled:
            self.store.mark_cancelled(jid)
        except (PermanentError, media.MediaError, ValueError) as e:
            retry = not isinstance(e, (PermanentError, ValueError))
            self.store.fail(jid, str(e), retryable=retry)
        except Exception as e:  # noqa: BLE001 - transient; retried with backoff
            self.store.fail(jid, f"{type(e).__name__}: {e}", retryable=True)

    def _hb(self, jid: str, p: float, step: str) -> None:
        if not self.store.heartbeat(jid, p, step):
            raise Cancelled()

    # ---- analysis ---------------------------------------------------------
    def analyze(self, job: dict) -> dict:
        jid, p = job["id"], job["payload"]
        cfg = AnalysisConfig(**p.get("config", {}))
        wd = self.work_dir(jid)
        cp = job.get("checkpoint") or {}
        src = p.get("local_path") or os.path.join(wd, "source" + os.path.splitext(p.get("filename", "x.mp4"))[1])
        self._hb(jid, 0.02, "fetch")
        if not p.get("local_path") and not os.path.exists(src):
            if not p.get("source_url"):
                raise PermanentError("payload needs source_url or local_path")
            download(p["source_url"], src, self.s.max_upload_mb * 1024 * 1024,
                     lambda n: self.store.heartbeat(jid))
        self.store.event(jid, "info", "source available")
        try:
            info = media.probe(src)
        except media.MediaError as e:
            raise PermanentError(f"unreadable media: {e}") from e
        problems = media.validate_media(info, self.s.max_upload_mb * 1024 * 1024)
        if problems:
            raise PermanentError("; ".join(problems))
        self._hb(jid, 0.08, "audio")
        wav = os.path.join(wd, "audio.wav")
        au = signals.AudioSignals()
        if info.has_audio:
            if not os.path.exists(wav):
                media.extract_audio(src, wav)
            au = signals.audio_signals(wav)
        else:
            self.store.event(jid, "warn", "no audio stream; analysis will use visual signals only")
        self._hb(jid, 0.18, "visual")
        vis = signals.visual_signals(src, self.s.frame_sample_fps)
        # transcription with chunk checkpoints
        self._hb(jid, 0.25, "transcribe")
        done = int(cp.get("chunks_done", 0))
        prior = [transcribe.Segment(**s) for s in cp.get("segments", [])]
        tr = Transcript(segments=prior)
        if info.has_audio:
            def on_chunk(i, n, segs):
                nonlocal prior
                prior = prior + segs
                self.store.checkpoint(jid, {"chunks_done": i, "segments": [s.model_dump() for s in prior]})
                self._hb(jid, 0.25 + 0.5 * i / n, f"transcribe {i}/{n}")
            tr = transcribe.transcribe(src, info.duration, self.s.chunk_seconds, self.model(), None, on_chunk,
                                       skip_chunks=done, prior=list(prior))
        self._hb(jid, 0.80, "moments")
        found = analyse(tr, au, vis, info.duration, cfg)
        self.store.event(jid, "info", f"{len(found)} candidate moments")
        self._hb(jid, 0.97, "finalise")
        result = {"media": info.model_dump(), "language": tr.language,
                  "transcript": tr.model_dump(), "scene_cuts": vis.scene_cuts,
                  "moments": [m.model_dump() for m in found],
                  "signals_available": {"audio": au.available, "visual": vis.available, "speech": bool(tr.segments)}}
        shutil.rmtree(wd, ignore_errors=True)  # temporary media cleanup
        return result

    # ---- render -----------------------------------------------------------
    def render(self, job: dict) -> dict:
        jid, p = job["id"], job["payload"]
        wd = self.work_dir(jid)
        req = dict(p["request"])
        src = p.get("local_path") or os.path.join(wd, "source.mp4")
        if not p.get("local_path") and not os.path.exists(src):
            download(p["source_url"], src, self.s.max_upload_mb * 1024 * 1024, lambda n: self.store.heartbeat(jid))
        req["source_path"] = src
        req["output_path"] = p.get("output_path") or os.path.join(wd, "clip.mp4")
        rr = RenderRequest(**req)
        self._hb(jid, 0.1, "render")

        def prog(x: float):
            self._hb(jid, 0.1 + 0.8 * x, "render")
        out = renderer.render(rr, prog)
        problems = renderer.verify_output(rr.output_path, rr.end - rr.start, rr.resolution)
        if problems:
            raise media.MediaError("output validation failed: " + "; ".join(problems))
        if p.get("output_upload_url"):
            self._hb(jid, 0.93, "upload")
            upload(rr.output_path, p["output_upload_url"])
            out["uploaded"] = True
            if not p.get("keep_local"):
                os.remove(rr.output_path)
        if not p.get("local_path"):
            shutil.rmtree(wd, ignore_errors=True) if out.get("uploaded") else None
        return out
