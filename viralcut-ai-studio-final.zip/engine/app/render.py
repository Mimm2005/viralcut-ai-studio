"""Vertical Shorts rendering with FFmpeg."""
from __future__ import annotations
import os
import re
import subprocess
import tempfile
from typing import Callable
from .models import MediaInfo, RenderRequest
from . import media, signals, subtitles

TARGETS = {"1080p": (1080, 1920), "720p": (720, 1280)}


def crop_geometry(src_w: int, src_h: int, cx: float, cy: float = 0.5) -> tuple[int, int, int, int]:
    """Largest 9:16 window inside the source, centred on (cx, cy) fractions. Returns w,h,x,y (even numbers)."""
    target = 9 / 16
    if src_w / src_h > target:
        h = src_h
        w = int(round(h * target))
    else:
        w = src_w
        h = int(round(w / target))
    w -= w % 2
    h -= h % 2
    x = int(round(cx * src_w - w / 2))
    y = int(round(cy * src_h - h / 2))
    x = max(0, min(src_w - w, x))
    y = max(0, min(src_h - h, y))
    return w, h, x - x % 2, y - y % 2


def _esc_filter_path(p: str) -> str:
    return p.replace("\\", "/").replace(":", r"\:").replace("'", r"\'")


def _esc_drawtext(t: str) -> str:
    return (t.replace("\\", r"\\").replace(":", r"\:").replace("'", "").replace("%", r"\%")
             .replace(",", r"\,"))[:90]


def build_filter(info: MediaInfo, req: RenderRequest, cx: float, ass_path: str | None) -> str:
    out_w, out_h = TARGETS[req.resolution]
    cw, ch, x, y = crop_geometry(info.width, info.height, cx, req.crop.y if req.crop.mode == "manual" else 0.5)
    chain = [f"crop={cw}:{ch}:{x}:{y}", f"scale={out_w}:{out_h}:flags=lanczos", "setsar=1"]
    if req.fps:
        chain.append(f"fps={req.fps}")
    if ass_path:
        chain.append(f"subtitles='{_esc_filter_path(ass_path)}'")
    if req.title_overlay:
        chain.append(
            f"drawtext=text='{_esc_drawtext(req.title_overlay)}':fontcolor=white:fontsize={int(out_h * 0.032)}:"
            f"borderw=3:bordercolor=black:x=(w-text_w)/2:y={int(out_h * 0.08)}:enable='between(t,0,3.5)'")
    return ",".join(chain)


def resolve_cx(req: RenderRequest, info: MediaInfo) -> float:
    if req.crop.mode == "center":
        return 0.5
    if req.crop.mode == "manual":
        return req.crop.x
    return signals.saliency_center_x(req.source_path, req.start, req.end)


def render(req: RenderRequest, on_progress: Callable[[float], None] | None = None) -> dict:
    info = media.probe(req.source_path)
    if not info.has_video:
        raise media.MediaError("source has no video stream")
    if req.end > info.duration + 0.5:
        raise media.MediaError("end time is beyond the end of the source")
    dur = req.end - req.start
    cx = resolve_cx(req, info)
    os.makedirs(os.path.dirname(os.path.abspath(req.output_path)), exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        ass_text = subtitles.build_ass(req.words, req.subtitles, req.start, req.end, *TARGETS[req.resolution])
        ass_path = None
        if ass_text:
            ass_path = os.path.join(td, "subs.ass")
            with open(ass_path, "w", encoding="utf-8") as f:
                f.write(ass_text)
        vf = build_filter(info, req, cx, ass_path)
        cmd = ["ffmpeg", "-y", "-v", "error", "-progress", "pipe:1", "-nostats",
               "-ss", f"{req.start:.3f}", "-i", req.source_path, "-t", f"{dur:.3f}", "-vf", vf,
               "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p"]
        if info.has_audio:
            if req.normalize_audio:
                cmd += ["-af", "loudnorm=I=-16:TP=-1.5:LRA=11"]
            cmd += ["-c:a", "aac", "-b:a", "160k", "-ar", "48000"]
        else:
            cmd += ["-an"]
        cmd += ["-movflags", "+faststart", req.output_path]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        rx = re.compile(r"out_time_ms=(\d+)")
        for line in proc.stdout:  # type: ignore[union-attr]
            m = rx.match(line.strip())
            if m and on_progress:
                on_progress(min(0.99, int(m.group(1)) / 1_000_000 / dur))
        err = proc.stderr.read()  # type: ignore[union-attr]
        if proc.wait() != 0:
            raise media.MediaError(f"render failed: {err.strip()[:400]}")
    if on_progress:
        on_progress(1.0)
    out = media.probe(req.output_path)
    return {"output_path": req.output_path, "info": out.model_dump(), "crop_center_x": cx}


def verify_output(path: str, expected_duration: float, resolution: str = "1080p", tol: float = 0.6) -> list[str]:
    """Output-format validation used by tests and by the pipeline after every render."""
    problems = []
    info = media.probe(path)
    w, h = TARGETS[resolution]
    if (info.width, info.height) != (w, h):
        problems.append(f"resolution {info.width}x{info.height} != {w}x{h}")
    if info.video_codec != "h264":
        problems.append(f"video codec {info.video_codec} != h264")
    if info.has_audio and info.audio_codec != "aac":
        problems.append(f"audio codec {info.audio_codec} != aac")
    if abs(info.duration - expected_duration) > tol:
        problems.append(f"duration {info.duration:.2f}s differs from expected {expected_duration:.2f}s")
    return problems
