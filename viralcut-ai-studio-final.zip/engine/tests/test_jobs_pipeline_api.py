import time
import pytest
from app.jobs import JobStore
from app.pipeline import Runner
from app.config import Settings
from conftest import FakeModel


@pytest.fixture
def store(tmp_path):
    return JobStore(str(tmp_path / "j.db"), lease_seconds=1, max_attempts=3)


def test_enqueue_is_idempotent(store):
    a = store.enqueue("analyze", {"x": 1}, "job-000001")
    b = store.enqueue("analyze", {"x": 1}, "job-000001")
    assert a == b and store.counts() == {"queued": 1}


def test_claim_is_exclusive(store):
    store.enqueue("analyze", {}, "job-000001")
    assert store.claim()["status"] == "running"
    assert store.claim() is None


def test_retry_backoff_then_fail(store):
    jid = store.enqueue("analyze", {}, "job-000001")
    store.claim()
    assert store.fail(jid, "boom") == "queued"
    j = store.get(jid)
    assert j["run_after"] > time.time()          # backoff
    assert store.claim() is None                 # not yet due
    for _ in range(2):
        with store._conn() as c:
            c.execute("UPDATE jobs SET run_after=0,status='queued' WHERE id=?", (jid,))
        store.claim()
        last = store.fail(jid, "boom")
    assert last == "failed" and store.get(jid)["attempts"] == 3


def test_permanent_failure_not_retried(store):
    jid = store.enqueue("analyze", {}, "job-000001")
    store.claim()
    assert store.fail(jid, "bad input", retryable=False) == "failed"


def test_lease_expiry_recovers_sleeping_worker(store):
    jid = store.enqueue("analyze", {}, "job-000001")
    store.claim()
    store.checkpoint(jid, {"chunks_done": 2})
    assert store.recover_expired() == []
    time.sleep(1.2)
    assert store.recover_expired() == [jid]
    j = store.claim()
    assert j["checkpoint"] == {"chunks_done": 2}  # resumes from checkpoint
    assert any("lease expired" in e["message"] for e in store.events(jid))


def test_heartbeat_extends_lease_and_reports_cancel(store):
    jid = store.enqueue("analyze", {}, "job-000001")
    store.claim()
    time.sleep(0.6); assert store.heartbeat(jid, 0.5, "x")
    time.sleep(0.6); assert store.recover_expired() == []
    store.cancel(jid)
    assert store.heartbeat(jid) is False


def test_cancel_queued(store):
    jid = store.enqueue("analyze", {}, "job-000001")
    assert store.cancel(jid) and store.get(jid)["status"] == "cancelled"
    assert store.cancel(jid) is False


def make_runner(tmp_path, store, model):
    s = Settings(data_dir=str(tmp_path / "data"), chunk_seconds=20, min_free_disk_mb=1)
    return Runner(store, s, lambda: model), s


def test_full_analysis_pipeline(tmp_path, store, sample_video):
    r, _ = make_runner(tmp_path, store, FakeModel())
    jid = store.enqueue("analyze", {"local_path": sample_video, "config": {"min_duration": 10, "max_duration": 25}},
                        "job-000001")
    r.run(store.claim())
    j = store.get(jid)
    assert j["status"] == "succeeded", j["error"]
    res = j["result"]
    assert res["media"]["duration"] > 40 and res["signals_available"]["audio"]
    assert res["moments"] and res["transcript"]["segments"]
    segs = res["transcript"]["segments"]
    assert segs == sorted(segs, key=lambda s: s["start"])
    assert any(s["start"] >= 20 for s in segs)    # later chunks carry a time offset
    assert all(0 <= m["score"] <= 100 for m in res["moments"])


def _due(store, jid):
    with store._conn() as c:
        c.execute("UPDATE jobs SET run_after=0 WHERE id=?", (jid,))


def test_transient_failure_retries_and_resumes_from_checkpoint(tmp_path, store, sample_video):
    model = FakeModel(fail_on={3})                # 45 s / 20 s chunks = 3 chunks; the 3rd call fails once
    r, _ = make_runner(tmp_path, store, model)
    jid = store.enqueue("analyze", {"local_path": sample_video}, "job-000001")
    r.run(store.claim())
    j = store.get(jid)
    assert j["status"] == "queued" and "simulated model failure" in j["error"]
    assert j["checkpoint"]["chunks_done"] == 2    # two chunks were saved
    _due(store, jid)
    r.run(store.claim())
    j = store.get(jid)
    assert j["status"] == "succeeded", j["error"]
    assert model.calls == 4                       # resumed: only the missing chunk re-ran (not 6)
    assert j["attempts"] == 2


def test_persistent_provider_failure_ends_failed(tmp_path, store, sample_video):
    r, _ = make_runner(tmp_path, store, FakeModel(fail_times=99))
    jid = store.enqueue("analyze", {"local_path": sample_video}, "job-000001")
    for _ in range(3):
        _due(store, jid)
        job = store.claim()
        if job:
            r.run(job)
    j = store.get(jid)
    assert j["status"] == "failed" and j["attempts"] == 3


def test_invalid_media_is_permanent_failure(tmp_path, store):
    bad = tmp_path / "bad.mp4"; bad.write_bytes(b"junk")
    r, _ = make_runner(tmp_path, store, FakeModel())
    jid = store.enqueue("analyze", {"local_path": str(bad)}, "job-000001")
    r.run(store.claim())
    j = store.get(jid)
    assert j["status"] == "failed" and j["attempts"] == 1     # no pointless retries


def test_render_job(tmp_path, store, sample_video):
    r, _ = make_runner(tmp_path, store, FakeModel())
    out = str(tmp_path / "clip.mp4")
    jid = store.enqueue("render", {"local_path": sample_video, "output_path": out, "request": {
        "start": 5, "end": 14, "resolution": "720p", "crop": {"mode": "center"}, "subtitles": {"mode": "none"}}},
        "job-000002")
    r.run(store.claim())
    assert store.get(jid)["status"] == "succeeded", store.get(jid)["error"]


def test_api_auth_and_flow(tmp_path, sample_video, monkeypatch):
    from fastapi.testclient import TestClient
    from app import main
    main.settings.data_dir = str(tmp_path / "api")
    main.settings.engine_token = "test-token"
    main.init(model_factory=lambda: FakeModel(), start_worker=False)
    c = TestClient(main.app)
    assert c.get("/health").json()["status"] == "ok"
    assert c.post("/jobs", json={"kind": "analyze", "payload": {}}).status_code == 401
    h = {"Authorization": "Bearer test-token"}
    assert c.post("/jobs", json={"kind": "bogus", "payload": {}}, headers=h).status_code == 422
    r = c.post("/jobs", json={"id": "job-abcdef", "kind": "analyze", "payload": {"local_path": sample_video}}, headers=h)
    assert r.status_code == 202
    assert c.get("/jobs/nope", headers=h).status_code == 404
    main.runner.run(main.store.claim())
    g = c.get("/jobs/job-abcdef", headers=h).json()
    assert g["status"] == "succeeded" and g["result"]["moments"]
    assert c.get("/jobs/job-abcdef/events", headers=h).json()["events"]
    v = c.post("/sources/validate", json={"adapter": "youtube", "source": {"url": "https://youtu.be/dQw4w9WgXcQ"}},
               headers=h).json()
    assert v["state"] == "validated"
    assert c.post("/sources/validate", json={"adapter": "x", "source": {}}, headers=h).status_code == 400
    main.settings.engine_token = ""
    assert c.get("/jobs/job-abcdef", headers=h).status_code == 503
    main.settings.engine_token = "test-token"
