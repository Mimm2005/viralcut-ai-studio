import os, wave
import pytest
from app import media
from app.sources import get_adapter, SourceState
from app.sources.youtube import extract_video_id
from app.sources.upload import UploadAdapter


def test_probe_reports_streams(sample_video):
    i = media.probe(sample_video)
    assert (i.width, i.height) == (640, 360)
    assert i.has_audio and i.has_video
    assert abs(i.duration - 45) < 0.5
    assert abs(i.fps - 30) < 0.1


def test_probe_rejects_garbage(tmp_path):
    p = tmp_path / "x.mp4"; p.write_bytes(b"not a video")
    with pytest.raises(media.MediaError):
        media.probe(str(p))


def test_validate_media_problems(silent_video):
    i = media.probe(silent_video)
    assert media.validate_media(i, 10**9) == []
    assert "no audio stream" in media.validate_media(i, 10**9, require_audio=True)
    assert any("larger" in p for p in media.validate_media(i.model_copy(update={"size_bytes": 10**10}), 10**9))


def test_audio_extraction_format_and_timestamps(sample_video, tmp_path):
    wav = str(tmp_path / "a.wav")
    media.extract_audio(sample_video, wav, start=10, duration=5)
    with wave.open(wav) as w:
        assert w.getframerate() == 16000 and w.getnchannels() == 1
        assert abs(w.getnframes() / 16000 - 5.0) < 0.05  # timestamp accuracy


def test_extract_frames(sample_video, tmp_path):
    n = media.extract_frames(sample_video, str(tmp_path / "f"), fps=1, width=160)
    assert 44 <= n <= 46


@pytest.mark.parametrize("url,vid", [
    ("https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ"),
    ("https://youtu.be/dQw4w9WgXcQ?t=5", "dQw4w9WgXcQ"),
    ("https://www.youtube.com/shorts/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
    ("https://www.youtube.com/live/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
])
def test_youtube_ids(url, vid):
    assert extract_video_id(url) == vid


@pytest.mark.parametrize("url", ["https://evil.com/watch?v=dQw4w9WgXcQ", "ftp://youtube.com/watch?v=dQw4w9WgXcQ",
                                 "https://youtube.com/watch?v=short", "javascript:alert(1)", ""])
def test_youtube_rejects(url):
    assert extract_video_id(url) is None


def test_youtube_states_never_overclaim():
    ad = get_adapter("youtube")
    src = {"url": "https://youtu.be/dQw4w9WgXcQ"}
    assert ad.validate(src).state == SourceState.VALIDATED          # URL only
    r = ad.authorize(src, {})
    assert r.state == SourceState.PENDING_CONFIGURATION and r.missing_config
    r = ad.authorize(src, {"google_oauth_connected": True, "owned_channel_video_ids": ["AAAAAAAAAAA"]})
    assert r.state == SourceState.REJECTED                          # not the owner's video
    r = ad.authorize(src, {"google_oauth_connected": True, "owned_channel_video_ids": ["dQw4w9WgXcQ"]})
    assert r.state == SourceState.AUTHORIZED
    assert ad.fetch(src, {"google_oauth_connected": True, "owned_channel_video_ids": ["dQw4w9WgXcQ"]}, "/tmp").state \
        != SourceState.IMPORTED                                      # never claims an import it did not do


def test_cloud_and_livestream_adapters():
    assert get_adapter("cloud").validate({"url": "http://drive.google.com/x"}).state == SourceState.UNSUPPORTED
    assert get_adapter("cloud").authorize({"url": "https://drive.google.com/file/d/1"}, {}).state == \
        SourceState.PENDING_CONFIGURATION
    assert get_adapter("livestream").validate({}).state == SourceState.UNSUPPORTED


def test_upload_adapter_lifecycle_and_duplicates(sample_video, tmp_path):
    ad = get_adapter("upload")
    r = ad.fetch({"path": sample_video}, {}, str(tmp_path))
    assert r.state == SourceState.IMPORTED and r.local_path == sample_video
    assert UploadAdapter.fingerprint(sample_video) == r.fingerprint
    bad = tmp_path / "x.exe"; bad.write_bytes(b"MZ")
    assert ad.validate({"path": str(bad)}).state == SourceState.REJECTED
    assert ad.validate({"path": str(tmp_path / "missing.mp4")}).state == SourceState.REJECTED
