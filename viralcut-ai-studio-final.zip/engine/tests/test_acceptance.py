"""Acceptance milestone (engine side): a 10-minute video -> analysis -> ranked candidates -> 5 vertical Shorts.

Whisper is replaced by a scripted model because the real model cannot be downloaded in the authoring
environment. Everything else (FFmpeg, audio/visual signals, scene detection, scoring, ranking,
rendering, output validation) runs for real.
"""
import json, os, subprocess, time
import pytest
from app import media, render
from app.config import Settings
from app.jobs import JobStore
from app.models import RenderRequest, CropSpec, SubtitleStyle, Word
from app.pipeline import Runner
from conftest import FakeSeg, FakeWord, FakeInfo

LINES = ["So here is the thing nobody tells you about this.", "We tried it and honestly it was kind of boring.",
         "Then suddenly wait what is that, oh my god!", "No way, that is insane, I can't believe it! haha",
         "Okay that was the best thing I have ever seen.", "Anyway, let's move on to the next topic here."]


class ScriptedWhisper:
    """One sentence every 12 s across each chunk (times relative to the chunk, as faster-whisper reports them)."""
    def __init__(self): self.calls = 0

    def transcribe(self, wav, language=None, word_timestamps=True, vad_filter=True):
        self.calls += 1
        import wave
        with wave.open(wav) as w:
            dur = w.getnframes() / w.getframerate()
        segs, t, i = [], 1.0, 0
        while t + 5 < dur:
            text = LINES[(self.calls * 3 + i) % len(LINES)]
            words = [FakeWord(t + k * 0.4, t + k * 0.4 + 0.35, x) for k, x in enumerate(text.split())]
            segs.append(FakeSeg(t, words[-1].end, text, words)); t += 12; i += 1
        return segs, FakeInfo()


@pytest.fixture(scope="module")
def ten_minute_video(tmp_path_factory):
    p = str(tmp_path_factory.mktemp("acc") / "ten_minutes.mp4")
    # loud bursts every ~70 s, varying scenes (testsrc2 + periodic colour flashes via geq-free approach: mandelbrot segments are costly, so use two sources alternated by enable)
    af = "volume='if(lt(mod(t,70),5),1.0,0.06)':eval=frame"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=24:duration=600",
                    "-f", "lavfi", "-i", "sine=frequency=300:sample_rate=16000:duration=600", "-af", af,
                    "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", p], check=True)
    return p


def test_ten_minute_acceptance(ten_minute_video, tmp_path):
    info = media.probe(ten_minute_video)
    assert 595 <= info.duration <= 605 and info.has_audio
    store = JobStore(str(tmp_path / "j.db"))
    s = Settings(data_dir=str(tmp_path / "data"), chunk_seconds=300, min_free_disk_mb=1)
    model = ScriptedWhisper()
    runner = Runner(store, s, lambda: model)
    jid = store.enqueue("analyze", {"local_path": ten_minute_video, "config": {"max_candidates": 15, "min_duration": 15, "max_duration": 45}}, "job-accept1")
    t0 = time.time(); runner.run(store.claim()); analysis_s = time.time() - t0
    job = store.get(jid)
    assert job["status"] == "succeeded", job["error"]
    res = job["result"]
    assert model.calls == 2                                           # 600 s / 300 s chunks => chunked processing
    segs = res["transcript"]["segments"]; assert len(segs) > 30 and segs == sorted(segs, key=lambda x: x["start"])
    assert any(x["start"] > 300 for x in segs)                         # second chunk carries its time offset
    moments = res["moments"]
    assert 5 <= len(moments) <= 15                                     # "at least 5 candidates when the content supports it"
    scores = [m["score"] for m in moments]; assert scores == sorted(scores, reverse=True) and all(0 <= x <= 100 for x in scores)
    for a in range(len(moments)):                                      # de-duplicated
        for b in range(a + 1, len(moments)):
            A, B = moments[a], moments[b]; inter = max(0, min(A["end"], B["end"]) - max(A["start"], B["start"]))
            assert inter / min(A["end"] - A["start"], B["end"] - B["start"]) <= 0.3 + 1e-9
    # the loud bursts (t mod 70 < 5) should lift windows containing them above windows that contain none
    def has_burst(m): return any((t % 70) < 5 for t in range(int(m["start"]), int(m["end"])))
    assert any(has_burst(m) for m in moments[:5])
    for m in moments: assert m["explanation"] and 0 <= m["confidence"] <= 1 and set(m["factors"]) == {"hook", "emotion", "entertainment", "unexpectedness", "shareability", "storytelling"}

    # render 5 shorts, verify format/duration/sync of each
    outs = []
    for n, m in enumerate(moments[:5]):
        out = str(tmp_path / f"short{n}.mp4")
        words = [Word(**w) for sg in segs for w in sg["words"] if w["end"] > m["start"] and w["start"] < m["end"]]
        req = RenderRequest(source_path=ten_minute_video, output_path=out, start=m["start"], end=m["end"], resolution="720p",
                            crop=CropSpec(mode="smart"), subtitles=SubtitleStyle(mode="highlight"), words=words, title_overlay=m["suggested_title"][:40])
        render.render(req)
        assert render.verify_output(out, m["end"] - m["start"], "720p") == [], out
        outs.append(out)
    assert len(outs) == 5
    print(f"\nacceptance: analysis {analysis_s:.1f}s, {len(moments)} moments, 5 shorts rendered")
