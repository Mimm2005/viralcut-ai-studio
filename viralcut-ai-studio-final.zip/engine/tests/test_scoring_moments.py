import numpy as np
import pytest
from app import scoring, moments, signals
from app.models import AnalysisConfig, FactorScores, Moment, Transcript


def F(**kw):
    base = dict(hook=0, emotion=0, entertainment=0, unexpectedness=0, shareability=0, storytelling=0)
    base.update(kw)
    return FactorScores(**base)


def test_weights_sum_to_100_and_match_spec():
    assert scoring.WEIGHTS == {"hook": 20, "emotion": 20, "entertainment": 20, "unexpectedness": 15,
                               "shareability": 15, "storytelling": 10}
    assert sum(scoring.WEIGHTS.values()) == 100


def test_score_boundaries():
    assert scoring.total_score(F()) == 0
    assert scoring.total_score(F(hook=100, emotion=100, entertainment=100, unexpectedness=100,
                                 shareability=100, storytelling=100)) == 100
    assert scoring.total_score(F(hook=100)) == 20       # weight applied
    assert scoring.total_score(F(storytelling=100)) == 10
    with pytest.raises(Exception):
        F(hook=101)


def test_confidence_rises_with_evidence():
    low = scoring.confidence(False, False, False, 0, 30)
    high = scoring.confidence(True, True, True, 60, 30)
    assert 0 <= low < high <= 1


def synth_audio(total=45, burst=(20, 24)):
    sr = 16000
    t = np.arange(int(total * sr)) / sr
    x = 0.02 * np.sin(2 * np.pi * 200 * t)
    m = (t >= burst[0]) & (t < burst[1])
    x[m] = 0.6 * np.sin(2 * np.pi * 300 * t[m]) * (0.6 + 0.4 * np.sin(2 * np.pi * 6 * t[m]))
    return signals.audio_signals_from_samples(x.astype(np.float32), sr)


def test_audio_signals_find_burst():
    au = synth_audio()
    sl = au.slice(20, 24)
    assert au.energy_z[sl].max() > 2.0
    assert au.energy_z[au.slice(5, 10)].max() < 1.0
    assert (au.laughter >= 0).all() and (au.laughter <= 1).all()


def test_candidates_respect_config(transcript):
    au, vis = synth_audio(), signals.VisualSignals()
    cfg = AnalysisConfig(min_duration=10, max_duration=30, max_candidates=5, min_score=0)
    res = moments.analyse(transcript, au, vis, 45, cfg)
    assert 1 <= len(res) <= 5
    for m in res:
        assert cfg.min_duration - 0.1 <= m.duration <= cfg.max_duration + 0.1
        assert 0 <= m.score <= 100 and 0 <= m.confidence <= 1
        assert m.end <= 45 and m.start >= 0
        assert m.explanation and m.suggested_title
    assert [m.score for m in res] == sorted([m.score for m in res], reverse=True)


def test_burst_window_outranks_boring_window(transcript):
    au, vis = synth_audio(), signals.VisualSignals()
    cfg = AnalysisConfig(min_duration=10, max_duration=30)
    cands = moments.generate_candidates(transcript, au, vis, 45, cfg)
    around = [m for m in cands if m.start <= 20 and m.end >= 24]
    boring = [m for m in cands if m.start >= 30]
    assert around and boring
    assert max(m.score for m in around) > max(m.score for m in boring)


def test_dedupe_removes_overlaps(transcript):
    au, vis = synth_audio(), signals.VisualSignals()
    res = moments.analyse(transcript, au, vis, 45, AnalysisConfig(max_candidates=20))
    for i, a in enumerate(res):
        for b in res[i + 1:]:
            assert moments.overlap_ratio(a, b) <= 0.3 + 1e-9


def test_min_score_filter(transcript):
    au, vis = synth_audio(), signals.VisualSignals()
    res = moments.analyse(transcript, au, vis, 45, AnalysisConfig(min_score=99))
    assert res == []


def test_no_speech_fallback_still_produces_candidates():
    au, vis = synth_audio(), signals.VisualSignals(motion=np.linspace(0, 1, 45), available=True)
    res = moments.analyse(Transcript(), au, vis, 45, AnalysisConfig(min_duration=10, max_duration=20))
    assert res and all(m.transcript == "" for m in res)
    assert all(m.confidence < 0.8 for m in res)        # no transcript => lower confidence


def test_config_validation():
    with pytest.raises(Exception):
        AnalysisConfig(min_duration=40, max_duration=20)


def test_title_generation():
    assert moments.make_title("") == "Untitled moment"
    assert len(moments.make_title("word " * 60)) <= 71
    assert moments.make_title("hello there. second") == "Hello there."


def test_range_restricts_candidates(transcript):
    au, vis = synth_audio(), signals.VisualSignals()
    cfg = AnalysisConfig(min_duration=8, max_duration=20, range_start=18, range_end=30)
    res = moments.analyse(transcript, au, vis, 45, cfg)
    assert res
    for m in res:
        assert m.start >= 17 and m.end <= 34


def test_range_validation():
    with pytest.raises(Exception):
        AnalysisConfig(range_start=10)
    with pytest.raises(Exception):
        AnalysisConfig(range_start=10, range_end=5)
