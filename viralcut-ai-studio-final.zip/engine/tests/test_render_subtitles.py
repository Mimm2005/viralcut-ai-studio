import os
import pytest
from app import media, render, subtitles
from app.models import RenderRequest, SubtitleStyle, CropSpec, Word
from conftest import make_words


def test_ass_colour_conversion():
    assert subtitles.ass_color("#FF0000") == "&H000000FF"      # ASS is BGR
    assert subtitles.ass_color("#00FF00", 0x60) == "&H6000FF00"
    with pytest.raises(ValueError):
        subtitles.ass_color("red")


def test_ass_modes():
    w = make_words("hello brave new world again", 10.0)
    assert subtitles.build_ass(w, SubtitleStyle(mode="none"), 10, 20) == ""
    assert subtitles.build_ass([], SubtitleStyle(), 10, 20) == ""
    std = subtitles.build_ass(w, SubtitleStyle(mode="standard", max_words_per_line=3), 10, 20)
    assert "hello brave new" in std and "\\kf" not in std
    assert std.count("Dialogue:") == 2
    hl = subtitles.build_ass(w, SubtitleStyle(mode="highlight"), 10, 20)
    assert "\\kf" in hl
    assert "Dialogue: 0,0:00:00.00" in std                      # times are clip-relative


def test_ass_sanitises_injection():
    w = [Word(start=0, end=1, text="{\\fs999}evil\\N")]
    out = subtitles.build_ass(w, SubtitleStyle(), 0, 5)
    assert "{\\fs999}" not in out


def test_crop_geometry():
    w, h, x, y = render.crop_geometry(1920, 1080, 0.5)
    assert (w, h) == (606, 1080) and x == (1920 - 606) // 2 // 2 * 2 or abs(x - 657) <= 2
    w, h, x, y = render.crop_geometry(1920, 1080, 0.0)
    assert x == 0
    w, h, x, y = render.crop_geometry(1920, 1080, 1.0)
    assert x + w <= 1920
    w, h, x, y = render.crop_geometry(1080, 1920, 0.5)           # already vertical
    assert (w, h) == (1080, 1920) and x == 0 and y == 0
    w, h, x, y = render.crop_geometry(1000, 1000, 0.5)           # square source
    assert h == 1000 and w == 562


def test_request_validation(sample_video, tmp_path):
    with pytest.raises(Exception):
        RenderRequest(source_path=sample_video, output_path="o.mp4", start=10, end=5)
    with pytest.raises(Exception):
        RenderRequest(source_path=sample_video, output_path="o.mp4", start=0, end=500)


def _render(sample_video, tmp_path, **kw):
    out = str(tmp_path / "out.mp4")
    base = dict(source_path=sample_video, output_path=out, start=5, end=15, resolution="720p",
                crop=CropSpec(mode="center"), subtitles=SubtitleStyle(mode="none"))
    base.update(kw)
    req = RenderRequest(**base)
    prog = []
    res = render.render(req, prog.append)
    return req, res, prog


def test_render_720p_format_and_duration(sample_video, tmp_path):
    req, res, prog = _render(sample_video, tmp_path)
    assert render.verify_output(req.output_path, 10, "720p") == []
    assert prog and prog[-1] == 1.0 and all(0 <= p <= 1 for p in prog)


def test_trim_accuracy_and_av_sync(sample_video, tmp_path):
    req, res, _ = _render(sample_video, tmp_path, start=12.5, end=19.0, normalize_audio=False)
    info = media.probe(req.output_path)
    assert abs(info.duration - 6.5) < 0.3
    # audio and video stream durations must agree (sync)
    import json, subprocess
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,duration", "-of", "json",
                          req.output_path], capture_output=True, text=True).stdout
    d = {s["codec_type"]: float(s["duration"]) for s in json.loads(out)["streams"]}
    assert abs(d["video"] - d["audio"]) < 0.25


def test_render_1080p_with_highlight_subtitles_and_title(sample_video, tmp_path):
    words = make_words("this is a subtitle test with several words in it", 6.0)
    req, res, _ = _render(sample_video, tmp_path, resolution="1080p", words=words, title_overlay="Test: Title, here",
                          subtitles=SubtitleStyle(mode="highlight"), end=12)
    assert render.verify_output(req.output_path, 7, "1080p") == []


def test_manual_and_smart_crop_modes(sample_video, tmp_path):
    _, res, _ = _render(sample_video, tmp_path, crop=CropSpec(mode="manual", x=0.1))
    assert res["crop_center_x"] == 0.1
    _, res, _ = _render(sample_video, tmp_path, crop=CropSpec(mode="smart"))
    assert 0.0 <= res["crop_center_x"] <= 1.0                     # never crashes without faces


def test_render_silent_source(silent_video, tmp_path):
    out = str(tmp_path / "s.mp4")
    req = RenderRequest(source_path=silent_video, output_path=out, start=0, end=6, resolution="720p",
                        subtitles=SubtitleStyle(mode="none"), crop=CropSpec(mode="center"))
    render.render(req)
    assert media.probe(out).has_audio is False


def test_end_beyond_source_rejected(sample_video, tmp_path):
    with pytest.raises(media.MediaError):
        render.render(RenderRequest(source_path=sample_video, output_path=str(tmp_path / "x.mp4"), start=40, end=60))
