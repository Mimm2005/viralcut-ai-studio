import os, subprocess, sys
import pytest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ.setdefault("ENGINE_TOKEN", "test-token")

from app.models import Segment, Transcript, Word


def _ff(args):
    subprocess.run(["ffmpeg", "-y", "-v", "error"] + args, check=True)


@pytest.fixture(scope="session")
def sample_video(tmp_path_factory):
    """45 s 640x360 test pattern with a loud burst between 20 s and 24 s."""
    p = str(tmp_path_factory.mktemp("media") / "sample.mp4")
    _ff(["-f", "lavfi", "-i", "testsrc2=size=640x360:rate=30:duration=45",
         "-f", "lavfi", "-i", "sine=frequency=330:sample_rate=16000:duration=45",
         "-af", "volume='if(between(t,20,24),1.0,0.08)':eval=frame",
         "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", p])
    return p


@pytest.fixture(scope="session")
def silent_video(tmp_path_factory):
    p = str(tmp_path_factory.mktemp("media") / "silent.mp4")
    _ff(["-f", "lavfi", "-i", "testsrc2=size=320x240:rate=25:duration=12", "-c:v", "libx264", "-pix_fmt", "yuv420p", p])
    return p


def make_words(text, start, per=0.4):
    out, t = [], start
    for w in text.split():
        out.append(Word(start=t, end=t + per * 0.9, text=w))
        t += per
    return out


@pytest.fixture
def transcript():
    lines = [
        (1.0, "So here is the thing nobody tells you about this."),
        (5.0, "We tried it and honestly it was kind of boring."),
        (10.0, "Then suddenly wait what is that, oh my god!"),
        (20.0, "No way, that is insane, I can't believe it! haha"),
        (25.0, "Okay that was the best thing I have ever seen."),
        (32.0, "Anyway, let's move on to the next topic here."),
        (38.0, "Thanks for watching and see you next time."),
    ]
    segs = []
    for s, txt in lines:
        w = make_words(txt, s)
        segs.append(Segment(start=s, end=w[-1].end, text=txt, words=w))
    return Transcript(language="en", segments=segs)


class FakeSeg:
    def __init__(self, s, e, t, words):
        self.start, self.end, self.text, self.words = s, e, t, words


class FakeWord:
    def __init__(self, s, e, w):
        self.start, self.end, self.word, self.probability = s, e, w, 0.9


class FakeInfo:
    language = "en"


class FakeModel:
    """Stands in for faster-whisper in tests only. Emits one segment per chunk."""
    def __init__(self, fail_times=0, fail_on=()):
        self.calls, self.fail_times, self.fail_on = 0, fail_times, set(fail_on)

    def transcribe(self, wav, language=None, word_timestamps=True, vad_filter=True):
        self.calls += 1
        if self.calls <= self.fail_times or self.calls in self.fail_on:
            raise RuntimeError("simulated model failure")
        words = [FakeWord(1 + i * 0.4, 1.3 + i * 0.4, w) for i, w in enumerate("wait what no way that is insane!".split())]
        return [FakeSeg(1.0, 4.0, "wait what no way that is insane!", words)], FakeInfo()
