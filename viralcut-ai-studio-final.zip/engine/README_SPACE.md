---
title: ViralCut Engine
emoji: ✂️
sdk: docker
app_port: 7860
pinned: false
---
Processing engine for ViralCut AI Studio. Copy this file to `README.md` in the root of the Space repository
(together with `Dockerfile`, `requirements.txt` and the `app/` folder). Set the `ENGINE_TOKEN` secret in Space settings.
