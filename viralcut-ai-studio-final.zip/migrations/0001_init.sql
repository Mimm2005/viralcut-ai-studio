-- ViralCut AI Studio: core schema (Cloudflare D1 / SQLite). All timestamps are unix epoch seconds (UTC).
PRAGMA foreign_keys = ON;

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL DEFAULT 'Owner',
  password_hash TEXT NOT NULL,            -- PBKDF2-SHA256 "pbkdf2$iters$salt$hash"
  role TEXT NOT NULL DEFAULT 'owner' CHECK (role IN ('owner','member')),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE sessions (
  id TEXT PRIMARY KEY,                    -- sha256(token); the raw token only lives in the cookie
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf_token TEXT NOT NULL,
  user_agent TEXT,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  last_seen_at INTEGER NOT NULL
);
CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

CREATE TABLE projects (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','importing','ready','analyzing','analyzed','failed')),
  category TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX idx_projects_user ON projects(user_id, created_at DESC);

CREATE TABLE source_media (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  adapter TEXT NOT NULL CHECK (adapter IN ('upload','youtube','cloud','livestream')),
  -- the four distinct states required by the spec; never skip ahead
  state TEXT NOT NULL DEFAULT 'submitted' CHECK (state IN
    ('submitted','validated','authorized','imported','pending_configuration','rejected','unsupported','upload_pending')),
  source_url TEXT,
  r2_key TEXT,
  original_filename TEXT,
  fingerprint TEXT,                       -- duplicate detection
  size_bytes INTEGER,
  duration_s REAL, width INTEGER, height INTEGER, fps REAL, has_audio INTEGER,
  mime_type TEXT,
  message TEXT,
  missing_config TEXT,                    -- JSON array
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX idx_source_project ON source_media(project_id);
CREATE UNIQUE INDEX idx_source_dupe ON source_media(user_id, fingerprint) WHERE fingerprint IS NOT NULL;

CREATE TABLE processing_jobs (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  source_id TEXT NOT NULL REFERENCES source_media(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL DEFAULT 'analyze' CHECK (kind IN ('analyze','render')),
  status TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','running','succeeded','failed','cancelled')),
  progress REAL NOT NULL DEFAULT 0,
  step TEXT,
  engine_job_id TEXT,
  config TEXT NOT NULL DEFAULT '{}',      -- JSON analysis config
  attempts INTEGER NOT NULL DEFAULT 0,
  error TEXT,
  last_synced_at INTEGER,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  finished_at INTEGER
);
CREATE INDEX idx_jobs_user ON processing_jobs(user_id, created_at DESC);
CREATE INDEX idx_jobs_status ON processing_jobs(status);

CREATE TABLE job_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id TEXT NOT NULL REFERENCES processing_jobs(id) ON DELETE CASCADE,
  ts INTEGER NOT NULL,
  level TEXT NOT NULL DEFAULT 'info',
  message TEXT NOT NULL
);
CREATE INDEX idx_job_events_job ON job_events(job_id, id);

CREATE TABLE transcripts (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL REFERENCES source_media(id) ON DELETE CASCADE,
  job_id TEXT REFERENCES processing_jobs(id) ON DELETE SET NULL,
  language TEXT NOT NULL DEFAULT 'en',
  segments TEXT NOT NULL,                 -- JSON [{start,end,text,words:[...]}]
  full_text TEXT,
  created_at INTEGER NOT NULL
);
CREATE UNIQUE INDEX idx_transcripts_source ON transcripts(source_id);

CREATE TABLE detected_moments (
  id TEXT PRIMARY KEY,
  job_id TEXT NOT NULL REFERENCES processing_jobs(id) ON DELETE CASCADE,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  source_id TEXT NOT NULL REFERENCES source_media(id) ON DELETE CASCADE,
  rank INTEGER NOT NULL,
  start_s REAL NOT NULL,
  end_s REAL NOT NULL,
  moment_type TEXT NOT NULL DEFAULT 'general',
  transcript TEXT,
  suggested_title TEXT,
  selected INTEGER NOT NULL DEFAULT 0,
  user_edited INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  CHECK (end_s > start_s)
);
CREATE INDEX idx_moments_job ON detected_moments(job_id, rank);

-- predicted scores, stored apart from the actual performance (analytics_snapshots)
CREATE TABLE moment_scores (
  id TEXT PRIMARY KEY,
  moment_id TEXT NOT NULL REFERENCES detected_moments(id) ON DELETE CASCADE,
  total REAL NOT NULL CHECK (total BETWEEN 0 AND 100),
  hook REAL NOT NULL, emotion REAL NOT NULL, entertainment REAL NOT NULL,
  unexpectedness REAL NOT NULL, shareability REAL NOT NULL, storytelling REAL NOT NULL,
  confidence REAL NOT NULL CHECK (confidence BETWEEN 0 AND 1),
  explanation TEXT NOT NULL,
  signals TEXT,                           -- JSON measurable evidence
  model_version TEXT NOT NULL DEFAULT 'rules-1',
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_scores_moment ON moment_scores(moment_id);

CREATE TABLE generated_clips (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  moment_id TEXT REFERENCES detected_moments(id) ON DELETE SET NULL,
  source_id TEXT NOT NULL REFERENCES source_media(id) ON DELETE CASCADE,
  title TEXT,
  start_s REAL NOT NULL, end_s REAL NOT NULL,
  settings TEXT NOT NULL DEFAULT '{}',    -- JSON render settings (crop, subtitles, resolution)
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','queued','rendering','ready','failed')),
  progress REAL NOT NULL DEFAULT 0,
  engine_job_id TEXT,
  r2_key TEXT, size_bytes INTEGER, duration_s REAL, width INTEGER, height INTEGER,
  error TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  CHECK (end_s > start_s)
);
CREATE INDEX idx_clips_user ON generated_clips(user_id, created_at DESC);
CREATE INDEX idx_clips_project ON generated_clips(project_id);

CREATE TABLE clip_metadata (
  id TEXT PRIMARY KEY,
  clip_id TEXT NOT NULL REFERENCES generated_clips(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('youtube','instagram','facebook','tiktok','x')),
  title TEXT,
  title_alternatives TEXT,                -- JSON array
  description TEXT,
  caption TEXT,
  hashtags TEXT,                          -- JSON array
  tags TEXT,                              -- JSON array (YouTube only)
  category TEXT, language TEXT NOT NULL DEFAULT 'en',
  privacy TEXT NOT NULL DEFAULT 'private',
  cover_recommendation TEXT,
  source TEXT NOT NULL DEFAULT 'manual' CHECK (source IN ('ai','template','manual')),
  provider TEXT, model TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  UNIQUE (clip_id, platform)
);

CREATE TABLE ai_providers (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('gemini','openai','anthropic','custom')),
  label TEXT NOT NULL,
  base_url TEXT,                          -- custom / OpenAI-compatible endpoints
  model TEXT NOT NULL,
  api_key_enc TEXT NOT NULL,              -- AES-GCM ciphertext; never returned by the API
  key_hint TEXT,                          -- last 4 chars only
  temperature REAL, max_tokens INTEGER,
  cost_tier TEXT NOT NULL DEFAULT 'unknown' CHECK (cost_tier IN ('free','paid','unknown')),
  is_default INTEGER NOT NULL DEFAULT 0,
  allow_fallback INTEGER NOT NULL DEFAULT 0,  -- must be explicitly enabled by the user
  task_routes TEXT NOT NULL DEFAULT '[]', -- JSON array of tasks, e.g. ["metadata","reasoning"]
  monthly_call_limit INTEGER,
  monthly_budget_inr REAL,
  price_in_per_mtok_inr REAL, price_out_per_mtok_inr REAL,
  status TEXT NOT NULL DEFAULT 'untested' CHECK (status IN ('untested','ok','error','paused')),
  last_error TEXT, last_tested_at INTEGER,
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE INDEX idx_ai_user ON ai_providers(user_id);

CREATE TABLE ai_usage (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  provider_id TEXT NOT NULL REFERENCES ai_providers(id) ON DELETE CASCADE,
  task TEXT NOT NULL,
  tokens_in INTEGER, tokens_out INTEGER,
  est_cost_inr REAL,                      -- NULL when prices are unknown (never invented)
  ok INTEGER NOT NULL,
  error TEXT,
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_ai_usage_provider ON ai_usage(provider_id, created_at);

CREATE TABLE social_accounts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('youtube','instagram','facebook','tiktok','x')),
  external_id TEXT, display_name TEXT, handle TEXT, avatar_url TEXT,
  status TEXT NOT NULL DEFAULT 'connected' CHECK (status IN ('connected','error','expired','revoked','pending_approval')),
  scopes TEXT,                            -- JSON array of GRANTED scopes
  extra TEXT,                             -- JSON (e.g. page id, ig user id)
  last_error TEXT,
  connected_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
  UNIQUE (user_id, platform)              -- single-account mode in V1; drop this index for multi-account later
);

CREATE TABLE oauth_tokens (
  id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES social_accounts(id) ON DELETE CASCADE,
  access_token_enc TEXT NOT NULL,
  refresh_token_enc TEXT,
  expires_at INTEGER,
  token_type TEXT,
  updated_at INTEGER NOT NULL,
  UNIQUE (account_id)
);

CREATE TABLE oauth_states (
  state TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform TEXT NOT NULL,
  code_verifier TEXT,
  expires_at INTEGER NOT NULL
);

CREATE TABLE publishing_schedules (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('youtube','instagram','facebook','tiktok','x')),
  kind TEXT NOT NULL CHECK (kind IN ('daily','weekly','custom')),
  times TEXT NOT NULL,                    -- JSON ["18:30"]
  weekdays TEXT,                          -- JSON [1..7]
  timezone TEXT NOT NULL DEFAULT 'Asia/Kolkata',
  active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);

CREATE TABLE publishing_jobs (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  clip_id TEXT NOT NULL REFERENCES generated_clips(id) ON DELETE CASCADE,
  metadata_id TEXT NOT NULL REFERENCES clip_metadata(id) ON DELETE CASCADE,
  account_id TEXT NOT NULL REFERENCES social_accounts(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('youtube','instagram','facebook','tiktok','x')),
  status TEXT NOT NULL DEFAULT 'pending_approval' CHECK (status IN
    ('pending_approval','approved','scheduled','publishing','needs_verification','published','failed','cancelled')),
  approved_at INTEGER,
  run_at INTEGER,                         -- UTC epoch of the scheduled publish time
  timezone TEXT NOT NULL DEFAULT 'Asia/Kolkata',
  attempts INTEGER NOT NULL DEFAULT 0,
  max_attempts INTEGER NOT NULL DEFAULT 3,
  next_attempt_at INTEGER,
  lease_expires_at INTEGER,
  stage TEXT,                             -- adapter stage, e.g. 'container_created'
  external_ref TEXT,                      -- platform id saved BEFORE the final commit call (duplicate protection)
  progress REAL NOT NULL DEFAULT 0,
  error TEXT,
  snapshot TEXT,                          -- JSON of the approved metadata at approval time
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE INDEX idx_pubjobs_due ON publishing_jobs(status, run_at);
CREATE INDEX idx_pubjobs_user ON publishing_jobs(user_id, run_at);
-- duplicate prevention: only one live job per clip+platform
CREATE UNIQUE INDEX idx_pubjobs_unique_active ON publishing_jobs(clip_id, platform)
  WHERE status IN ('pending_approval','approved','scheduled','publishing','needs_verification');

CREATE TABLE published_posts (
  id TEXT PRIMARY KEY,
  publishing_job_id TEXT NOT NULL UNIQUE REFERENCES publishing_jobs(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  clip_id TEXT NOT NULL REFERENCES generated_clips(id) ON DELETE CASCADE,
  platform TEXT NOT NULL,
  external_id TEXT NOT NULL,              -- ID returned by the platform
  url TEXT,
  platform_status TEXT,                   -- what the platform itself reported
  verified_at INTEGER NOT NULL,           -- only set after the platform confirmed
  published_at INTEGER NOT NULL,
  predicted_score REAL,                   -- copied from moment_scores at publish time
  duration_s REAL, moment_type TEXT, title TEXT, hook_text TEXT,
  UNIQUE (platform, external_id)
);
CREATE INDEX idx_posts_user ON published_posts(user_id, published_at DESC);

CREATE TABLE publishing_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  publishing_job_id TEXT NOT NULL REFERENCES publishing_jobs(id) ON DELETE CASCADE,
  ts INTEGER NOT NULL,
  level TEXT NOT NULL DEFAULT 'info',
  message TEXT NOT NULL,
  http_status INTEGER
);
CREATE INDEX idx_publogs_job ON publishing_logs(publishing_job_id, id);

CREATE TABLE analytics_snapshots (
  id TEXT PRIMARY KEY,
  post_id TEXT NOT NULL REFERENCES published_posts(id) ON DELETE CASCADE,
  captured_at INTEGER NOT NULL,
  metrics TEXT NOT NULL,                  -- JSON {metric: number|null}
  unavailable TEXT,                       -- JSON {metric: reason} for metrics the API did not provide
  source TEXT NOT NULL DEFAULT 'api'
);
CREATE INDEX idx_snap_post ON analytics_snapshots(post_id, captured_at);

CREATE TABLE notifications (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  link TEXT,
  read INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_notif_user ON notifications(user_id, read, created_at DESC);

CREATE TABLE user_settings (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  timezone TEXT NOT NULL DEFAULT 'Asia/Kolkata',
  currency TEXT NOT NULL DEFAULT 'INR',
  language TEXT NOT NULL DEFAULT 'en',
  default_resolution TEXT NOT NULL DEFAULT '1080p',
  subtitle_style TEXT NOT NULL DEFAULT '{}',
  default_privacy TEXT NOT NULL DEFAULT 'private',
  queue_paused INTEGER NOT NULL DEFAULT 0,
  retention_days INTEGER NOT NULL DEFAULT 30,
  storage_quota_mb INTEGER NOT NULL DEFAULT 9000,
  notifications TEXT NOT NULL DEFAULT '{}',
  prompt_templates TEXT NOT NULL DEFAULT '{}',
  updated_at INTEGER NOT NULL
);

CREATE TABLE audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target TEXT,
  ip TEXT,
  detail TEXT,
  ts INTEGER NOT NULL
);
CREATE INDEX idx_audit_user ON audit_logs(user_id, ts DESC);

CREATE TABLE rate_limits (
  key TEXT NOT NULL,
  window_start INTEGER NOT NULL,
  count INTEGER NOT NULL,
  PRIMARY KEY (key, window_start)
);
