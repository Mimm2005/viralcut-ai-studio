import { h, mount, clear, icon, api, session, toast, fail, field, validators, busy, routes, render, fmtDate } from './core.js';
import './pages/dashboard.js'; import './pages/finder.js'; import './pages/studio.js'; import './pages/publish.js'; import './pages/insights.js';

export const NAV = [['dashboard', 'Dashboard', 'home'], ['finder', 'Viral Finder', 'search'], ['projects', 'Video Projects', 'folder'], ['metadata', 'AI Metadata', 'tag'], ['editor', 'Shorts Editor', 'scissors'],
  ['accounts', 'Social Accounts', 'link'], ['calendar', 'Publishing Calendar', 'calendar'], ['analytics', 'Analytics', 'chart'], ['providers', 'AI Providers', 'cpu'], ['settings', 'Settings', 'settings']];

function buildShell() {
  const side = document.getElementById('sidebar');
  mount(side, h('div', { class: 'brand' }, icon('scissors', 22), h('span', {}, 'ViralCut AI Studio')), ...NAV.map(([r, label, ic]) => h('a', { href: `#/${r}`, 'data-route': r, onclick: () => side.classList.remove('open') }, icon(ic), h('span', { class: 'label' }, label))));
  const menu = document.getElementById('menu-btn'); mount(menu, icon('menu'));
  menu.onclick = () => { if (matchMedia('(max-width:800px)').matches) side.classList.toggle('open'); else side.classList.toggle('collapsed'); };
  const theme = document.getElementById('theme'); mount(theme, icon('sun')); const saved = localStorage.getItem('vc-theme'); if (saved) document.documentElement.dataset.theme = saved;
  theme.onclick = () => { const dark = (document.documentElement.dataset.theme || (matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light')) === 'dark'; const next = dark ? 'light' : 'dark'; document.documentElement.dataset.theme = next; try { localStorage.setItem('vc-theme', next); } catch { /* private mode */ } };
  document.getElementById('logout').onclick = async () => { await api.post('/api/auth/logout').catch(() => {}); location.hash = ''; location.reload(); };
  const bell = document.getElementById('bell'); mount(bell, icon('bell'));
  bell.onclick = async () => { try { const { notifications } = await api.get('/api/notifications'); const { modal } = await import('./core.js');
      modal('Notifications', notifications.length ? h('div', { class: 'stack' }, notifications.slice(0, 30).map((n) => h('div', { class: 'notice' }, h('strong', {}, n.title), h('div', { class: 'small muted' }, `${fmtDate(n.created_at)} ${n.body || ''}`), n.link ? h('a', { href: n.link, class: 'small' }, 'Open') : null))) : h('p', { class: 'muted' }, 'No notifications.'));
      await api.post('/api/notifications/read'); refreshBell(); } catch (e) { fail(e); } };
}
async function refreshBell() { try { const { unread } = await api.get('/api/notifications'); const bell = document.getElementById('bell'); bell.querySelector('.dot')?.remove(); if (unread) bell.append(h('span', { class: 'dot' }, unread > 9 ? '9+' : unread)); } catch { /* signed out */ } }

function authScreen(setupRequired) {
  const auth = document.getElementById('auth'); auth.hidden = false;
  const email = h('input', { type: 'email', autocomplete: 'username', required: true }), pw = h('input', { type: 'password', autocomplete: setupRequired ? 'new-password' : 'current-password', required: true }), tok = h('input', { type: 'password', autocomplete: 'off' }); const err = h('div', { class: 'err-msg', role: 'alert' });
  const submit = (btn) => { err.textContent = ''; const bad = validators.email(email.value) || (setupRequired ? validators.password(pw.value) : validators.required(pw.value)) || (setupRequired && validators.required(tok.value) ? 'Enter your setup token' : null); if (bad) { err.textContent = bad; return; }
    busy(btn, async () => { try { if (setupRequired) await api.post('/api/auth/setup', { email: email.value, password: pw.value, setupToken: tok.value }); await api.post('/api/auth/login', { email: email.value, password: pw.value }); location.reload(); } catch (e) { err.textContent = e.status === 429 ? 'Too many attempts. Wait a few minutes.' : e.message; } }); };
  mount(auth, h('div', { class: 'card stack' }, h('h1', {}, setupRequired ? 'Create the owner account' : 'Sign in'), h('p', { class: 'muted small' }, setupRequired ? 'First-run setup. Requires the SETUP_TOKEN you configured on the server. Public registration is not available.' : 'ViralCut AI Studio'),
    field('Email', email), field('Password', pw, { hint: setupRequired ? 'At least 12 characters' : undefined }), setupRequired ? field('Setup token', tok) : null, err, h('button', { class: 'btn primary', style: 'width:100%', onclick: (e) => submit(e.target) }, setupRequired ? 'Create account' : 'Sign in')));
  [email, pw, tok].forEach((i) => i.addEventListener('keydown', (e) => e.key === 'Enter' && submit(auth.querySelector('.btn.primary'))));
}

export async function boot() {
  let me; try { me = await fetch('/api/auth/me', { credentials: 'same-origin' }); } catch { return mount(document.body, h('p', { style: 'padding:20px' }, 'Cannot reach the API.')); }
  const data = await me.json().catch(() => ({}));
  if (!me.ok || !data.user) return authScreen(!!data.setupRequired);
  session.user = data.user; session.csrf = data.csrfToken; document.getElementById('app').hidden = false; buildShell(); refreshBell(); setInterval(refreshBell, 60000);
  addEventListener('hashchange', render); await render();
}
if (typeof window !== 'undefined' && !window.__VC_TEST__) boot();
