import { h, mount, api, badge, bar, field, counted, fail, toast, busy, fmtTime, empty, spinner, routes, poll, modal, validators } from '../core.js';

const PLATFORMS = ['youtube', 'instagram', 'facebook', 'tiktok', 'x'];
const PL = { youtube: 'YouTube', instagram: 'Instagram', facebook: 'Facebook', tiktok: 'TikTok', x: 'X' };

async function clipPicker(current, hrefBase) {
  const { clips } = await api.get('/api/clips');
  const sel = h('select', { 'aria-label': 'Choose clip', onchange: (e) => { location.hash = `${hrefBase}/${e.target.value}`; } }, h('option', { value: '' }, '— choose a clip —'), ...clips.map((c) => h('option', { value: c.id, selected: c.id === current }, `${c.title || 'Untitled'} (${c.status})`)));
  return { sel, clips };
}

routes.editor = async ({ args, signal }) => {
  const id = args[0]; const { sel, clips } = await clipPicker(id, '#/editor');
  if (!id) return h('div', {}, h('h1', {}, 'Shorts Editor'), clips.length ? h('div', { class: 'card' }, field('Clip', sel)) : empty('No clips yet. Pick moments in Viral Finder and render them, or open one in the editor.'));
  let clip = (await api.get(`/api/clips/${id}`)).clip; const S = clip.settings || {}; const sub = S.subtitles || {}; const crop = S.crop || { mode: 'smart' };
  const root = h('div', {}); const status = h('div', {});
  const f = {
    title: h('input', { value: clip.title || '', maxlength: 200 }), start: h('input', { type: 'number', step: '0.1', value: clip.start_s }), end: h('input', { type: 'number', step: '0.1', value: clip.end_s }),
    res: h('select', {}, ['1080p', '720p'].map((r) => h('option', { value: r, selected: (S.resolution || '1080p') === r }, r === '1080p' ? '1080 × 1920' : '720 × 1280 (resource-constrained)'))),
    fps: h('select', {}, h('option', { value: '' }, 'Source FPS'), h('option', { value: '30', selected: S.fps === 30 }, '30 FPS')),
    cropMode: h('select', {}, [['smart', 'Smart crop'], ['center', 'Center crop'], ['manual', 'Manual position']].map(([v, l]) => h('option', { value: v, selected: crop.mode === v }, l))),
    cropX: h('input', { type: 'range', min: 0, max: 1, step: 0.01, value: crop.x ?? 0.5 }),
    subMode: h('select', {}, [['none', 'No subtitles'], ['standard', 'Standard'], ['highlight', 'Highlighted words'], ['custom', 'Custom styling']].map(([v, l]) => h('option', { value: v, selected: (sub.mode || 'standard') === v }, l))),
    font: h('select', {}, ['DejaVu Sans', 'Liberation Sans', 'Arial'].map((x) => h('option', { value: x, selected: (sub.font || 'DejaVu Sans') === x }, x))),
    size: h('input', { type: 'number', min: 16, max: 200, value: sub.size || 64 }), color: h('input', { type: 'color', value: sub.color || '#ffffff' }), hl: h('input', { type: 'color', value: sub.highlight_color || '#ffd400' }), outlineC: h('input', { type: 'color', value: sub.outline_color || '#000000' }),
    outline: h('input', { type: 'number', min: 0, max: 12, value: sub.outline ?? 4 }), bg: h('input', { type: 'checkbox', checked: !!sub.background }), pos: h('select', {}, ['bottom', 'middle', 'top'].map((x) => h('option', { value: x, selected: (sub.position || 'bottom') === x }, x))),
    words: h('input', { type: 'number', min: 1, max: 10, value: sub.max_words_per_line || 4 }), overlay: h('input', { value: S.titleOverlay || '', maxlength: 90, placeholder: 'Optional title overlay (first 3.5 s)' }), norm: h('input', { type: 'checkbox', checked: S.normalizeAudio !== false }),
  };
  const err = h('div', { class: 'err-msg' });
  const collect = () => {
    const bad = validators.range(f.start.value, 0, 100000) || validators.range(f.end.value, 0, 100000) || validators.range(f.size.value, 16, 200) || validators.range(f.outline.value, 0, 12) || validators.range(f.words.value, 1, 10);
    if (bad) throw new Error(bad); const len = f.end.value - f.start.value; if (len < 3 || len > 180) throw new Error('Clip length must be between 3 and 180 seconds');
    const settings = { resolution: f.res.value, crop: { mode: f.cropMode.value, x: +f.cropX.value, y: 0.5 }, normalizeAudio: f.norm.checked, titleOverlay: f.overlay.value || undefined,
      subtitles: { mode: f.subMode.value, font: f.font.value, size: +f.size.value, color: f.color.value, highlight_color: f.hl.value, outline_color: f.outlineC.value, outline: +f.outline.value, background: f.bg.checked, position: f.pos.value, max_words_per_line: +f.words.value } };
    if (f.fps.value) settings.fps = +f.fps.value; return { title: f.title.value, start_s: +f.start.value, end_s: +f.end.value, settings };
  };
  const player = h('video', { controls: true, class: clip.height > clip.width ? 'vertical' : '', preload: 'metadata' }); const draw = () => {
    if (clip.previewUrl) player.src = clip.previewUrl;
    mount(status, h('div', { class: 'row between' }, h('span', {}, 'Render status'), badge(clip.status)), ['queued', 'rendering'].includes(clip.status) ? bar((clip.progress || 0) * 100) : null, clip.error ? h('div', { class: 'notice err' }, clip.error) : null,
      clip.status === 'ready' ? h('div', { class: 'row' }, h('span', { class: 'small muted' }, `${clip.width}×${clip.height} · ${fmtTime(clip.duration_s)}`), h('a', { class: 'btn sm', href: clip.downloadUrl, download: 'clip.mp4' }, 'Download MP4')) : null);
  }; draw();
  const reload = async () => { clip = (await api.get(`/api/clips/${id}`)).clip; draw(); return !['queued', 'rendering'].includes(clip.status); };
  if (['queued', 'rendering'].includes(clip.status)) poll(reload, 3000, signal);
  const section = (t, ...k) => h('div', { class: 'card' }, h('h2', {}, t), ...k);
  return mount(root, h('h1', {}, 'Shorts Editor'), field('Clip', sel), h('div', { class: 'grid g2' },
    h('div', {}, section('Preview', player, status), publishCard(clip)),
    h('div', {}, section('Trim', field('Title', f.title), h('div', { class: 'grid g2' }, field('Start (s)', f.start), field('End (s)', f.end))),
      section('Frame', h('div', { class: 'grid g2' }, field('Resolution', f.res), field('Frame rate', f.fps), field('Crop', f.cropMode), field('Manual horizontal position', f.cropX)), h('p', { class: 'small muted' }, 'Smart crop follows faces, else motion, else the centre. Use manual if it picks the wrong area.')),
      section('Subtitles', h('div', { class: 'grid g2' }, field('Mode', f.subMode), field('Font', f.font), field('Size', f.size), field('Words per line', f.words), field('Text colour', f.color), field('Highlight colour', f.hl), field('Outline colour', f.outlineC), field('Outline width', f.outline), field('Position', f.pos), h('div', { class: 'field' }, h('label', {}, 'Background box'), f.bg))),
      section('Extras', field('Title overlay', f.overlay), h('label', { class: 'row' }, f.norm, 'Normalise audio loudness')),
      err, h('div', { class: 'row' }, h('button', { class: 'btn primary', onclick: (e) => { err.textContent = ''; busy(e.target, async () => { try { const body = collect(); await api.patch(`/api/clips/${id}`, body); await api.post(`/api/clips/${id}/render`); toast('Render queued'); await reload(); poll(reload, 3000, signal); } catch (x) { err.textContent = x.message; } }); } }, 'Save & render'),
        h('button', { class: 'btn', onclick: (e) => busy(e.target, async () => { try { await api.patch(`/api/clips/${id}`, collect()); toast('Saved'); } catch (x) { err.textContent = x.message; } }) }, 'Save only'),
        h('button', { class: 'btn danger', onclick: () => modal('Delete clip?', h('p', {}, 'The rendered file will be removed.'), [{ label: 'Delete', kind: 'danger', run: async () => { await api.del(`/api/clips/${id}`); location.hash = '#/editor'; } }]) }, 'Delete')))));
};

function publishCard(clip) {
  if (clip.status !== 'ready') return h('div', { class: 'card' }, h('h2', {}, 'Publish'), h('p', { class: 'muted' }, 'Render the clip first. You approve exact metadata before anything is queued.'));
  const pl = h('select', {}, PLATFORMS.map((p) => h('option', { value: p }, PL[p]))); const when = h('input', { type: 'datetime-local' }); const msg = h('div', { class: 'small' });
  return h('div', { class: 'card' }, h('h2', {}, 'Review & schedule'), h('p', { class: 'small muted' }, 'Approving freezes the current metadata. After approval the post publishes automatically at the chosen time, with no further confirmation.'),
    h('div', { class: 'grid g2' }, field('Platform', pl), field('Publish at (your timezone from Settings)', when)), msg,
    h('div', { class: 'row' }, h('a', { class: 'btn', href: `#/metadata/${clip.id}` }, 'Edit metadata'), h('button', { class: 'btn primary', onclick: (e) => busy(e.target, async () => {
      if (!when.value) throw new Error('Choose a date and time');
      const a = await api.post('/api/publishing/approve', { clipId: clip.id, platform: pl.value });
      try { await api.post('/api/publishing/schedule', { jobId: a.job.id, localTime: when.value }); } catch (x) { msg.textContent = 'Approved but not scheduled: ' + x.message; throw x; }
      toast('Approved and scheduled'); location.hash = '#/calendar'; }) }, 'Approve & schedule')));
}

routes.metadata = async ({ args }) => {
  const id = args[0]; const { sel, clips } = await clipPicker(id, '#/metadata');
  if (!id) return h('div', {}, h('h1', {}, 'AI Metadata'), clips.length ? h('div', { class: 'card' }, field('Clip', sel)) : empty('No clips yet.'));
  const { metadata, specs } = await api.get(`/api/metadata/${id}`); const by = Object.fromEntries(metadata.map((m) => [m.platform, m]));
  let active = 'youtube'; const body = h('div', {}); const tabs = h('div', { class: 'tabs', role: 'tablist' });
  const lang = h('input', { value: 'en', maxlength: 10, style: 'width:80px' }); const tpl = h('input', { placeholder: 'Optional style instruction, e.g. "playful, no emojis"', maxlength: 500 });
  const drawTabs = () => mount(tabs, ...PLATFORMS.map((p) => h('button', { role: 'tab', class: p === active ? 'active' : '', onclick: () => { active = p; drawTabs(); drawBody(); } }, PL[p], by[p] ? ' ✓' : '')));
  const gen = (btn, mode, fields) => busy(btn, async () => { const r = await api.post('/api/metadata/generate', { clipId: id, platforms: [active], language: lang.value || 'en', template: tpl.value || undefined, mode, fields }); const m = r.metadata[0]; by[active] = m; toast(m.warnings?.length ? m.warnings.join('; ') : `Generated (${m.source})`); drawBody(); });
  function drawBody() {
    const m = by[active]; const sp = specs[active];
    if (!m) return mount(body, h('div', { class: 'card' }, h('p', { class: 'muted' }, `No ${PL[active]} metadata yet.`), h('div', { class: 'row' }, h('button', { class: 'btn primary', onclick: (e) => gen(e.target, 'ai') }, 'Generate with AI'), h('button', { class: 'btn', onclick: (e) => gen(e.target, 'template') }, 'Draft from transcript (no AI)')), h('p', { class: 'small muted' }, 'AI generation uses the provider you configured under AI Providers. If none is configured nothing is sent anywhere.')));
    const el = {}; const ta = (k, max, rows) => { el[k] = h('textarea', { rows: rows || 3 }, m[k] || ''); return counted(k[0].toUpperCase() + k.slice(1), el[k], max); };
    const fields = [];
    if (sp.title) { el.title = h('input', { value: m.title || '' }); fields.push(counted('Title', el.title, sp.title)); }
    if (sp.description) fields.push(ta('description', sp.description, 5)); if (sp.caption) fields.push(ta('caption', sp.caption, 4));
    el.hashtags = h('input', { value: (m.hashtags || []).map((x) => '#' + x).join(' ') }); fields.push(field(`Hashtags (max ${sp.hashtags})`, el.hashtags));
    if (active === 'youtube') { el.tags = h('input', { value: (m.tags || []).join(', ') }); fields.push(field('Tags (500 characters total)', el.tags)); el.category = h('input', { value: m.category || '24' }); fields.push(field('Category ID', el.category)); }
    else fields.push(h('p', { class: 'small muted' }, `${PL[active]} has no separate tags field.`));
    if (sp.privacy?.length) { el.privacy = h('select', {}, sp.privacy.map((x) => h('option', { value: x, selected: x === m.privacy }, x))); fields.push(field('Privacy', el.privacy)); }
    const save = (btn) => busy(btn, async () => { const b = { hashtags: el.hashtags.value.split(/[\s,]+/).filter(Boolean) }; for (const k of ['title', 'description', 'caption', 'category', 'privacy']) if (el[k]) b[k] = el[k].value; if (el.tags) b.tags = el.tags.value.split(',').map((x) => x.trim()).filter(Boolean);
      const r = await api.patch(`/api/metadata/${m.id}`, b); by[active] = r.metadata; toast(r.warnings.length ? r.warnings.join('; ') : 'Saved'); drawBody(); });
    const copyText = () => [el.title?.value, el.description?.value || el.caption?.value, el.hashtags.value].filter(Boolean).join('\n\n');
    mount(body, h('div', { class: 'card' }, h('div', { class: 'row between' }, badge(m.source), h('span', { class: 'small muted' }, m.provider ? `${m.provider} · ${m.model}` : '')), ...fields,
      m.titleAlternatives?.length ? h('div', { class: 'field' }, h('label', {}, 'Title alternatives (click to use)'), ...m.titleAlternatives.map((t) => h('button', { class: 'btn sm', style: 'margin:2px', onclick: () => { el.title.value = t; el.title.dispatchEvent(new Event('input')); } }, t))) : null,
      m.coverRecommendation ? h('p', { class: 'small' }, 'Cover idea: ' + m.coverRecommendation) : null,
      h('div', { class: 'row' }, h('button', { class: 'btn primary', onclick: (e) => save(e.target) }, 'Save'), h('button', { class: 'btn', onclick: (e) => gen(e.target, 'ai') }, 'Regenerate all'),
        ...(sp.title ? [h('button', { class: 'btn', onclick: (e) => gen(e.target, 'ai', ['title', 'title_alternatives']) }, 'Regenerate title')] : []), ...(sp.hashtags ? [h('button', { class: 'btn', onclick: (e) => gen(e.target, 'ai', ['hashtags']) }, 'Regenerate hashtags')] : []),
        h('button', { class: 'btn', onclick: () => navigator.clipboard.writeText(copyText()).then(() => toast('Copied'), () => toast('Copy not permitted by the browser', 'err')) }, 'Copy'))));
  }
  drawTabs(); drawBody();
  return h('div', {}, h('h1', {}, 'AI Metadata'), field('Clip', sel), h('div', { class: 'card row' }, h('div', {}, field('Language', lang)), h('div', { style: 'flex:1;min-width:240px' }, field('Prompt template', tpl))), tabs, body,
    h('a', { class: 'btn', href: `#/editor/${id}` }, 'Back to editor'));
};
