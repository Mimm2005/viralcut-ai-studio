import { h, mount, api, badge, bar, field, validators, fail, toast, busy, fmtTime, fmtDate, fmtBytes, empty, spinner, errorBox, routes, poll, modal, confirmBox, session } from '../core.js';

const TYPES = ['', 'funny', 'surprising', 'emotional', 'story', 'action', 'general'];
const FACTORS = [['hook', 'Opening hook'], ['emotion', 'Emotional intensity'], ['entertainment', 'Entertainment'], ['unexpectedness', 'Unexpectedness'], ['shareability', 'Shareability'], ['storytelling', 'Storytelling']];
const ACTIVE = ['queued', 'running'];

function uploadWithProgress(url, method, file, headers, onProgress) {
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest(); x.open(method, url); for (const [k, v] of Object.entries(headers || {})) x.setRequestHeader(k, v);
    if (url.startsWith('/')) x.setRequestHeader('x-csrf-token', session.csrf);
    x.upload.onprogress = (e) => e.lengthComputable && onProgress(e.loaded / e.total);
    x.onload = () => (x.status < 300 ? resolve() : reject(new Error(`Upload failed (HTTP ${x.status})`)));
    x.onerror = () => reject(new Error('Upload failed: network error')); x.send(file);
  });
}

routes.finder = async ({ query, signal, view }) => {
  const st = { project: null, source: null, jobId: null, moments: [] };
  const root = h('div', {}); const body = h('div', {});
  const draw = () => mount(root, h('h1', {}, 'Viral Finder'), h('p', { class: 'muted' }, 'Import a video you have the rights to, analyse it, and review ranked moments with the evidence behind each score.'), body);
  draw();
  const projects = (await api.get('/api/projects')).projects;
  if (query.project) await loadProject(query.project); else showStep();
  return root;

  async function loadProject(id) {
    const d = await api.get(`/api/projects/${id}`); st.project = d.project; st.sources = d.sources; st.jobs = d.jobs;
    const src = d.sources.find((s) => ['validated', 'imported'].includes(s.state)) || d.sources[0]; st.source = src || null;
    const done = d.jobs.find((j) => j.status === 'succeeded'); const active = d.jobs.find((j) => ACTIVE.includes(j.status));
    st.jobId = (active || done)?.id || null; showStep();
  }

  function showStep() {
    const parts = [projectCard(), sourceCard()];
    if (st.source && ['validated', 'imported'].includes(st.source.state)) parts.push(analyzeCard());
    if (st.jobId) parts.push(resultsCard());
    mount(body, ...parts);
  }

  function projectCard() {
    const sel = h('select', {}, h('option', { value: '' }, '— new project —'), ...projects.map((p) => h('option', { value: p.id, selected: st.project?.id === p.id }, p.name)));
    const name = h('input', { placeholder: 'Project name', maxlength: 120 }); const err = h('div', { class: 'err-msg' });
    return h('div', { class: 'card' }, h('h2', {}, '1. Project'), st.project ? h('div', { class: 'row between' }, h('strong', {}, st.project.name), badge(st.project.status)) :
      h('div', { class: 'grid g2' }, field('Existing project', sel), h('div', {}, field('Or create new', name), err)),
      !st.project ? h('div', { class: 'row' }, h('button', { class: 'btn primary', onclick: async (e) => {
        err.textContent = ''; if (sel.value) return busy(e.target, () => loadProject(sel.value));
        const bad = validators.required(name.value); if (bad) { err.textContent = 'Enter a project name'; return; }
        await busy(e.target, async () => { const r = await api.post('/api/projects', { name: name.value }); projects.unshift(r.project); await loadProject(r.project.id); });
      } }, 'Continue')) : null);
  }

  function sourceCard() {
    if (!st.project) return null;
    const file = h('input', { type: 'file', accept: '.mp4,.mov,.webm,.mkv,.m4v,video/*' }); const prog = h('div', { hidden: true }); const err = h('div', { class: 'err-msg' });
    const url = h('input', { type: 'url', placeholder: 'https://youtu.be/… (your own channel)' }); const adapter = h('select', {}, h('option', { value: 'youtube' }, 'YouTube (own channel)'), h('option', { value: 'cloud' }, 'Google Drive'), h('option', { value: 'livestream' }, 'Live stream (planned)'));
    return h('div', { class: 'card' }, h('h2', {}, '2. Source video'),
      st.sources?.length ? h('div', { class: 'stack' }, st.sources.map((s) => h('div', { class: 'notice' }, h('div', { class: 'row between' }, h('strong', {}, s.original_filename || s.source_url || s.adapter), badge(s.state)),
        h('div', { class: 'small muted' }, s.message || ''), s.duration_s ? h('div', { class: 'small' }, `${fmtTime(s.duration_s)} · ${s.width || '?'}×${s.height || '?'} · ${s.fps || '?'} fps · ${s.has_audio ? 'audio' : 'no audio'} · ${fmtBytes(s.size_bytes)}`) : null,
        s.missing_config?.length ? h('div', { class: 'small' }, 'Needs: ' + s.missing_config.join(', ')) : null))) : null,
      h('div', { class: 'grid g2', style: 'margin-top:10px' },
        h('div', { class: 'stack' }, h('h3', {}, 'Upload a file'), file, err, prog,
          h('button', { class: 'btn primary', onclick: (e) => upload(e.target, file, prog, err) }, 'Upload'), h('p', { class: 'small muted' }, 'MP4, MOV, WebM or MKV. Stream and decoder checks run when analysis starts.')),
        h('div', { class: 'stack' }, h('h3', {}, 'Import by URL'), adapter, url,
          h('button', { class: 'btn', onclick: (e) => busy(e.target, async () => { const r = await api.post('/api/media/import', { projectId: st.project.id, adapter: adapter.value, url: url.value }); toast(`Source state: ${r.source.state}`); await loadProject(st.project.id); }) }, 'Validate URL'),
          h('p', { class: 'small muted' }, 'A URL is only validated, not downloaded. Only your own channel\u2019s videos can be authorised; otherwise upload the file.'))));
  }

  async function upload(btn, file, prog, err) {
    err.textContent = ''; const f = file.files[0]; if (!f) { err.textContent = 'Choose a video file first'; return; }
    await busy(btn, async () => {
      const init = await api.post('/api/media/upload/init', { projectId: st.project.id, filename: f.name, size: f.size, contentType: f.type || 'video/mp4' });
      prog.hidden = false; mount(prog, bar(0)); const set = (p) => mount(prog, bar(p * 100), h('div', { class: 'small muted' }, `${Math.round(p * 100)}%`));
      await uploadWithProgress(init.uploadUrl, 'PUT', f, init.headers, set);
      await api.post('/api/media/upload/complete', { sourceId: init.sourceId }); toast('Upload complete'); await loadProject(st.project.id);
    });
  }

  function analyzeCard() {
    const num = (v, a, b, s = 1) => h('input', { type: 'number', value: v, min: a, max: b, step: s });
    const minS = num(0, 0, 100), maxC = num(15, 1, 50), minD = num(15, 3, 180), maxD = num(60, 5, 180), type = h('select', {}, TYPES.map((t) => h('option', { value: t }, t || 'any')));
    const err = h('div', { class: 'err-msg' });
    return h('div', { class: 'card' }, h('h2', {}, '3. Analyse'), h('div', { class: 'grid g4' }, field('Minimum score', minS), field('Max candidates', maxC), field('Min duration (s)', minD), field('Max duration (s)', maxD), field('Preferred type', type)), err,
      h('button', { class: 'btn primary', disabled: ACTIVE.includes(st.jobs?.[0]?.status), onclick: (e) => {
        const bad = validators.range(minS.value, 0, 100) || validators.range(maxC.value, 1, 50) || validators.range(minD.value, 3, 180) || validators.range(maxD.value, 5, 180) || (Number(maxD.value) < Number(minD.value) ? 'Max duration must be at least min duration' : null);
        if (bad) { err.textContent = bad; return; } err.textContent = '';
        const config = { min_score: +minS.value, max_candidates: +maxC.value, min_duration: +minD.value, max_duration: +maxD.value }; if (type.value) config.preferred_type = type.value;
        busy(e.target, async () => { const r = await api.post('/api/analyze', { projectId: st.project.id, sourceId: st.source.id, config }); st.jobId = r.job.id; toast(r.job.submitted ? 'Analysis started' : 'Queued. It starts as soon as the processing engine responds.'); showStep(); });
      } }, 'Analyse video'));
  }

  function resultsCard() {
    const box = h('div', {}, spinner('Loading analysis…')); const card = h('div', { class: 'card' }, h('h2', {}, '4. Ranked moments'), box);
    const refresh = async () => {
      const j = (await api.get(`/api/jobs/${st.jobId}`)).job;
      if (ACTIVE.includes(j.status)) { const ev = (await api.get(`/api/jobs/${st.jobId}/events`)).events.slice(-3);
        mount(box, h('div', { class: 'stack' }, h('div', { class: 'row between' }, h('span', {}, `${j.step || 'waiting for engine'}`), badge(j.status)), bar(j.progress * 100), ev.map((e) => h('div', { class: 'small muted' }, e.message)))); return false; }
      if (j.status !== 'succeeded') { mount(box, h('div', { class: 'notice err' }, `Analysis ${j.status}: ${j.error || 'no details'}`)); return true; }
      const m = (await api.get(`/api/jobs/${st.jobId}/moments`)).moments; st.moments = m; mount(box, momentsView(m)); return true;
    };
    poll(refresh, 3000, undefined); return card;
  }

  function momentsView(moments) {
    if (!moments.length) return empty('No moments passed your filters. Lower the minimum score or widen the duration range.');
    const sel = new Set(moments.filter((m) => m.selected).map((m) => m.id)); const res = h('select', {}, h('option', { value: '1080p' }, '1080×1920'), h('option', { value: '720p' }, '720p fallback'));
    const crop = h('select', {}, h('option', { value: 'smart' }, 'Smart crop'), h('option', { value: 'center' }, 'Center crop')); const subs = h('select', {}, ['standard', 'highlight', 'none'].map((x) => h('option', { value: x }, x === 'none' ? 'No subtitles' : x + ' subtitles')));
    const toolbar = h('div', { class: 'row' }, h('button', { class: 'btn primary', onclick: (e) => busy(e.target, async () => {
        if (!sel.size) throw new Error('Select at least one moment'); const r = await api.post('/api/moments/render-batch', { ids: [...sel], settings: { resolution: res.value, crop: { mode: crop.value }, subtitles: { mode: subs.value } } });
        toast(`${r.clipIds.length} clip(s) queued`); location.hash = '#/projects/' + st.project.id; }) }, 'Render selected'),
      h('button', { class: 'btn', onclick: (e) => busy(e.target, async () => { if (sel.size < 2) throw new Error('Select two or more adjacent moments to merge'); await api.post('/api/moments/merge', { ids: [...sel] }); toast('Merged'); showStep(); }) }, 'Merge selected'), res, crop, subs);
    const player = h('video', { controls: true, preload: 'metadata', hidden: true });
    api.get(`/api/media/${st.source.id}`).then((r) => { if (r.source.previewUrl) { player.src = r.source.previewUrl; player.hidden = false; } }).catch(() => {});
    return h('div', { class: 'stack' }, toolbar, player, ...moments.map((m) => momentCard(m, sel, player)));
  }

  function momentCard(m, sel, player) {
    const s = h('input', { type: 'number', step: '0.1', value: m.start, min: 0 }), e = h('input', { type: 'number', step: '0.1', value: m.end, min: 0 });
    const cb = h('input', { type: 'checkbox', checked: sel.has(m.id), 'aria-label': 'Select moment', onchange: () => { cb.checked ? sel.add(m.id) : sel.delete(m.id); api.patch(`/api/moments/${m.id}`, { selected: cb.checked }).catch(fail); } });
    return h('div', { class: 'card moment' }, h('div', { class: 'stack' }, h('div', { class: 'score', title: 'Viral Potential Score' }, Math.round(m.score ?? 0)), cb),
      h('div', { class: 'stack' }, h('div', { class: 'row between' }, h('strong', {}, `#${m.rank} ${m.title || ''}`), h('span', {}, badge(m.type), ' ', h('span', { class: 'small muted' }, `confidence ${Math.round((m.confidence ?? 0) * 100)}%`))),
        h('div', { class: 'small muted' }, `${fmtTime(m.start)} – ${fmtTime(m.end)} (${m.duration}s)${m.edited ? ' · edited' : ''}`), h('p', { class: 'small' }, m.explanation),
        h('details', {}, h('summary', { class: 'small' }, 'Factor scores & transcript'), FACTORS.map(([k, l]) => h('div', { class: 'factor' }, l, bar(m.factors[k] ?? 0), Math.round(m.factors[k] ?? 0))), h('p', { class: 'small muted' }, m.transcript || '(no speech detected)')),
        h('div', { class: 'row' }, h('div', { style: 'width:100px' }, s), h('div', { style: 'width:100px' }, e),
          h('button', { class: 'btn sm', onclick: (ev) => busy(ev.target, async () => { const bad = Number(e.value) - Number(s.value); if (bad < 3 || bad > 180) throw new Error('Clip length must be 3–180 seconds'); await api.patch(`/api/moments/${m.id}`, { start: +s.value, end: +e.value }); toast('Timestamps saved'); }) }, 'Save times'),
          h('button', { class: 'btn sm', onclick: () => { player.currentTime = m.start; player.play().catch(() => {}); } }, 'Preview'),
          h('button', { class: 'btn sm', onclick: (ev) => busy(ev.target, async () => { const r = await api.post(`/api/moments/${m.id}/reanalyse`); st.jobId = r.job.id; toast('Re-analysing this segment'); showStep(); }) }, 'Reanalyse'),
          h('button', { class: 'btn sm primary', onclick: (ev) => busy(ev.target, async () => { const r = await api.post(`/api/moments/${m.id}/render`, {}); location.hash = '#/editor/' + r.clipId; }) }, 'Open in editor'))));
  }
};

routes.projects = async ({ args }) => {
  if (args[0]) return projectDetail(args[0]);
  const { projects } = await api.get('/api/projects');
  return h('div', {}, h('div', { class: 'row between' }, h('h1', {}, 'Video Projects'), h('a', { class: 'btn primary', href: '#/finder' }, 'New project')),
    projects.length ? h('div', { class: 'card table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Name', 'Status', 'Moments', 'Clips', 'Created'].map((x) => h('th', {}, x)))), h('tbody', {}, projects.map((p) => h('tr', {}, h('td', {}, h('a', { href: `#/projects/${p.id}` }, p.name)), h('td', {}, badge(p.status)), h('td', {}, p.moments), h('td', {}, p.clips), h('td', {}, fmtDate(p.created_at))))))) : empty('No projects yet.'));
};

async function projectDetail(id) {
  const d = await api.get(`/api/projects/${id}`);
  return h('div', {}, h('div', { class: 'row between' }, h('h1', {}, d.project.name), h('div', { class: 'row' }, h('a', { class: 'btn', href: `#/finder?project=${id}` }, 'Open in Viral Finder'),
      h('button', { class: 'btn danger', onclick: () => modal('Delete project?', h('p', {}, 'This permanently deletes the project, its source video, moments and rendered clips. Scheduled posts must be cancelled first.'), [{ label: 'Delete', kind: 'danger', run: async () => { await api.del(`/api/projects/${id}`); toast('Project deleted'); location.hash = '#/projects'; } }]) }, 'Delete'))),
    h('div', { class: 'card' }, h('h2', {}, 'Sources'), d.sources.length ? d.sources.map((s) => h('div', { class: 'row between' }, h('span', {}, s.original_filename || s.source_url), badge(s.state))) : empty('No sources.')),
    h('div', { class: 'card' }, h('h2', {}, 'Analysis jobs'), d.jobs.length ? d.jobs.map((j) => h('div', { class: 'row between' }, h('span', {}, fmtDate(j.created_at)), h('span', {}, badge(j.status), j.error ? h('span', { class: 'small muted' }, ' ' + j.error) : null))) : empty('Not analysed yet.')),
    h('div', { class: 'card' }, h('h2', {}, 'Clips'), d.clips.length ? d.clips.map((c) => h('div', { class: 'row between' }, h('a', { href: `#/editor/${c.id}` }, c.title || 'Untitled'), h('span', {}, c.status === 'rendering' ? `${Math.round(c.progress * 100)}% ` : '', badge(c.status)))) : empty('No clips rendered yet.')));
}
