import { h, mount, api, badge, field, fail, toast, busy, fmtDate, fmtNum, empty, routes, modal, validators } from '../core.js';

routes.accounts = async ({ query }) => {
  const { accounts } = await api.get('/api/social/accounts');
  const msg = query.connected ? h('div', { class: 'notice' }, `${query.connected} connected.`) : query.error ? h('div', { class: 'notice err', role: 'alert' }, `Connection failed: ${query.error}`) : null;
  return h('div', {}, h('h1', {}, 'Social Accounts'), h('p', { class: 'muted' }, 'One account per platform. Connections use each platform\u2019s official OAuth flow with the minimum scopes needed.'), msg,
    h('div', { class: 'grid g2' }, accounts.map((a) => h('div', { class: 'card' }, h('div', { class: 'row between' }, h('h2', {}, a.label), badge(a.status)),
      a.account ? h('div', { class: 'stack' }, h('div', {}, h('strong', {}, a.account.displayName), ' ', h('span', { class: 'muted' }, a.account.handle || '')), h('div', { class: 'small muted' }, `Connected ${fmtDate(a.account.connectedAt)}`),
        h('div', { class: 'small' }, 'Granted permissions: ', a.account.grantedScopes.length ? a.account.grantedScopes.join(', ') : 'none recorded'), a.account.lastError ? h('div', { class: 'notice err' }, a.account.lastError) : null) : null,
      a.status === 'pending_configuration' ? h('div', { class: 'notice warn' }, h('strong', {}, 'Pending configuration. '), `This deployment is missing ${a.missingConfig.join(', ')}. Follow ${a.setupGuide}. Redirect URI to register: `, h('span', { class: 'mono' }, a.redirectUri)) : null,
      h('p', { class: 'small muted' }, a.notes), h('p', { class: 'small' }, 'Capabilities: ' + a.capabilities.join(', ')),
      h('div', { class: 'row' }, a.status === 'pending_configuration' ? null : (a.account && a.status !== 'disconnected') ?
        h('button', { class: 'btn danger', onclick: () => disconnect(a) }, 'Disconnect') : null,
        a.status !== 'pending_configuration' && (!a.account || ['expired', 'error', 'revoked'].includes(a.status)) ? h('a', { class: 'btn primary', href: `/api/social/${a.platform}/connect` }, a.account ? 'Reconnect' : 'Connect') : null)))));
};

function disconnect(a) {
  modal(`Disconnect ${a.label}?`, h('p', {}, 'Stored tokens are deleted. Scheduled posts for this account will be cancelled. Already-published posts and their analytics are kept.'), [{ label: 'Disconnect', kind: 'danger', run: async () => {
    try { await api.del(`/api/social/${a.platform}/disconnect`); } catch (e) { if (e.status === 409) { await api.del(`/api/social/${a.platform}/disconnect?cancelPending=1`); } else throw e; }
    toast('Disconnected'); location.reload(); } }]);
}

const dayKey = (d) => d.toISOString().slice(0, 10);
routes.calendar = async () => {
  const state = { view: 'list', month: new Date() }; const root = h('div', {}); const body = h('div', {});
  const load = async () => {
    const [jobs, sch] = await Promise.all([api.get('/api/publishing/jobs'), api.get('/api/publishing/schedules')]);
    const from = Math.floor(new Date(state.month.getFullYear(), state.month.getMonth(), 1).getTime() / 1000) - 86400, to = from + 33 * 86400;
    const cal = await api.get(`/api/publishing/calendar?from=${from}&to=${to}`); draw(jobs, sch.schedules, cal);
  };
  function draw(data, schedules, cal) {
    const tabs = h('div', { class: 'tabs' }, ['list', 'calendar', 'schedules'].map((v) => h('button', { class: state.view === v ? 'active' : '', onclick: () => { state.view = v; draw(data, schedules, cal); } }, v === 'list' ? 'List' : v === 'calendar' ? 'Calendar' : 'Recurring schedules')));
    const pause = h('button', { class: 'btn' + (data.queuePaused ? ' primary' : ''), onclick: (e) => busy(e.target, async () => { await api.patch('/api/publishing/queue', { paused: !data.queuePaused }); await load(); }) }, data.queuePaused ? 'Resume queue' : 'Pause queue');
    mount(body, h('div', { class: 'row between' }, h('h1', {}, 'Publishing Calendar'), pause), data.queuePaused ? h('div', { class: 'notice warn' }, 'The queue is paused. Nothing will publish until you resume it.') : null, tabs,
      state.view === 'list' ? listView(data.jobs, cal.timezone) : state.view === 'calendar' ? gridView(cal) : scheduleView(schedules));
  }
  const listView = (jobs, tz) => jobs.length ? h('div', { class: 'card table-wrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Clip', 'Platform', 'When', 'Status', ''].map((x) => h('th', {}, x)))),
    h('tbody', {}, jobs.map((j) => h('tr', {}, h('td', {}, j.clipTitle), h('td', {}, j.platform), h('td', {}, fmtDate(j.runAt, tz)), h('td', {}, badge(j.status), j.error ? h('div', { class: 'small muted' }, j.error) : null, j.postUrl ? h('div', {}, h('a', { href: j.postUrl, target: '_blank', rel: 'noopener noreferrer' }, 'Open post')) : null), h('td', {}, actions(j, tz))))))) : empty('Nothing here yet. Approve a clip from the Shorts Editor.');
  function actions(j, tz) {
    const b = (t, fn, cls = '') => h('button', { class: 'btn sm ' + cls, onclick: (e) => busy(e.target, async () => { await fn(); await load(); }) }, t);
    const out = [h('button', { class: 'btn sm', onclick: () => logs(j) }, 'Logs')];
    if (['scheduled', 'approved', 'failed'].includes(j.status)) out.push(b('Reschedule', async () => new Promise((res) => { const t = h('input', { type: 'datetime-local' }); modal('Reschedule', field('New time', t), [{ label: 'Save', run: async () => { if (!t.value) throw new Error('Choose a time'); await api.patch(`/api/publishing/jobs/${j.id}`, { action: 'reschedule', localTime: t.value }); res(); await load(); } }]); })));
    if (j.status === 'failed') out.push(b('Retry', () => api.patch(`/api/publishing/jobs/${j.id}`, { action: 'retry' })));
    if (j.status === 'needs_verification') out.push(b('It was not posted: retry', () => api.patch(`/api/publishing/jobs/${j.id}`, { action: 'retry' }), 'danger'));
    if (['scheduled', 'approved', 'failed', 'needs_verification'].includes(j.status)) out.push(b('Cancel', () => api.del(`/api/publishing/jobs/${j.id}`), 'danger'));
    return h('div', { class: 'row' }, out);
  }
  async function logs(j) { const d = await api.get(`/api/publishing/jobs/${j.id}`); modal('Publishing log', h('div', { class: 'stack small' }, d.logs.length ? d.logs.map((l) => h('div', { class: 'mono' }, `${fmtDate(l.ts)} [${l.level}] ${l.message}${l.http_status ? ' (HTTP ' + l.http_status + ')' : ''}`)) : h('p', { class: 'muted' }, 'No log entries yet.'))); }
  function gridView(cal) {
    const y = state.month.getFullYear(), m = state.month.getMonth(); const first = new Date(Date.UTC(y, m, 1)); const lead = (first.getUTCDay() + 6) % 7; const days = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
    const cells = []; for (let i = 0; i < lead; i++) cells.push(h('div', { class: 'd off' }));
    for (let d = 1; d <= days; d++) { const key = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`; const ev = cal.days[key] || [];
      cells.push(h('div', { class: 'd' }, h('strong', {}, d), ...ev.slice(0, 3).map((e) => h('span', { class: 'ev', title: `${e.clipTitle} · ${e.status}` }, `${e.localTime} ${e.platform}`)), ev.length > 3 ? h('span', { class: 'small muted' }, `+${ev.length - 3} more`) : null)); }
    return h('div', { class: 'card' }, h('div', { class: 'row between' }, h('button', { class: 'btn sm', onclick: () => { state.month = new Date(y, m - 1, 1); load(); } }, '‹'), h('strong', {}, first.toLocaleString('en', { month: 'long', year: 'numeric', timeZone: 'UTC' }) + ` (${cal.timezone})`), h('button', { class: 'btn sm', onclick: () => { state.month = new Date(y, m + 1, 1); load(); } }, '›')),
      h('div', { class: 'cal', style: 'margin-top:10px' }, ...['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((x) => h('div', { class: 'h' }, x)), ...cells));
  }
  function scheduleView(schedules) {
    const pl = h('select', {}, ['youtube', 'instagram', 'facebook', 'tiktok', 'x'].map((p) => h('option', { value: p }, p))); const kind = h('select', {}, ['daily', 'weekly', 'custom'].map((k) => h('option', { value: k }, k))); const times = h('input', { placeholder: '09:00, 18:30' });
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d, i) => h('label', { class: 'row' }, h('input', { type: 'checkbox', value: i + 1 }), d)); const err = h('div', { class: 'err-msg' });
    return h('div', {}, h('div', { class: 'card' }, h('h2', {}, 'Add a recurring schedule'), h('p', { class: 'small muted' }, 'Used when you pick “next free slot”. Times are in your Settings timezone (Asia/Kolkata by default).'),
      h('div', { class: 'grid g3' }, field('Platform', pl), field('Type', kind), field('Times (HH:MM, comma separated)', times)), h('div', { class: 'row' }, 'Weekdays (weekly only):', ...days), err,
      h('button', { class: 'btn primary', onclick: (e) => { const t = times.value.split(/[\s,]+/).filter(Boolean); if (!t.length || t.some((x) => !/^([01]\d|2[0-3]):[0-5]\d$/.test(x))) { err.textContent = 'Use 24-hour HH:MM times'; return; } err.textContent = '';
        const wd = days.map((d) => d.firstChild).filter((c) => c.checked).map((c) => +c.value); if (kind.value === 'weekly' && !wd.length) { err.textContent = 'Pick at least one weekday'; return; }
        busy(e.target, async () => { await api.post('/api/publishing/schedules', { platform: pl.value, kind: kind.value, times: t, ...(kind.value === 'weekly' ? { weekdays: wd } : {}) }); toast('Schedule added'); await load(); }); } }, 'Add schedule')),
      schedules.length ? h('div', { class: 'card' }, schedules.map((s) => h('div', { class: 'row between' }, h('span', {}, `${s.platform} · ${s.kind} · ${s.times.join(', ')}`, h('span', { class: 'small muted' }, ` next: ${s.next.map((n) => fmtDate(n, s.timezone)).join(' | ')}`)),
        h('button', { class: 'btn sm danger', onclick: (e) => busy(e.target, async () => { await api.del(`/api/publishing/schedules/${s.id}`); await load(); }) }, 'Remove')))) : null);
  }
  mount(root, body); await load(); return root;
};
