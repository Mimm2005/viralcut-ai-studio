import { h, api, bar, badge, fmtBytes, fmtDate, empty, routes, poll } from '../core.js';

routes.dashboard = async ({ signal }) => {
  const d = await api.get('/api/dashboard');
  const stat = (n, l) => h('div', { class: 'card' }, h('div', { class: 'stat' }, n), h('div', { class: 'stat-label' }, l));
  const link = (href, t) => h('a', { href }, t);
  const st = d.storage;
  return h('div', {}, h('h1', {}, 'Dashboard'),
    h('div', { class: 'grid g4' }, stat(d.counts.projects, 'Projects'), stat(d.counts.clips, 'Rendered clips'), stat(d.counts.scheduled, 'Scheduled posts'), stat(d.counts.posts, 'Published posts')),
    h('div', { class: 'grid g2' },
      h('div', { class: 'card' }, h('h2', {}, 'Processing queue'), d.queue.length ? d.queue.map((j) => h('div', { class: 'stack', style: 'margin-bottom:8px' }, h('div', { class: 'row between' }, h('span', {}, `${j.kind} · ${j.step || 'waiting'}`), badge(j.status)), bar(j.progress * 100))) : empty('Nothing is processing.')),
      h('div', { class: 'card' }, h('h2', {}, 'Storage'), h('p', {}, `${fmtBytes(st.usedBytes)} of ${fmtBytes(st.quotaBytes)} (${st.percent}%)`), bar(st.percent, st.percent > 90 ? 'err' : ''),
        h('p', { class: 'small muted' }, `Sources ${fmtBytes(st.sourceBytes)} · Clips ${fmtBytes(st.clipBytes)}`))),
    h('div', { class: 'grid g2' },
      h('div', { class: 'card' }, h('h2', {}, 'Recent projects'), d.recentProjects.length ? d.recentProjects.map((p) => h('div', { class: 'row between' }, link(`#/projects/${p.id}`, p.name), badge(p.status))) : empty('No projects yet. Start in Viral Finder.')),
      h('div', { class: 'card' }, h('h2', {}, 'Recent clips'), d.recentClips.length ? d.recentClips.map((c) => h('div', { class: 'row between' }, link(`#/editor/${c.id}`, c.title || 'Untitled clip'), badge(c.status))) : empty('No clips yet.'))),
    h('div', { class: 'grid g2' },
      h('div', { class: 'card' }, h('h2', {}, 'Recent publishing activity'), d.recentPublishing.length ? d.recentPublishing.map((j) => h('div', { class: 'row between' }, h('span', {}, `${j.platform} · ${fmtDate(j.run_at)}`), badge(j.status))) : empty('Nothing scheduled or published yet.')),
      h('div', { class: 'card' }, h('h2', {}, 'AI usage this month'), d.ai.length ? d.ai.map((p) => h('div', { class: 'row between' }, h('span', {}, `${p.label} (${p.model})`), h('span', { class: 'small muted' }, `${p.usage.calls} calls · ${p.usage.tokensIn + p.usage.tokensOut} tokens`))) :
        h('div', {}, empty('No AI provider configured. Metadata generation stays off until you add one.'), h('a', { href: '#/providers' }, 'Add a provider')))));
};
