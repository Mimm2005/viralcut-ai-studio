// Core helpers: safe DOM builder, API client, toasts, modal, formatting, icons, router.
const SVG = 'http://www.w3.org/2000/svg';

export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'value') el.value = v;
    else if (k === 'checked' || k === 'disabled' || k === 'hidden' || k === 'selected') el[k] = !!v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  add(el, kids);
  return el;
}
function add(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k === null || k === undefined || k === false) continue;
    el.append(k instanceof Node ? k : document.createTextNode(String(k)));   // text nodes only: no HTML injection
  }
}
export const clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };
export const mount = (el, ...kids) => { clear(el); add(el, kids); return el; };

// Lucide-style 24x24 stroke icons (ISC-licensed shapes), inlined so the app has no CDN dependency.
const ICONS = {
  home: 'M3 10.5 12 3l9 7.5V21H3z|M9 21v-7h6v7', search: 'M21 21l-4.3-4.3|M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z', folder: 'M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
  tag: 'M3 3h8l10 10-8 8L3 11z|M7.5 7.5h.01', scissors: 'M6 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6z|M6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6z|M20 4 8.1 15.9|M14.5 14.5 20 20|M8.1 8.1 12 12', link: 'M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7|M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7',
  calendar: 'M8 2v4|M16 2v4|M3 6h18v15H3z|M3 10h18', chart: 'M3 3v18h18|M7 15l4-4 3 3 5-6', cpu: 'M6 6h12v12H6z|M9 2v4|M15 2v4|M9 18v4|M15 18v4|M2 9h4|M2 15h4|M18 9h4|M18 15h4', settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z|M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
  menu: 'M3 6h18|M3 12h18|M3 18h18', bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9|M13.7 21a2 2 0 0 1-3.4 0', sun: 'M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10z|M12 1v2|M12 21v2|M4.2 4.2l1.4 1.4|M18.4 18.4l1.4 1.4|M1 12h2|M21 12h2|M4.2 19.8l1.4-1.4|M18.4 5.6l1.4-1.4', upload: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4|M17 8l-5-5-5 5|M12 3v12',
};
export function icon(name, size = 18) {
  const s = document.createElementNS(SVG, 'svg');
  for (const [k, v] of Object.entries({ width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', 'stroke-width': 2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true' })) s.setAttribute(k, v);
  for (const d of (ICONS[name] || '').split('|')) { const p = document.createElementNS(SVG, 'path'); p.setAttribute('d', d); s.append(p); }
  return s;
}

// ---- API ------------------------------------------------------------------------------------------
export const session = { user: null, csrf: '' };
export class ApiError extends Error { constructor(status, message, details) { super(message); this.status = status; this.details = details; } }

export async function api(method, path, body) {
  const headers = {};
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (session.csrf) headers['x-csrf-token'] = session.csrf;
  let res;
  try { res = await fetch(path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), credentials: 'same-origin' }); }
  catch { throw new ApiError(0, 'Network error. Check your connection and try again.'); }
  let data = null; const text = await res.text(); try { data = text ? JSON.parse(text) : null; } catch { data = null; }
  if (data?.csrfToken) session.csrf = data.csrfToken;
  if (!res.ok) throw new ApiError(res.status, data?.error || `Request failed (${res.status})`, data?.details);
  return data;
}
api.get = (p) => api('GET', p); api.post = (p, b = {}) => api('POST', p, b); api.patch = (p, b) => api('PATCH', p, b); api.del = (p) => api('DELETE', p);

export function errText(e) {
  if (!(e instanceof ApiError)) return e?.message || 'Something went wrong';
  if (Array.isArray(e.details)) return `${e.message}: ${e.details.join(' | ')}`;
  if (e.details && typeof e.details === 'object') return `${e.message}: ${Object.entries(e.details).map(([k, v]) => `${k} ${v}`).join(', ')}`;
  return e.message;
}

// ---- UI helpers --------------------------------------------------------------------------------------
export function toast(msg, kind = '') {
  const t = h('div', { class: 'toast ' + kind, role: kind === 'err' ? 'alert' : 'status' }, msg);
  document.getElementById('toasts').append(t); setTimeout(() => t.remove(), kind === 'err' ? 7000 : 3500);
}
export const fail = (e) => { toast(errText(e), 'err'); };

export function modal(title, body, actions = []) {
  const root = document.getElementById('modal-root');
  const close = () => { clear(root); document.removeEventListener('keydown', esc); };
  const esc = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', esc);
  const bg = h('div', { class: 'modal-bg', onclick: (e) => { if (e.target === bg) close(); } },
    h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, h('h2', {}, title), body, h('div', { class: 'row', style: 'justify-content:flex-end;margin-top:14px' },
      h('button', { class: 'btn', onclick: close }, 'Close'), ...actions.map((a) => h('button', { class: 'btn ' + (a.kind || 'primary'), onclick: async () => { try { if ((await a.run()) !== false) close(); } catch (e) { fail(e); } } }, a.label)))));
  clear(root).append(bg);
  return { close };
}
export function confirmBox(title, text, label = 'Confirm', kind = 'danger') {
  return new Promise((res) => { const m = modal(title, h('p', {}, text), [{ label, kind, run: () => { res(true); } }]); document.querySelector('.modal-bg .btn:not(.primary):not(.danger)')?.addEventListener('click', () => res(false)); });
}

export const fmtTime = (s) => { s = Math.max(0, Number(s) || 0); const m = Math.floor(s / 60), r = (s % 60).toFixed(1).padStart(4, '0'); return `${m}:${r}`; };
export const fmtBytes = (n) => (n == null ? '—' : n < 1024 ** 2 ? `${(n / 1024).toFixed(0)} KB` : n < 1024 ** 3 ? `${(n / 1024 ** 2).toFixed(1)} MB` : `${(n / 1024 ** 3).toFixed(2)} GB`);
export const fmtNum = (n) => (n == null ? '—' : Number(n).toLocaleString('en-IN'));
export const fmtDate = (epoch, tz) => (epoch ? new Date(epoch * 1000).toLocaleString('en-IN', { timeZone: tz || 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' }) : '—');
export const statusKind = (s) => (['ready', 'published', 'connected', 'succeeded', 'ok', 'imported', 'authorized', 'analyzed'].includes(s) ? 'ok' : ['failed', 'error', 'expired', 'rejected', 'revoked', 'needs_verification'].includes(s) ? 'err' : ['pending_configuration', 'unsupported', 'queued', 'running', 'rendering', 'publishing', 'scheduled', 'validated', 'untested', 'pending_approval', 'approved'].includes(s) ? 'warn' : '');
export const badge = (s) => h('span', { class: 'badge ' + statusKind(s) }, String(s).replace(/_/g, ' '));
export const bar = (pct, kind = '') => h('div', { class: 'bar ' + kind, role: 'progressbar', 'aria-valuenow': Math.round(pct), 'aria-valuemin': 0, 'aria-valuemax': 100 }, h('i', { style: `width:${Math.max(0, Math.min(100, pct))}%` }));
export const spinner = (t = 'Loading…') => h('div', { class: 'row muted', role: 'status' }, h('span', { class: 'spinner' }), t);
export const empty = (t) => h('div', { class: 'empty' }, t);
export const errorBox = (e, retry) => h('div', { class: 'notice err', role: 'alert' }, errText(e), retry ? h('button', { class: 'btn sm', style: 'margin-left:8px', onclick: retry }, 'Retry') : null);

export function field(label, input, { hint, error } = {}) {
  return h('div', { class: 'field' }, h('label', {}, label), input, hint ? h('div', { class: 'small muted' }, hint) : null, error ? h('div', { class: 'err-msg' }, error) : null);
}
export function counted(label, el, max) {
  const c = h('div', { class: 'count' });
  const upd = () => { const n = el.value.length; c.textContent = `${n}/${max}`; c.className = 'count' + (n > max ? ' over' : ''); };
  el.addEventListener('input', upd); upd();
  return h('div', { class: 'field' }, h('label', {}, label), el, c);
}
export async function busy(btn, fn) {
  const old = btn.textContent; btn.disabled = true; btn.textContent = 'Working…';
  try { return await fn(); } catch (e) { fail(e); } finally { btn.disabled = false; btn.textContent = old; }
}
export function poll(fn, ms, signal) {            // stops when fn returns true or the view changes
  let stop = false; const run = async () => { while (!stop && !signal?.aborted) { try { if (await fn()) return; } catch { /* keep polling */ } await new Promise((r) => setTimeout(r, ms)); } };
  run(); return () => { stop = true; };
}

// ---- validation ------------------------------------------------------------------------------------------
export const validators = {
  email: (v) => (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v) ? null : 'Enter a valid email address'),
  password: (v) => (v.length >= 12 ? null : 'Use at least 12 characters'),
  range: (v, lo, hi) => { const n = Number(v); return Number.isFinite(n) && n >= lo && n <= hi ? null : `Enter a number between ${lo} and ${hi}`; },
  required: (v) => (String(v).trim() ? null : 'Required'),
};

// ---- router ------------------------------------------------------------------------------------------------
export const routes = {};
let current = null;
export function parseHash(hash = location.hash) { const [p, q = ''] = hash.replace(/^#\/?/, '').split('?'); const [name, ...rest] = p.split('/'); return { name: name || 'dashboard', args: rest, query: Object.fromEntries(new URLSearchParams(q)) }; }
export async function render() {
  const view = document.getElementById('view'); const { name, args, query } = parseHash();
  const page = routes[name] || routes.dashboard;
  current?.abort?.(); const ctl = new AbortController(); current = ctl;
  document.querySelectorAll('#sidebar a').forEach((a) => a.classList.toggle('active', a.dataset.route === (routes[name] ? name : 'dashboard')));
  mount(view, spinner());
  try { const out = await page({ args, query, signal: ctl.signal, view }); if (!ctl.signal.aborted) { if (out) mount(view, out); view.focus({ preventScroll: true }); } }
  catch (e) { if (!ctl.signal.aborted) mount(view, errorBox(e, render)); if (e.status === 401) location.reload(); }
}
