import test from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { readFileSync } from 'node:fs';

const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../css/app.css', import.meta.url), 'utf8');
const wait = (ms = 20) => new Promise((r) => setTimeout(r, ms));
const until = async (fn, n = 60) => { for (let i = 0; i < n; i++) { if (fn()) return true; await wait(10); } return false; };

/** Fresh DOM + scripted API. `routes` maps "METHOD /path" (prefix match, query ignored) to a value or fn(body). */
let prevWindow = null;
function setup(routesMap = {}, { narrow = false } = {}) {
  prevWindow?.close();            // stop the previous test's pending events from touching this DOM
  const dom = new JSDOM(html, { url: 'https://app.test/', pretendToBeVisual: true, runScripts: 'outside-only' });
  const w = dom.window; prevWindow = w; w.__VC_TEST__ = true; w.matchMedia = (q) => ({ matches: narrow && /max-width/.test(q), addEventListener() {}, removeEventListener() {} });
  Object.assign(globalThis, { window: w, document: w.document, location: w.location, Node: w.Node, Event: w.Event, localStorage: w.localStorage, matchMedia: w.matchMedia, addEventListener: w.addEventListener.bind(w), setInterval: () => 0 });
  Object.defineProperty(globalThis, 'navigator', { value: w.navigator, configurable: true });
  const calls = [];
  globalThis.fetch = async (url, init = {}) => {
    const path = String(url).split('?')[0]; const key = `${init.method || 'GET'} ${path}`; calls.push({ key, body: init.body ? JSON.parse(init.body) : undefined, headers: init.headers });
    const hit = Object.keys(routesMap).sort((a, b) => b.length - a.length).find((k) => key === k || key.startsWith(k + '/'));
    let out = hit ? routesMap[hit] : { __status: 404, error: 'unscripted ' + key }; if (typeof out === 'function') out = await out(init.body ? JSON.parse(init.body) : undefined);
    const status = out?.__status || 200; return { ok: status < 400, status, text: async () => JSON.stringify(out), json: async () => out };
  };
  return { w, calls, view: () => w.document.getElementById('view') };
}
const core = await import('../js/core.js');
const main = await import('../js/main.js');
const { h } = core;

const USER = { user: { id: 'u', email: 'a@b.co', displayName: 'Owner', role: 'owner' }, csrfToken: 'csrf1' };
const FIX = {
  'GET /api/auth/me': USER, 'GET /api/notifications': { notifications: [{ id: 'n', title: 'Clip rendered', body: 'x', created_at: 1, link: '#/editor/c', read: false }], unread: 1 },
  'GET /api/dashboard': { counts: { projects: 2, clips: 3, scheduled: 1, posts: 0 }, recentProjects: [{ id: 'p1', name: 'Alpha', status: 'analyzed' }], queue: [], recentClips: [], recentPublishing: [], storage: { usedBytes: 5e6, quotaBytes: 9e9, percent: 0.1, sourceBytes: 4e6, clipBytes: 1e6 }, ai: [] },
  'GET /api/projects': { projects: [{ id: 'p1', name: 'Alpha', status: 'analyzed', moments: 5, clips: 2, created_at: 1700000000 }] }, 'GET /api/clips': { clips: [{ id: 'c1', title: 'Clip one', status: 'ready' }] },
  'GET /api/social/accounts': { accounts: [
    { platform: 'youtube', label: 'YouTube', status: 'connected', missingConfig: [], setupGuide: 'docs/YOUTUBE_INTEGRATION.md', capabilities: ['publish'], notes: 'n', redirectUri: 'https://app.test/api/social/youtube/callback', account: { displayName: 'My Channel', handle: '@me', grantedScopes: ['youtube.upload'], connectedAt: 1700000000 } },
    { platform: 'tiktok', label: 'TikTok', status: 'pending_configuration', missingConfig: ['TIKTOK_CLIENT_KEY'], setupGuide: 'docs/TIKTOK_INTEGRATION.md', capabilities: ['publish'], notes: 'audit', redirectUri: 'https://app.test/api/social/tiktok/callback', account: null }] },
  'GET /api/publishing/jobs': { jobs: [], queuePaused: false }, 'GET /api/publishing/schedules': { schedules: [] }, 'GET /api/publishing/calendar': { timezone: 'Asia/Kolkata', days: {} },
  'GET /api/analytics/overview': { range: {}, posts: 2, totals: { views: 1500, likes: null, comments: 3, shares: null, reach: null, impressions: null, saves: null, avgViewPercentage: null }, postsWithMetric: { views: 2, likes: 0, comments: 1 }, bestClips: [], bestMetadata: [], note: null },
  'GET /api/analytics/posts': { posts: [] }, 'GET /api/analytics/platforms': { platforms: [] }, 'GET /api/analytics/insights': { caveat: 'correlations only', postsWithMetric: 0, sections: {}, scoreCalibration: { n: 0, correlation: null, note: 'Need at least 10' }, message: 'Only 0 posts have metrics; at least 20 are needed' },
  'GET /api/ai/providers': { providers: [], tasks: ['metadata', 'reasoning', 'alternatives', 'explanation', 'test'] }, 'GET /api/costguard': { providers: [], storage: { usedBytes: 0, quotaBytes: 1e9 }, engine: { configured: false }, freeTierNotice: 'quotas apply' },
  'GET /api/settings': { settings: { timezone: 'Asia/Kolkata', language: 'en', defaultResolution: '1080p', defaultPrivacy: 'private', retentionDays: 30, storageQuotaMb: 9000, notifications: {} }, profile: USER.user },
  'GET /api/metadata': { metadata: [], specs: { youtube: { title: 100, description: 5000, hashtags: 15, privacy: ['private', 'unlisted', 'public'] }, instagram: { caption: 2200, hashtags: 30, privacy: [] }, facebook: { caption: 2200, hashtags: 30, privacy: [] }, tiktok: { caption: 2200, hashtags: 30, privacy: ['SELF_ONLY'] }, x: { caption: 280, hashtags: 3, privacy: [] } } },
  'GET /api/clips/c1': { clip: { id: 'c1', title: 'Clip one', status: 'ready', start_s: 5, end_s: 25, width: 1080, height: 1920, duration_s: 20, previewUrl: '/api/media/file?x', downloadUrl: '/api/media/file?y', settings: {} } },
};
async function bootAt(hash, extra = {}, opts) { const env = setup({ ...FIX, ...extra }, opts); env.w.history.replaceState(null, '', '/' + hash); await main.boot(); await until(() => !env.view().querySelector('.spinner')); return env; }

test('rendering is XSS-safe: untrusted strings become text, never markup', () => {
  setup(); const evil = '<img src=x onerror=alert(1)><script>alert(2)</script>';
  const el = h('div', { title: '" onmouseover="alert(3)' }, evil, h('b', {}, evil));
  assert.equal(el.querySelector('img'), null); assert.equal(el.querySelector('script'), null); assert.ok(el.textContent.includes('<img src=x')); assert.equal(el.getAttribute('onmouseover'), null);
  assert.equal(h('span', {}, 0, null, false, undefined, 'x').textContent, '0x');
});

test('validators and hash parsing', () => {
  const v = core.validators; assert.equal(v.email('a@b.co'), null); assert.ok(v.email('nope')); assert.ok(v.password('short')); assert.equal(v.password('a'.repeat(12)), null); assert.ok(v.range('abc', 0, 5)); assert.ok(v.range('9', 0, 5)); assert.equal(v.range('3', 0, 5), null); assert.ok(v.required('  '));
  assert.deepEqual(core.parseHash('#/editor/c1?x=1'), { name: 'editor', args: ['c1'], query: { x: '1' } }); assert.equal(core.parseHash('').name, 'dashboard');
  assert.equal(core.fmtTime(75.25), '1:15.3'); assert.equal(core.fmtBytes(5 * 1024 ** 2), '5.0 MB'); assert.equal(core.fmtNum(null), '—');
});

test('navigation: all ten sections exist, in order, and every page renders without error', async () => {
  const env = await bootAt('#/dashboard'); const links = [...env.w.document.querySelectorAll('#sidebar a')];
  assert.deepEqual(links.map((a) => a.dataset.route), ['dashboard', 'finder', 'projects', 'metadata', 'editor', 'accounts', 'calendar', 'analytics', 'providers', 'settings']);
  assert.equal(links.length, 10); assert.ok(env.w.document.querySelector('#view h1').textContent.includes('Dashboard'));
  for (const [route, title] of [['finder', 'Viral Finder'], ['projects', 'Video Projects'], ['metadata', 'AI Metadata'], ['editor', 'Shorts Editor'], ['accounts', 'Social Accounts'], ['calendar', 'Publishing Calendar'], ['analytics', 'Social Analytics'], ['providers', 'AI Providers'], ['settings', 'Settings']]) {
    env.w.location.hash = '#/' + route; await until(() => env.view().querySelector('h1')?.textContent.includes(title));
    assert.ok(env.view().querySelector('h1')?.textContent.includes(title), `${route} should render "${title}"`); assert.equal(env.view().querySelector('.notice.err'), null, `${route} rendered an error`);
    assert.ok(env.w.document.querySelector(`#sidebar a[data-route="${route}"]`).classList.contains('active'));
  }
});

test('loading state shows first; API failure shows an error box with working Retry', async () => {
  let fail = true; const env = setup({ ...FIX, 'GET /api/dashboard': () => (fail ? { __status: 500, error: 'boom' } : FIX['GET /api/dashboard']) }); await main.boot();
  await until(() => env.view().querySelector('.notice.err')); assert.match(env.view().querySelector('.notice.err').textContent, /boom/);
  fail = false; env.view().querySelector('.notice.err button').click(); await until(() => env.view().querySelector('h1')); assert.ok(env.view().textContent.includes('Dashboard'));
  const slow = setup({ ...FIX, 'GET /api/dashboard': () => new Promise(() => {}) }); const p = main.boot(); await wait(30); assert.ok(slow.view().querySelector('.spinner') && slow.view().querySelector('[role=status]'));
});

test('login / first-run setup: validation blocks bad input before any request; errors are shown', async () => {
  let env = setup({ 'GET /api/auth/me': { __status: 401, user: null, setupRequired: true }, 'POST /api/auth/setup': {}, 'POST /api/auth/login': { __status: 401, error: 'Invalid email or password' } }); await main.boot();
  const auth = env.w.document.getElementById('auth'); assert.equal(auth.hidden, false); assert.equal(env.w.document.getElementById('app').hidden, true);
  assert.match(auth.textContent, /Create the owner account/); assert.ok(auth.querySelector('input[type=password][autocomplete=off]'));          // setup-token field
  const [email, pw, tok] = auth.querySelectorAll('input'); const btn = auth.querySelector('.btn.primary'); const err = auth.querySelector('.err-msg');
  email.value = 'bad'; btn.click(); assert.match(err.textContent, /valid email/); pw.value = 'short'; email.value = 'a@b.co'; btn.click(); assert.match(err.textContent, /12 characters/);
  pw.value = 'long enough password'; btn.click(); assert.match(err.textContent, /setup token/i); assert.equal(env.calls.filter((c) => c.key.startsWith('POST')).length, 0);
  tok.value = 'tok'; btn.click(); await until(() => env.calls.some((c) => c.key === 'POST /api/auth/login'));
  assert.deepEqual(env.calls.find((c) => c.key === 'POST /api/auth/setup').body, { email: 'a@b.co', password: 'long enough password', setupToken: 'tok' });
  await until(() => /Invalid email/.test(err.textContent)); assert.match(err.textContent, /Invalid email or password/);
  env = setup({ 'GET /api/auth/me': { __status: 401, user: null, setupRequired: false } }); await main.boot(); assert.match(env.w.document.getElementById('auth').textContent, /Sign in/); assert.equal(env.w.document.querySelectorAll('#auth input').length, 2);   // no token field, no registration
});

test('modal: dialog semantics, Escape and backdrop close, action runs and reports errors', async () => {
  const env = setup(); const root = env.w.document.getElementById('modal-root'); let ran = 0;
  core.modal('Delete?', h('p', {}, 'sure'), [{ label: 'Do it', kind: 'danger', run: async () => { ran++; } }]);
  const dlg = root.querySelector('[role=dialog]'); assert.equal(dlg.getAttribute('aria-modal'), 'true'); assert.equal(dlg.getAttribute('aria-label'), 'Delete?');
  env.w.document.dispatchEvent(new env.w.KeyboardEvent('keydown', { key: 'Escape' })); assert.equal(root.children.length, 0);
  core.modal('A', h('p', {}, 'b')); root.querySelector('.modal-bg').dispatchEvent(new env.w.MouseEvent('click', { bubbles: true })); assert.equal(root.children.length, 0);
  core.modal('B', h('p', {}, 'b'), [{ label: 'Go', run: async () => { ran++; } }]); [...root.querySelectorAll('button')].find((b) => b.textContent === 'Go').click(); await wait(); assert.equal(ran, 1); assert.equal(root.children.length, 0);
  core.modal('C', h('p', {}, 'b'), [{ label: 'Bad', run: async () => { throw new Error('nope'); } }]); [...root.querySelectorAll('button')].find((b) => b.textContent === 'Bad').click(); await wait();
  assert.equal(root.children.length, 1); assert.match(env.w.document.getElementById('toasts').textContent, /nope/);                 // stays open on failure
});

test('responsive shell: mobile drawer vs desktop collapse; CSS has breakpoint, dark mode and reduced motion', async () => {
  let env = await bootAt('#/dashboard', {}, { narrow: true }); const side = env.w.document.getElementById('sidebar'); const menu = env.w.document.getElementById('menu-btn');
  menu.click(); assert.ok(side.classList.contains('open')); assert.ok(!side.classList.contains('collapsed')); side.querySelector('a').click(); assert.ok(!side.classList.contains('open'));
  env = await bootAt('#/dashboard', {}, { narrow: false }); const s2 = env.w.document.getElementById('sidebar'); env.w.document.getElementById('menu-btn').click(); assert.ok(s2.classList.contains('collapsed'));
  assert.match(css, /@media \(max-width:800px\)/); assert.match(css, /prefers-color-scheme:dark/); assert.match(css, /prefers-reduced-motion/); assert.match(css, /:root\[data-theme=dark\]/);
  assert.match(html, /name="viewport"/); assert.match(html, /<main id="view" tabindex="-1">/);
  env.w.document.getElementById('theme').click(); assert.ok(['dark', 'light'].includes(env.w.document.documentElement.dataset.theme)); const first = env.w.document.documentElement.dataset.theme;
  env.w.document.getElementById('theme').click(); assert.notEqual(env.w.document.documentElement.dataset.theme, first);
});

test('notifications bell shows unread count and opens the list', async () => {
  const env = await bootAt('#/dashboard', { 'POST /api/notifications/read': {} }); await until(() => env.w.document.querySelector('#bell .dot'));
  assert.equal(env.w.document.querySelector('#bell .dot').textContent, '1'); env.w.document.getElementById('bell').click(); await until(() => env.w.document.querySelector('.modal'));
  assert.match(env.w.document.querySelector('.modal').textContent, /Clip rendered/);
});

test('social accounts: pending config is explicit and offers no connect; connected shows permissions and disconnect', async () => {
  const env = await bootAt('#/accounts?connected=youtube'); const cards = [...env.view().querySelectorAll('.card')];
  const tt = cards.find((c) => c.textContent.includes('TikTok')); assert.match(tt.textContent, /pending configuration/i); assert.match(tt.textContent, /TIKTOK_CLIENT_KEY/); assert.match(tt.textContent, /docs\/TIKTOK_INTEGRATION\.md/); assert.equal(tt.querySelector('a[href^="/api/social"]'), null);
  const yt = cards.find((c) => c.textContent.includes('YouTube')); assert.match(yt.textContent, /youtube\.upload/); assert.match(yt.textContent, /My Channel/); assert.ok([...yt.querySelectorAll('button')].some((b) => b.textContent === 'Disconnect'));
  assert.match(env.view().textContent, /youtube connected/);
  const e2 = await bootAt('#/accounts?error=access_denied'); assert.match(e2.view().querySelector('.notice.err').textContent, /access_denied/);
});

test('analytics: unavailable metrics render as n/a, never as zero; insights caveat visible', async () => {
  const env = await bootAt('#/analytics?range=7d'); const text = env.view().textContent;
  assert.match(text, /1,500/); assert.ok(env.view().querySelectorAll('.stat .muted').length >= 5);                     // likes/shares/reach/... are n/a
  assert.equal([...env.view().querySelectorAll('.stat')].filter((s) => s.textContent === '0').length, 0); assert.match(text, /correlations only/); assert.match(text, /at least 20 are needed/);
  assert.ok(env.view().querySelector('.tabs button.active').textContent === '7d');
});

test('AI providers form: required fields and custom URL validated client-side; key sent once and field not re-rendered', async () => {
  const env = await bootAt('#/providers', { 'POST /api/ai/providers': { provider: {} } }); const addBtn = [...env.view().querySelectorAll('button')].find((b) => b.textContent === 'Add provider'); const err = [...env.view().querySelectorAll('.err-msg')].pop();
  addBtn.click(); assert.match(err.textContent, /required/); assert.equal(env.calls.filter((c) => c.key === 'POST /api/ai/providers').length, 0);
  const inputs = [...env.view().querySelectorAll('.card:last-child input, .card:last-child select')]; const [kind, , model, key] = inputs; model.value = 'm'; key.value = 'sk-secret-xyz'; kind.value = 'custom'; addBtn.click(); assert.match(err.textContent, /base URL/);
  kind.value = 'gemini'; addBtn.click(); await until(() => env.calls.some((c) => c.key === 'POST /api/ai/providers')); const sent = env.calls.find((c) => c.key === 'POST /api/ai/providers'); assert.equal(sent.body.apiKey, 'sk-secret-xyz'); assert.equal(sent.headers['x-csrf-token'], 'csrf1');
  assert.equal(key.getAttribute('type'), 'password'); assert.match(env.view().textContent, /No provider is assumed to be free/);
});

test('settings: client validation, save payload, notification toggles, password length', async () => {
  const env = await bootAt('#/settings', { 'PATCH /api/settings': {}, 'POST /api/auth/password': {} }); const v = env.view();
  const ret = v.querySelector('input[type=number]'); ret.value = '0'; [...v.querySelectorAll('button')].find((b) => b.textContent === 'Save').click(); assert.match(v.querySelector('.err-msg').textContent, /between 1 and 3650/); assert.equal(env.calls.filter((c) => c.key === 'PATCH /api/settings').length, 0);
  ret.value = '14'; [...v.querySelectorAll('button')].find((b) => b.textContent === 'Save').click(); await until(() => env.calls.some((c) => c.key === 'PATCH /api/settings')); assert.equal(env.calls.find((c) => c.key === 'PATCH /api/settings').body.retentionDays, 14); assert.equal(env.calls.find((c) => c.key === 'PATCH /api/settings').body.timezone, 'Asia/Kolkata');
  v.querySelector('[data-k=storage_warning]').checked = false; [...v.querySelectorAll('button')].find((b) => b.textContent === 'Save notification settings').click(); await until(() => env.calls.filter((c) => c.key === 'PATCH /api/settings').length > 1);
  assert.equal(env.calls.filter((c) => c.key === 'PATCH /api/settings')[1].body.notifications.storage_warning, false);
  const pwBtn = [...v.querySelectorAll('button')].find((b) => b.textContent === 'Change password'); pwBtn.click(); assert.match([...v.querySelectorAll('.err-msg')].pop().textContent, /12 characters/);
});

test('editor: validates trim length, renders download link and preview only for ready clips, vertical player', async () => {
  const env = await bootAt('#/editor/c1', { 'PATCH /api/clips/c1': {}, 'POST /api/clips/c1/render': {} }); const v = env.view();
  assert.ok(v.querySelector('video.vertical')); assert.ok(v.querySelector('a[download]')); assert.match(v.textContent, /1080/);
  const [start, end] = v.querySelectorAll('input[type=number]'); start.value = '5'; end.value = '6'; [...v.querySelectorAll('button')].find((b) => b.textContent === 'Save & render').click(); await wait(30);
  assert.match(v.textContent, /between 3 and 180/); assert.equal(env.calls.filter((c) => c.key === 'PATCH /api/clips/c1').length, 0);
  end.value = '25'; [...v.querySelectorAll('button')].find((b) => b.textContent === 'Save & render').click(); await until(() => env.calls.some((c) => c.key === 'POST /api/clips/c1/render'));
  const body = env.calls.find((c) => c.key === 'PATCH /api/clips/c1').body; assert.equal(body.start_s, 5); assert.equal(body.end_s, 25); assert.ok(['smart', 'center', 'manual'].includes(body.settings.crop.mode)); assert.ok(['none', 'standard', 'highlight', 'custom'].includes(body.settings.subtitles.mode)); assert.match(body.settings.subtitles.color, /^#[0-9a-f]{6}$/i);
  const e2 = await bootAt('#/editor/c1', { 'GET /api/clips/c1': { clip: { ...FIX['GET /api/clips/c1'].clip, status: 'draft', previewUrl: null, downloadUrl: null } } }); assert.equal(e2.view().querySelector('a[download]'), null); assert.match(e2.view().textContent, /Render the clip first/);
});

test('metadata studio: per-platform fields, limits shown, no tags field outside YouTube, template mode labelled', async () => {
  const gen = (body) => ({ metadata: [body.platforms[0] === 'youtube'
    ? { id: 'm1', platform: 'youtube', title: 'T', description: 'D', hashtags: ['a'], tags: ['x'], category: '24', privacy: 'private', source: 'template', provider: null, titleAlternatives: [], warnings: [] }
    : { id: 'm2', platform: 'instagram', caption: 'Cap', hashtags: ['a'], tags: [], privacy: '', source: 'template', provider: null, titleAlternatives: [], warnings: [] }] });
  const env = await bootAt('#/metadata/c1', { 'POST /api/metadata/generate': gen }); const v = env.view(); const draft = () => [...v.querySelectorAll('button')].find((b) => b.textContent.startsWith('Draft from transcript'));
  assert.match(v.textContent, /No YouTube metadata yet/); draft().click(); await until(() => v.querySelector('.count'));
  assert.ok([...v.querySelectorAll('.count')].some((c) => c.textContent === '1/100')); assert.match(v.textContent, /Tags \(500 characters total\)/); assert.match(v.textContent, /template/);
  assert.equal(env.calls.find((c) => c.key === 'POST /api/metadata/generate').body.mode, 'template');
  [...v.querySelectorAll('.tabs button')].find((b) => b.textContent.startsWith('Instagram')).click(); await wait(); assert.match(v.textContent, /No Instagram metadata yet/); draft().click();
  await until(() => /no separate tags field/.test(v.textContent)); assert.match(v.textContent, /Instagram has no separate tags field/); assert.equal([...v.querySelectorAll('label')].some((l) => l.textContent.startsWith('Tags')), false);
  assert.ok([...v.querySelectorAll('.count')].some((c) => c.textContent === '3/2200'));
});
