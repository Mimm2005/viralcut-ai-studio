#!/usr/bin/env bash
# Runs every automated test suite. Requires: python3 + pip, node >= 22.
set -euo pipefail
cd "$(dirname "$0")/.."
echo "== engine (pytest) =="; (cd engine && python3 -m pytest tests -q)
echo "== worker (node:test) =="; (cd worker && node --experimental-sqlite --no-warnings --test)
echo "== frontend (jsdom) =="; (cd frontend && { [ -d node_modules ] || npm install --no-audit --no-fund; } && node --test test/frontend.test.js)
echo "== secret scan =="; ./scripts/scan-secrets.sh
echo "ALL SUITES PASSED"
