#!/usr/bin/env bash
# Deploys the Worker + frontend to Cloudflare (free plan). Does NOT create any paid resource.
# Prerequisite: you have run `npx wrangler login` and completed docs/DEPLOYMENT.md steps 1-4.
set -euo pipefail
cd "$(dirname "$0")/../worker"
grep -qE "REPLACE_WITH_YOUR_(D1_DATABASE_ID|BUCKET_NAME)" wrangler.toml && { echo "Edit worker/wrangler.toml first (database_id, S3_BUCKET, APP_URL)."; exit 1; }
npm install --no-audit --no-fund
npx wrangler d1 migrations apply viralcut --remote
npx wrangler deploy
echo "Deployed. Open your APP_URL and complete first-run setup with your SETUP_TOKEN."
