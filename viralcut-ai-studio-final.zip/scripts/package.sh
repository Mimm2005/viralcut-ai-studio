#!/usr/bin/env bash
# Builds viralcut-ai-studio-final.zip without build artefacts, caches, node_modules or credentials.
set -euo pipefail
cd "$(dirname "$0")/.."
./scripts/scan-secrets.sh
OUT="${1:-../viralcut-ai-studio-final.zip}"; rm -f "$OUT"
zip -rq "$OUT" . -x 'node_modules/*' '*/node_modules/*' '*__pycache__*' '*.pyc' '.pytest_cache/*' '*/.pytest_cache/*' '.wrangler/*' '*/.wrangler/*' '.env' '*/.dev.vars' '*.zip' '.git/*' 'package-lock.json' '*/package-lock.json'
echo "wrote $OUT"; unzip -l "$OUT" | tail -1
