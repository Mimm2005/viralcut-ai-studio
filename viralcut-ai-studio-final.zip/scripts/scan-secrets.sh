#!/usr/bin/env bash
# Fails if anything that looks like a real credential is present in the source tree.
set -uo pipefail
cd "$(dirname "$0")/.."
PATTERN='(AIza[0-9A-Za-z_-]{30,}|sk-[A-Za-z0-9]{32,}|sk-ant-[A-Za-z0-9_-]{20,}|ya29\.[0-9A-Za-z_-]{20,}|EAA[A-Za-z0-9]{40,}|AKIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY-----|xox[abp]-[0-9A-Za-z-]{10,}|ghp_[A-Za-z0-9]{30,})'
hits=$(grep -rIE "$PATTERN" . --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=__pycache__ --exclude=*.zip --exclude=scan-secrets.sh --exclude=*.test.js --exclude=test_*.py 2>/dev/null)
if [ -n "$hits" ]; then echo "POSSIBLE SECRETS FOUND:"; echo "$hits"; exit 1; fi
bad=$(find . -name ".env" -o -name ".dev.vars" -o -name "*.pem" -o -name "*.key" 2>/dev/null | grep -v node_modules)
if [ -n "$bad" ]; then echo "Credential files present:"; echo "$bad"; exit 1; fi
echo "secret scan: clean"
