#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../engine"
export ENGINE_TOKEN="${ENGINE_TOKEN:-dev-token-change-me}" VC_DATA_DIR="${VC_DATA_DIR:-/tmp/viralcut}"
python3 -m pip install -q -r requirements.txt
exec python3 -m uvicorn app.main:app --host 127.0.0.1 --port 7860 --reload
