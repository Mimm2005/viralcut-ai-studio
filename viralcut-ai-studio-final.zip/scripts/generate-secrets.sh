#!/usr/bin/env bash
# Prints fresh random secrets. Nothing is stored or sent anywhere.
set -euo pipefail
command -v openssl >/dev/null || { echo "openssl is required"; exit 1; }
echo "ENCRYPTION_KEY=$(openssl rand -base64 32)"
echo "SETUP_TOKEN=$(openssl rand -hex 16)"
echo "ENGINE_TOKEN=$(openssl rand -hex 32)"
echo
echo "Set each in Cloudflare with:  cd worker && npx wrangler secret put ENCRYPTION_KEY   (paste the value when asked)"
echo "BACK UP ENCRYPTION_KEY somewhere safe: losing it makes stored API keys and OAuth tokens unreadable."
