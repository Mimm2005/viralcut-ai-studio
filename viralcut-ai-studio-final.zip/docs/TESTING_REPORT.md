# Testing report

Run date: 2026-11-21 · Environment: Linux, Python 3.12, Node 22, FFmpeg 6.1 · Command: `./scripts/run-tests.sh`

## Result: 117 automated tests, all passing

| Suite | Tests | Runner | What is real vs. simulated |
|---|---|---|---|
| Engine | **55** | pytest | **Real:** FFmpeg/ffprobe, OpenCV, PySceneDetect, numpy signals, scoring, rendering, SQLite job store, FastAPI app. **Simulated:** Whisper (scripted fake model, because the model cannot be downloaded in the build sandbox). |
| Worker | **48** | node:test | **Real:** all route/handler code, crypto (WebCrypto), migrations (the real SQL files). **Simulated:** D1 (a shim over `node:sqlite`), R2 and an S3-compatible API (in-memory fakes), every external HTTP call (mock `fetch`). |
| Frontend | **14** | node:test + jsdom | **Real:** the actual JS modules rendering into a DOM. **Simulated:** browser engine (jsdom, no layout/painting), API (scripted fetch). |
| Secret scan | 1 | grep | Fails the build on credential-like strings or `.env`/key files. |

## Coverage against the specification

| Area | Verified by tests |
|---|---|
| Frontend | navigation (10 sections, order, active state), responsive shell (mobile drawer vs desktop collapse, CSS breakpoint/dark/reduced-motion present), form validation (login/setup, providers, settings, editor trim, schedules), loading and error states (+retry), modal behaviour (ARIA, Esc, backdrop, failing action stays open), XSS-safe rendering, "n/a" for unavailable metrics, pending-configuration cards |
| Backend | setup one-time + token, login/logout/me, rate limits, CSRF + Origin, cross-user isolation (404), validation of every tested endpoint, upload init/complete/proxy, duplicate detection, signed URL tamper/expiry, job creation/status/events/cancel, engine-unreachable → queued → cron submits |
| AI | transcript parsing (faster-whisper segment shape), candidate generation under config limits, scoring weights (exact 20/20/20/15/15/10), score boundaries 0–100, duplicate suppression, range re-analysis, no-speech fallback, provider request shapes (Gemini/OpenAI/Anthropic/custom), provider failure → no silent paid fallback, call-limit and budget blocking *before* any network call, routing, key encryption/redaction, SSRF guard |
| Video | audio extraction format + timestamp accuracy, frame sampling, trimming accuracy, crop geometry (landscape/square/vertical, bounds), manual/smart/center crop, ASS subtitles (modes, colour order, injection-sanitising), 720p and 1080p output, H.264/AAC/resolution/duration validation, A/V stream sync (< 0.25 s), silent sources, out-of-range end |
| Jobs | idempotent enqueue, exclusive claim, exponential backoff, max attempts, permanent vs transient failure, lease expiry recovery, heartbeat/cancel, **checkpoint resume (only the missing chunk is re-run)** |
| Social | OAuth state (forged, reused, expired, wrong session), PKCE S256, least-privilege scopes, granted-vs-requested scopes, tokens encrypted at rest, token refresh, refresh-token retention, revocation → expired + notification, disconnect keeps history |
| Publishing | approval preconditions, frozen snapshot, duplicate prevention, schedule validation (past/too far/timezone/IST conversion), recurring slots, not published early, **published only after platform confirmation**, resume at verify without re-upload, duplicate-upload guard after crash, retry/backoff/fail, 401 → no blind retries, concurrent runners claim once, lease expiry, queue pause, cancel rules, Instagram "interrupted publish → needs verification", Facebook/TikTok/X multi-step flows, TikTok privacy downgrade |
| Analytics | API response parsing, missing metrics as `null` + reason, failed collection never overwrites real data, snapshot cadence, range filtering, platform comparison, insights gating (< 20 posts → no conclusions) and correlation caveat |
| Ops | retention policy, notification preferences, storage accounting |
| Standard | SigV4 presigning matches AWS's published test vector |

## Acceptance milestone (engine side) — passed

`engine/tests/test_acceptance.py`: a real 10-minute 640×360 video → chunked analysis (2 chunks, offsets correct) in ~21 s → 15 ranked, de-duplicated moments with scores, factors, confidence and explanations → 5 vertical 720p H.264/AAC Shorts rendered with highlighted subtitles and title overlay, each re-probed and validated. The Worker-side steps of your 15-step acceptance list (metadata generation incl. editing, approval, scheduling, scheduler state, publishing against a **mock** platform, saving analytics) are exercised in `publishing.test.js` / `ai_social.test.js`.

## NOT verified (read this)

1. **Live platform APIs: YouTube, Instagram, Facebook, TikTok, X.** Request shapes follow each platform's documentation as I know it, but they have only been run against mocks. Field names, versions and permissions drift; expect to fix small mismatches on first contact. Live publishing and live analytics are **unverified**.
2. **Real Faster-Whisper transcription.** Model download is impossible in the build sandbox. Chunking, offsets, parsing and checkpointing are tested with a scripted model; accuracy, speed and memory of real Whisper on a free CPU Space are unmeasured.
3. **Docker image build and Hugging Face deployment** (no Docker available). The Dockerfile is straightforward but unbuilt.
4. **Cloudflare deployment** (`wrangler deploy`, real D1, real R2, Cron Triggers, `[assets]` configuration). `wrangler.toml` has not been validated by wrangler. D1 and R2 are simulated by shims; real-service quirks (e.g. batch semantics, `RETURNING` handling, streaming uploads via `FixedLengthStream`, request-size and CPU limits) are untested. In particular **streaming a rendered clip from R2 through a Worker to YouTube/X has not been exercised in a Workers runtime.**
5. **Real browsers.** UI logic is tested in jsdom; there has been no visual QA, no cross-browser run, no real XHR upload-progress test, and no accessibility audit beyond semantic attributes.
6. **Performance on free infrastructure** (timings in FREE_TIER_LIMITATIONS are indicative only).
7. Free-tier numbers and third-party API details in the docs may be out of date.

## Known limitations / not implemented
- YouTube-URL and Google-Drive **download** are not implemented (honest `authorized` / `pending_configuration` states); upload the file instead. Live-stream ingest is a declared placeholder.
- Moment detection is signal-based (audio energy, speech cues, motion, scene cuts); lexicons are English-only, laughter detection is a heuristic, no semantic visual understanding or object detection. Scores are relative to each video, not calibrated against real outcomes until you have enough published history.
- "Reanalyse" re-runs the analysis restricted to a time range (it recomputes global signals).
- Editor has no timeline scrubber or live crop/subtitle preview; you preview the rendered clip. Manual crop is a horizontal slider.
- Cover/thumbnail recommendations are text suggestions from the AI, not generated images.
- Single-owner / single-account-per-platform by design (schema is ready for more).
- Retention deletes whole old files; there is no per-file restore.
- Facebook per-post metrics other than views are not collected.
- No i18n (UI in English; metadata language is selectable).

## Live verification checklist (do this before relying on the app)
1. Deploy; confirm `/api/health`, first-run setup, engine "reachable" in the Cost Guard card.
2. Upload a 1-minute video; analyse; render; download; check 1080×1920 playback with audio.
3. Run with real Whisper (`tiny`) and confirm transcript quality; time a 10-minute file.
4. Add an AI provider; *Test connection*; generate metadata.
5. For each platform you intend to use: connect with a **test/private** account, publish a short **private** clip, confirm it on the platform, check the job shows `published` with the platform id, then wait for analytics.
6. Kill/sleep the engine mid-analysis and confirm the job resumes; pause/resume the queue.
