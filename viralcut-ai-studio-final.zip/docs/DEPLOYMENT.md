# Deployment (₹0 target)

Everything below uses free plans. **No step creates a paid resource**, but providers can change terms and some (notably Cloudflare R2) ask for a payment method on file before enabling the free allowance. Read each prompt; stop if you are asked to pick a paid plan.

You will deploy three things: (A) the Worker + frontend on Cloudflare, (B) the processing engine on Hugging Face Spaces (or your own server), (C) optional platform/AI credentials.

## Step 0 — Accounts
1. Cloudflare account: https://dash.cloudflare.com/sign-up (Workers + D1 only; no card needed)
2. Hugging Face account: https://huggingface.co/join
3. Later, per platform: Google Cloud, Meta for Developers, TikTok for Developers, X developer portal (see the integration guides).

## Step 1 — Install tools and log in
```bash
node --version          # must be 22+
cd viralcut/worker && npm install
npx wrangler login      # opens a browser window to authorise
```

## Step 2 — Database (D1)
```bash
npx wrangler d1 create viralcut
```
Copy the printed `database_id` into `worker/wrangler.toml` (`database_id = "…"`).

## Step 3 — Video storage (S3-compatible, no Cloudflare R2 needed)
Any S3-compatible bucket works. Cloudflare R2 asks for a payment method; **Backblaze B2** (10 GB free at the time of writing; verify on their pricing page and check whether signup asks for a card) is the first one to try. Alternatives: Supabase Storage (free tier is small, ~1 GB, per-file size limit), Wasabi/others (usually trials).

Backblaze B2 steps: sign up at https://www.backblaze.com/cloud-storage → **Buckets → Create a Bucket** (private, any unique name) → open the bucket and note the **Endpoint** (like `s3.us-west-004.backblazeb2.com`) → **Application Keys → Add a New Application Key**, restricted to that bucket with *Read and Write* → **copy the keyID and applicationKey immediately** (the key is shown once).

Then edit `worker/wrangler.toml`: `S3_ENDPOINT` (hostname only), `S3_REGION` (the part after `s3.`, e.g. `us-west-004`), `S3_BUCKET`. Later, in Step 4, you store the key as secrets `S3_ACCESS_KEY_ID` (= keyID) and `S3_SECRET_ACCESS_KEY` (= applicationKey).

`UPLOAD_MODE = "proxy"` makes uploads go through the Worker (max 95 MB per file, no bucket CORS needed). That is the simplest start. For bigger files, configure CORS on the bucket for your `APP_URL` (PUT/GET/HEAD, header `*`) and remove `UPLOAD_MODE`.
If you do use Cloudflare R2 instead, copy `worker/wrangler.r2.toml.example` over `wrangler.toml` and follow the R2 notes in that file's comments (S3 token + `R2_*` secrets).

## Step 4 — Configure and set secrets
Edit `worker/wrangler.toml`: set `APP_URL` to the URL your Worker will have (`https://viralcut-api.<your-subdomain>.workers.dev`; you can see your subdomain after the first deploy, then edit and redeploy) and `FRONTEND_ORIGIN` to the same value.

```bash
cd .. && ./scripts/generate-secrets.sh        # prints ENCRYPTION_KEY, SETUP_TOKEN, ENGINE_TOKEN
cd worker
npx wrangler secret put ENCRYPTION_KEY        # paste when prompted; BACK THIS UP
npx wrangler secret put SETUP_TOKEN
npx wrangler secret put ENGINE_TOKEN
npx wrangler secret put S3_ACCESS_KEY_ID
npx wrangler secret put S3_SECRET_ACCESS_KEY
# ENGINE_URL is set in Step 6
```

## Step 5 — Deploy the Worker and frontend
```bash
../scripts/deploy.sh        # = d1 migrations apply --remote  +  wrangler deploy
```
The Worker serves the frontend from the same origin (`[assets]` in `wrangler.toml`), which keeps cookies simple and secure. Cron triggers (every minute and every 5 minutes) are registered automatically.
*Cloudflare Pages alternative:* you can host `frontend/` on Pages, but then `/api/*` must be routed to the Worker on the same domain (custom domain + Worker route), otherwise the session cookie will be treated as third-party and blocked by many browsers.

## Step 6 — Deploy the processing engine on Hugging Face Spaces
1. https://huggingface.co/new-space → name `viralcut-engine`, SDK **Docker**, hardware **CPU basic (free)**, visibility **Public** (the engine is protected by `ENGINE_TOKEN`; the Worker does not send a Hugging Face token).
2. Clone the Space repo and copy in `engine/Dockerfile`, `engine/requirements.txt`, `engine/app/`, and `engine/README_SPACE.md` renamed to `README.md`. Commit and push.
3. Space → Settings → *Variables and secrets* → add secret `ENGINE_TOKEN` (the same value you gave the Worker). Optional variables: `WHISPER_MODEL` (`tiny` default; `base`/`small` are better but slower on CPU), `MAX_UPLOAD_MB`.
4. Wait for the build, then:
```bash
curl https://<user>-viralcut-engine.hf.space/health            # → {"status":"ok",...}
cd worker && npx wrangler secret put ENGINE_URL                 # https://<user>-viralcut-engine.hf.space
```
Free Spaces sleep when idle. The first request wakes them (can take minutes); jobs stay `queued` and the cron retries automatically.
*Own server alternative:* `docker compose up --build -d` on any machine with a public HTTPS URL (e.g. behind Caddy or a Cloudflare Tunnel) and use that URL as `ENGINE_URL`.

## Step 7 — First run
Open your `APP_URL` → "Create the owner account" → email, a 12+ character password and your `SETUP_TOKEN`. Registration closes permanently after this.
Then: **AI Providers** → add a provider (optional) → **Social Accounts** (shows *pending configuration* until you finish the integration guides) → **Viral Finder** → upload a short test video (1–2 min) first.

## Step 8 — Verify the deployment
| Check | Expected |
|---|---|
| `curl $APP_URL/api/health` | `{"ok":true,…}` |
| AI Providers page → Cost Guard card | Engine "reachable" and free disk shown |
| Upload + Analyse a 1-minute clip | job progresses queued → running → succeeded; moments listed |
| Render a clip | status ready; MP4 downloads; 1080×1920 |
| `npx wrangler tail` | no `unhandled` errors |

## Updating
```bash
git pull   # or unzip the new release over the folder
./scripts/run-tests.sh
cd worker && npx wrangler d1 migrations apply viralcut --remote && npx wrangler deploy
# engine: push the new engine/ files to the Space (or docker compose up --build -d)
```
Migrations are additive and numbered; never edit an applied migration, add a new file.

## Optional: Google Cloud Run
Not configured and never enabled automatically. If you later choose it: set billing alerts first, deploy `engine/` as a service with min instances 0, and point `ENGINE_URL` at it. Cloud Run can incur charges.
