# AI provider setup

ViralCut never calls an AI provider until **you** add one (AI Providers page) **and** a feature needs it. Moment scoring does not use AI at all; AI is used only for metadata text (titles, descriptions, captions, hashtags, tags). Without a provider you can still use **Draft from transcript (no AI)**, which is labelled `template`.

## Adding a provider
AI Providers → *Add a provider*: pick type, enter the **model name exactly as the provider's documentation lists it** (model names change; none are hard-coded), paste the API key. The key is encrypted immediately and only its last 4 characters are ever shown again. Click **Test connection** (one tiny request; counts toward usage).

| Type | Get a key | Notes |
|---|---|---|
| Gemini | https://aistudio.google.com/apikey | Google offers a free tier with rate limits for some models; check current limits. Set *cost tier* accordingly. |
| OpenAI | https://platform.openai.com/api-keys | Paid. |
| Anthropic Claude | https://console.anthropic.com/ | Paid. |
| Custom (OpenAI-compatible) | your provider's docs | Any `…/v1/chat/completions` endpoint (OpenRouter, Groq, Together, a self-hosted vLLM/Ollama gateway…). Base URL must be public **https**; private/localhost addresses are refused. Whether it is free depends on the provider. |

**Nothing is assumed to be free.** Set *cost tier* (free / paid / unknown) so Cost Guard can warn you.

## Routing and fallback (all user-configured)
- **Default provider**: used for any task with no specific route.
- **Task routes**: tick the tasks (metadata, reasoning, alternatives, explanation) a provider should handle, e.g. Gemini → metadata, Claude → reasoning.
- **Fallback**: a provider is used as a fallback **only if you tick "Allow as fallback"**. A paid provider is never used silently.
- **Temperature / max tokens**: per provider; blank = provider default.

## Cost Guard
Before every call the gateway checks, per provider and calendar month: **monthly call limit**, **monthly budget (₹)**, and *paused*. If a limit is reached the call is **not made**. Costs are estimated only if you enter token prices (₹ per million input/output tokens); otherwise the UI says *unknown* instead of inventing a figure. The Costs card also shows storage use and engine health, and warns at 80 %.

## Errors
Provider errors are stored (redacted) on the provider card; quota errors (HTTP 429) mark the provider `error` until the next success. Keys appear in headers only, never in URLs or logs.
