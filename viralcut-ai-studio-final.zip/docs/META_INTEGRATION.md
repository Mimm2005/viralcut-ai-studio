# Instagram & Facebook (Meta) integration

Status: **implemented, mock-tested, NOT verified against the live Graph API.** Meta changes permission names and API versions often; verify everything below against https://developers.facebook.com/docs before relying on it.

## Requirements
- A **Facebook Page** you administer.
- For Instagram: an **Instagram Business or Creator account linked to that Page**.
- A Meta developer app (type *Business*) with the products *Facebook Login* (and Instagram API access).

## Setup checklist
1. https://developers.facebook.com → My Apps → Create App.
2. Facebook Login → Settings → **Valid OAuth Redirect URIs**: add both  
   `https://<APP_URL>/api/social/instagram/callback` and `https://<APP_URL>/api/social/facebook/callback`.
3. Secrets: `META_APP_ID`, `META_APP_SECRET`. Optionally set `META_GRAPH_VERSION` (default `v21.0`; check the currently supported version).
4. Social Accounts → **Connect** Instagram / Facebook.

Permissions requested (least privilege for each feature): Instagram — `instagram_basic`, `instagram_content_publish`, `instagram_manage_insights`, `pages_show_list`, `pages_read_engagement`. Facebook — `pages_show_list`, `pages_manage_posts`, `pages_read_engagement`, `read_insights`. Only permissions actually **granted** are stored and shown.

## App Review
In *Development mode* only app admins/developers/testers can authorise, which is enough for personal use of your own accounts. Publishing for anyone else requires **App Review** and Business Verification (days to weeks). The app does not bypass this.

## Flows implemented
- **Instagram Reels**: `POST /{ig-user}/media` (`media_type=REELS`, `video_url` = short-lived presigned R2 URL) → poll `status_code` until `FINISHED` → `POST /{ig-user}/media_publish` → `GET permalink`. If the process dies between "publish sent" and "id saved", the job becomes **needs verification** (no automatic retry) to avoid double posting.
- **Facebook Page Reels**: `video_reels` `start` → hosted-file upload (`file_url` header) → `finish` with `video_state=PUBLISHED` → poll status.
- Page access tokens obtained from a long-lived user token do not expire; if Meta invalidates them the account moves to **expired** and you reconnect.

## Limits
Instagram has publishing rate limits per account per day, and requires the media to be fetchable by Meta (the presigned URL lasts 1 hour). Reels must meet Meta's format rules (MP4/H.264/AAC, 9:16, up to the current maximum length). Metrics are requested one at a time; any Meta rejects are shown as n/a with the reason. Facebook per-post likes/comments/shares are not collected in this version.
