# Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Login page says "Create the owner account" on a deployed site | D1 migrations not applied, or empty DB | `npx wrangler d1 migrations apply viralcut --remote` |
| `Too many requests` on login | Rate limit (8 attempts / 15 min per account) | Wait; see `Retry-After`. |
| Cannot sign in after redeploy | `ENCRYPTION_KEY` unchanged is fine; session cookie requires HTTPS and same origin | Use the `APP_URL` exactly; do not mix `workers.dev` and a custom domain. |
| Worker error 1102 / "exceeded CPU" on login | Free-plan CPU limit and PBKDF2 | Set `PBKDF2_ITERATIONS` to 50000 and set a new password (new hashes use it). |
| Upload fails with 503 about storage / `S3_*` | Storage variables or secrets missing | Set `S3_ENDPOINT/S3_REGION/S3_BUCKET` in `wrangler.toml` and the two `S3_*` secrets (DEPLOYMENT step 3-4). |
| Upload fails with 413 / "95 MB" | Proxy upload limit | Configure bucket CORS and remove `UPLOAD_MODE`, or compress the video. |
| Browser upload blocked (CORS) | Direct upload mode without bucket CORS | Set `UPLOAD_MODE = "proxy"` or add the CORS rule for your exact `APP_URL`. |
| "Storage … failed (HTTP 403)" | Wrong key/region/endpoint or key not scoped to this bucket | Re-check `S3_REGION` (must match the endpoint), bucket name, and the application key. |
| Analysis stays `queued` | Engine not configured/unreachable/asleep | AI Providers → Cost Guard card shows engine status; check `ENGINE_URL`/`ENGINE_TOKEN`; wake the Space by opening `/health`. The cron retries every minute. |
| Job `failed`: "unreadable media" / "no video stream" | Corrupt or unsupported file | Re-encode to H.264/AAC MP4 and re-upload. |
| Job `failed`: "insufficient free disk" | Engine disk full | Restart the Space (disk is ephemeral) or free space; job retries. |
| Transcript empty | No speech, wrong model, or Whisper model failed to download | Check engine logs; scoring then relies on audio/visual signals and confidence is lower. |
| Render "output validation failed" | FFmpeg built without libx264/libass | Use the provided Dockerfile (Debian ffmpeg). |
| Subtitles show boxes | Font missing | Choose "DejaVu Sans" or "Liberation Sans" (installed in the image). |
| "No AI provider configured" (409) | Intended: nothing is called until you add one | Add a provider or use *Draft from transcript*. |
| "All configured providers failed or are blocked by Cost Guard" | Quota, limit, bad key or paused provider | Read the listed attempts; raise limits deliberately or add a fallback you explicitly allow. |
| Social card says **pending configuration** | `*_CLIENT_ID/SECRET` secrets missing | Follow the platform guide; set secrets; redeploy. |
| OAuth error `invalid_or_expired_state` | Took > 10 min, reused link, or different browser session | Click Connect again. |
| `redirect_uri_mismatch` | Redirect URI differs from the one shown on the card | Register the exact URI shown (scheme, host, path). |
| Account shows **expired** | Token revoked/expired | Reconnect. Scheduled posts for it fail with "reconnect" and can be retried afterwards. |
| Job **needs verification** | Interrupted at a point where the post may exist | Check the platform; if it is not there use "It was not posted: retry"; if it is, cancel the job. |
| YouTube video is private although you chose public | Unaudited API project | Complete Google's audit or change privacy in Studio. |
| Calendar shows wrong time | Timezone setting | Settings → Timezone (default Asia/Kolkata). |
| Nothing publishes | Queue paused, or job not `scheduled`, or cron not running | Calendar → check "queue paused"; `npx wrangler tail` to watch cron runs. |

Logs: `cd worker && npx wrangler tail` (secrets are redacted). Engine: Space → Logs, or `docker compose logs -f engine`.
