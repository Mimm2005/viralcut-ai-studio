# X (Twitter) integration

Status: **adapter implemented and mock-tested; NOT verified live; X API access is a paid product.**

X's API now requires a paid plan/credits for posting. Because the project forbids mandatory paid services, the X integration is **inactive unless you configure `X_CLIENT_ID`/`X_CLIENT_SECRET` yourself**, and Cost Guard never enables it. Check X's current developer pricing before connecting.

1. https://developer.x.com → create a project/app (OAuth 2.0, *Web app*, confidential client). Callback URI: `https://<APP_URL>/api/social/x/callback`.
2. Scopes requested: `tweet.read tweet.write users.read media.write offline.access`.
3. Secrets: `X_CLIENT_ID`, `X_CLIENT_SECRET`; connect from Social Accounts.

Flow: OAuth 2.0 + PKCE → chunked media upload (`initialize`, `append` 4 MB segments, `finalize`, poll processing) → `POST /2/tweets` with the media id. Post text ≤ 280 characters (hashtags are dropped first if needed). If the process is interrupted while creating the post the job becomes **needs verification**. Metrics: `public_metrics` (likes, replies, reposts, quotes, impressions where returned); reach is n/a.

Endpoint paths and media-upload requirements change; verify them in X's documentation before the first live run.
