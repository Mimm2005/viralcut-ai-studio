# Installation (local development)

## 1. Prerequisites
| Tool | Version | Check |
|---|---|---|
| Python | 3.11+ | `python3 --version` |
| FFmpeg (+ffprobe) with libx264, libass, libfreetype | 6.x | `ffmpeg -version` |
| Node.js | **22+** (uses `node:sqlite` for tests) | `node --version` |
| Docker (optional) | any | `docker --version` |

Ubuntu/Debian: `sudo apt install ffmpeg fonts-dejavu-core python3-venv`. macOS: `brew install ffmpeg node python`. Windows: use WSL2.

## 2. Engine
```bash
cd engine
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
ENGINE_TOKEN=dev-token python -m pytest tests -q      # 54 tests, ~1 minute
```
Run it: `ENGINE_TOKEN=dev-token uvicorn app.main:app --port 7860` (or `./scripts/dev-engine.sh`). The first transcription downloads the Whisper model (`tiny` ≈ 75 MB) from Hugging Face, so it needs internet once. Check: `curl localhost:7860/health`.

## 3. Worker + frontend (local)
```bash
cd worker && npm install
cp .dev.vars.example .dev.vars        # then fill in: ./scripts/generate-secrets.sh prints values
npx wrangler d1 migrations apply viralcut --local
npx wrangler dev                       # serves API and ../frontend on http://localhost:8787
```
Open http://localhost:8787 → create the owner with your `SETUP_TOKEN`. Browsers accept the `Secure` session cookie on `http://localhost`; on any other host you need HTTPS.
`wrangler dev` uses a local R2 emulation; presigned URLs need real R2 S3 credentials, so locally uploads use the built-in proxy path (files ≤ 95 MB).

## 4. Tests
```bash
./scripts/run-tests.sh                # engine + worker + frontend + secret scan
```

## 5. Docker (optional)
```bash
cp .env.example .env && docker compose up --build
```
The image has not been built in the authoring environment; if the build fails, `docs/TROUBLESHOOTING.md` lists likely causes.
