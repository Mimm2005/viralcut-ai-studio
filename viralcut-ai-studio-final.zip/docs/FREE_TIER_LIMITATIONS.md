# Free-tier limitations

The values below are **reference figures believed correct when this was written and may have changed. Verify each on the provider's pricing/limits page before relying on them.** The app never assumes unlimited capacity and never upgrades anything automatically.

| Service | What you get (approx.) | What bites in practice |
|---|---|---|
| Cloudflare Workers (Free) | ~100k requests/day, very small CPU time per request, limited subrequests per invocation | Password hashing (PBKDF2) is the heaviest request → if login errors with a CPU-limit message, lower `PBKDF2_ITERATIONS`. Cron work is split (1 min / 5 min) and batch-limited to stay under subrequest caps. **Streaming a large video through a Worker to a platform may hit limits; keep Shorts small (< ~50 MB).** |
| Cloudflare D1 (Free) | ~5 GB, daily row read/write allowances | Heavy analytics polling uses reads; the app limits snapshot cadence (hourly → daily). |
| Object storage | **Cloudflare R2** (~10 GB free) needs a payment method to enable. **Backblaze B2** (~10 GB free at time of writing) or another S3-compatible service can be used instead without code changes. | Source videos are large: the quota bar (Settings) warns at 80 % of the quota *you* set (set it to your real free limit). Delete sources after rendering. Check egress/transaction fees on your provider's pricing page: some charge for downloads beyond a free allowance. |
| Hugging Face CPU Basic Space | ~2 vCPU / 16 GB RAM, **sleeps when idle**, ephemeral disk (tens of GB, wiped on restart) | A 10-minute video with Whisper `tiny` on CPU typically takes a few minutes to tens of minutes; `small`/`medium` are much slower. Cold start after sleep takes minutes; jobs wait in the queue and resume. The local job database is lost if the Space is rebuilt: queued engine jobs are re-submitted by the cron only while they remain `queued` in D1. |
| Gemini API (free tier) | rate- and quota-limited, model-dependent | 429 errors; Cost Guard marks the provider and never silently uses a paid fallback. |
| YouTube Data API | 10,000 quota units/day by default | Uploads are costly (≈1,600 units); expect only a few per day. |
| Meta / TikTok / X | free to register; **approval/review/paid access gates real publishing** | Review can take weeks; TikTok unaudited = private posts only; X requires paid API access. |

## Zero-budget operating tips
Use Whisper `tiny` first; analyse 10–30 minute videos rather than multi-hour streams; render at 720p when the Space is slow; delete source files after rendering; keep the number of scheduled posts per day within the platform quotas; pause the queue (Calendar → *Pause queue*) any time.
