# Database schema

_Generated from `migrations/*.sql` by `scripts/gen-docs.mjs`. Cloudflare D1 (SQLite). Timestamps are UTC epoch seconds. No video binaries are stored in D1: media lives in R2 and is referenced by key._

## Required tables

`users, sessions, projects, source_media, processing_jobs, job_events, transcripts, detected_moments, moment_scores, generated_clips, clip_metadata, ai_providers, social_accounts, oauth_tokens, publishing_schedules, publishing_jobs, published_posts, publishing_logs, analytics_snapshots, notifications, user_settings, audit_logs` — all present, plus support tables `ai_usage` (Cost Guard), `oauth_states` (CSRF/PKCE state) and `rate_limits`.

Key rules: foreign keys with `ON DELETE CASCADE` for owned data; `UNIQUE(user_id, platform)` on `social_accounts` (single-account mode, drop to go multi-account); a **partial unique index** on `publishing_jobs(clip_id, platform)` for live statuses prevents duplicate posts; predicted scores (`moment_scores`) are stored separately from actual results (`analytics_snapshots`); `ai_providers.api_key_enc` and `oauth_tokens.*_enc` are AES-256-GCM ciphertext.

## ai_providers

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| user_id | TEXT | NOT NULL |
| kind | TEXT | NOT NULL |
| label | TEXT | NOT NULL |
| base_url | TEXT |  |
| model | TEXT | NOT NULL |
| api_key_enc | TEXT | NOT NULL |
| key_hint | TEXT |  |
| temperature | REAL |  |
| max_tokens | INTEGER |  |
| cost_tier | TEXT | NOT NULL, default 'unknown' |
| is_default | INTEGER | NOT NULL, default 0 |
| allow_fallback | INTEGER | NOT NULL, default 0 |
| task_routes | TEXT | NOT NULL, default '[]' |
| monthly_call_limit | INTEGER |  |
| monthly_budget_inr | REAL |  |
| price_in_per_mtok_inr | REAL |  |
| price_out_per_mtok_inr | REAL |  |
| status | TEXT | NOT NULL, default 'untested' |
| last_error | TEXT |  |
| last_tested_at | INTEGER |  |
| created_at | INTEGER | NOT NULL |
| updated_at | INTEGER | NOT NULL |

Foreign keys: user_id → users.id (on delete cascade)

Indexes: `idx_ai_user`

## ai_usage

| Column | Type | Constraints |
|---|---|---|
| id | INTEGER | PK |
| provider_id | TEXT | NOT NULL |
| task | TEXT | NOT NULL |
| tokens_in | INTEGER |  |
| tokens_out | INTEGER |  |
| est_cost_inr | REAL |  |
| ok | INTEGER | NOT NULL |
| error | TEXT |  |
| created_at | INTEGER | NOT NULL |

Foreign keys: provider_id → ai_providers.id (on delete cascade)

Indexes: `idx_ai_usage_provider`

## analytics_snapshots

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| post_id | TEXT | NOT NULL |
| captured_at | INTEGER | NOT NULL |
| metrics | TEXT | NOT NULL |
| unavailable | TEXT |  |
| source | TEXT | NOT NULL, default 'api' |

Foreign keys: post_id → published_posts.id (on delete cascade)

Indexes: `idx_snap_post`

## audit_logs

| Column | Type | Constraints |
|---|---|---|
| id | INTEGER | PK |
| user_id | TEXT |  |
| action | TEXT | NOT NULL |
| target | TEXT |  |
| ip | TEXT |  |
| detail | TEXT |  |
| ts | INTEGER | NOT NULL |

Foreign keys: user_id → users.id (on delete set null)

Indexes: `idx_audit_user`

## clip_metadata

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| clip_id | TEXT | NOT NULL |
| platform | TEXT | NOT NULL |
| title | TEXT |  |
| title_alternatives | TEXT |  |
| description | TEXT |  |
| caption | TEXT |  |
| hashtags | TEXT |  |
| tags | TEXT |  |
| category | TEXT |  |
| language | TEXT | NOT NULL, default 'en' |
| privacy | TEXT | NOT NULL, default 'private' |
| cover_recommendation | TEXT |  |
| source | TEXT | NOT NULL, default 'manual' |
| provider | TEXT |  |
| model | TEXT |  |
| created_at | INTEGER | NOT NULL |
| updated_at | INTEGER | NOT NULL |

Foreign keys: clip_id → generated_clips.id (on delete cascade)

## detected_moments

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| job_id | TEXT | NOT NULL |
| project_id | TEXT | NOT NULL |
| source_id | TEXT | NOT NULL |
| rank | INTEGER | NOT NULL |
| start_s | REAL | NOT NULL |
| end_s | REAL | NOT NULL |
| moment_type | TEXT | NOT NULL, default 'general' |
| transcript | TEXT |  |
| suggested_title | TEXT |  |
| selected | INTEGER | NOT NULL, default 0 |
| user_edited | INTEGER | NOT NULL, default 0 |
| created_at | INTEGER | NOT NULL |

Foreign keys: source_id → source_media.id (on delete cascade); project_id → projects.id (on delete cascade); job_id → processing_jobs.id (on delete cascade)

Indexes: `idx_moments_job`

## generated_clips

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| user_id | TEXT | NOT NULL |
| project_id | TEXT | NOT NULL |
| moment_id | TEXT |  |
| source_id | TEXT | NOT NULL |
| title | TEXT |  |
| start_s | REAL | NOT NULL |
| end_s | REAL | NOT NULL |
| settings | TEXT | NOT NULL, default '{}' |
| status | TEXT | NOT NULL, default 'draft' |
| progress | REAL | NOT NULL, default 0 |
| engine_job_id | TEXT |  |
| r2_key | TEXT |  |
| size_bytes | INTEGER |  |
| duration_s | REAL |  |
| width | INTEGER |  |
| height | INTEGER |  |
| error | TEXT |  |
| created_at | INTEGER | NOT NULL |
| updated_at | INTEGER | NOT NULL |

Foreign keys: source_id → source_media.id (on delete cascade); moment_id → detected_moments.id (on delete set null); project_id → projects.id (on delete cascade); user_id → users.id (on delete cascade)

Indexes: `idx_clips_user`, `idx_clips_project`

## job_events

| Column | Type | Constraints |
|---|---|---|
| id | INTEGER | PK |
| job_id | TEXT | NOT NULL |
| ts | INTEGER | NOT NULL |
| level | TEXT | NOT NULL, default 'info' |
| message | TEXT | NOT NULL |

Foreign keys: job_id → processing_jobs.id (on delete cascade)

Indexes: `idx_job_events_job`

## moment_scores

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| moment_id | TEXT | NOT NULL |
| total | REAL | NOT NULL |
| hook | REAL | NOT NULL |
| emotion | REAL | NOT NULL |
| entertainment | REAL | NOT NULL |
| unexpectedness | REAL | NOT NULL |
| shareability | REAL | NOT NULL |
| storytelling | REAL | NOT NULL |
| confidence | REAL | NOT NULL |
| explanation | TEXT | NOT NULL |
| signals | TEXT |  |
| model_version | TEXT | NOT NULL, default 'rules-1' |
| created_at | INTEGER | NOT NULL |

Foreign keys: moment_id → detected_moments.id (on delete cascade)

Indexes: `idx_scores_moment`

## notifications

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| user_id | TEXT | NOT NULL |
| kind | TEXT | NOT NULL |
| title | TEXT | NOT NULL |
| body | TEXT |  |
| link | TEXT |  |
| read | INTEGER | NOT NULL, default 0 |
| created_at | INTEGER | NOT NULL |

Foreign keys: user_id → users.id (on delete cascade)

Indexes: `idx_notif_user`

## oauth_states

| Column | Type | Constraints |
|---|---|---|
| state | TEXT | PK |
| user_id | TEXT | NOT NULL |
| platform | TEXT | NOT NULL |
| code_verifier | TEXT |  |
| expires_at | INTEGER | NOT NULL |

Foreign keys: user_id → users.id (on delete cascade)

## oauth_tokens

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| account_id | TEXT | NOT NULL |
| access_token_enc | TEXT | NOT NULL |
| refresh_token_enc | TEXT |  |
| expires_at | INTEGER |  |
| token_type | TEXT |  |
| updated_at | INTEGER | NOT NULL |

Foreign keys: account_id → social_accounts.id (on delete cascade)

## processing_jobs

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| project_id | TEXT | NOT NULL |
| source_id | TEXT | NOT NULL |
| user_id | TEXT | NOT NULL |
| kind | TEXT | NOT NULL, default 'analyze' |
| status | TEXT | NOT NULL, default 'queued' |
| progress | REAL | NOT NULL, default 0 |
| step | TEXT |  |
| engine_job_id | TEXT |  |
| config | TEXT | NOT NULL, default '{}' |
| attempts | INTEGER | NOT NULL, default 0 |
| error | TEXT |  |
| last_synced_at | INTEGER |  |
| created_at | INTEGER | NOT NULL |
| updated_at | INTEGER | NOT NULL |
| finished_at | INTEGER |  |

Foreign keys: user_id → users.id (on delete cascade); source_id → source_media.id (on delete cascade); project_id → projects.id (on delete cascade)

Indexes: `idx_jobs_user`, `idx_jobs_status`

## projects

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| user_id | TEXT | NOT NULL |
| name | TEXT | NOT NULL |
| status | TEXT | NOT NULL, default 'draft' |
| category | TEXT |  |
| created_at | INTEGER | NOT NULL |
| updated_at | INTEGER | NOT NULL |

Foreign keys: user_id → users.id (on delete cascade)

Indexes: `idx_projects_user`

## published_posts

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| publishing_job_id | TEXT | NOT NULL |
| user_id | TEXT | NOT NULL |
| clip_id | TEXT | NOT NULL |
| platform | TEXT | NOT NULL |
| external_id | TEXT | NOT NULL |
| url | TEXT |  |
| platform_status | TEXT |  |
| verified_at | INTEGER | NOT NULL |
| published_at | INTEGER | NOT NULL |
| predicted_score | REAL |  |
| duration_s | REAL |  |
| moment_type | TEXT |  |
| title | TEXT |  |
| hook_text | TEXT |  |

Foreign keys: clip_id → generated_clips.id (on delete cascade); user_id → users.id (on delete cascade); publishing_job_id → publishing_jobs.id (on delete cascade)

Indexes: `idx_posts_user`

## publishing_jobs

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| user_id | TEXT | NOT NULL |
| clip_id | TEXT | NOT NULL |
| metadata_id | TEXT | NOT NULL |
| account_id | TEXT | NOT NULL |
| platform | TEXT | NOT NULL |
| status | TEXT | NOT NULL, default 'pending_approval' |
| approved_at | INTEGER |  |
| run_at | INTEGER |  |
| timezone | TEXT | NOT NULL, default 'Asia/Kolkata' |
| attempts | INTEGER | NOT NULL, default 0 |
| max_attempts | INTEGER | NOT NULL, default 3 |
| next_attempt_at | INTEGER |  |
| lease_expires_at | INTEGER |  |
| stage | TEXT |  |
| external_ref | TEXT |  |
| progress | REAL | NOT NULL, default 0 |
| error | TEXT |  |
| snapshot | TEXT |  |
| created_at | INTEGER | NOT NULL |
| updated_at | INTEGER | NOT NULL |

Foreign keys: account_id → social_accounts.id (on delete cascade); metadata_id → clip_metadata.id (on delete cascade); clip_id → generated_clips.id (on delete cascade); user_id → users.id (on delete cascade)

Indexes: `idx_pubjobs_due`, `idx_pubjobs_user`, `idx_pubjobs_unique_active`

## publishing_logs

| Column | Type | Constraints |
|---|---|---|
| id | INTEGER | PK |
| publishing_job_id | TEXT | NOT NULL |
| ts | INTEGER | NOT NULL |
| level | TEXT | NOT NULL, default 'info' |
| message | TEXT | NOT NULL |
| http_status | INTEGER |  |

Foreign keys: publishing_job_id → publishing_jobs.id (on delete cascade)

Indexes: `idx_publogs_job`

## publishing_schedules

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| user_id | TEXT | NOT NULL |
| platform | TEXT | NOT NULL |
| kind | TEXT | NOT NULL |
| times | TEXT | NOT NULL |
| weekdays | TEXT |  |
| timezone | TEXT | NOT NULL, default 'Asia/Kolkata' |
| active | INTEGER | NOT NULL, default 1 |
| created_at | INTEGER | NOT NULL |

Foreign keys: user_id → users.id (on delete cascade)

## rate_limits

| Column | Type | Constraints |
|---|---|---|
| key | TEXT | PK, NOT NULL |
| window_start | INTEGER | PK, NOT NULL |
| count | INTEGER | NOT NULL |

## sessions

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| user_id | TEXT | NOT NULL |
| csrf_token | TEXT | NOT NULL |
| user_agent | TEXT |  |
| created_at | INTEGER | NOT NULL |
| expires_at | INTEGER | NOT NULL |
| last_seen_at | INTEGER | NOT NULL |

Foreign keys: user_id → users.id (on delete cascade)

Indexes: `idx_sessions_user`, `idx_sessions_expires`

## social_accounts

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| user_id | TEXT | NOT NULL |
| platform | TEXT | NOT NULL |
| external_id | TEXT |  |
| display_name | TEXT |  |
| handle | TEXT |  |
| avatar_url | TEXT |  |
| status | TEXT | NOT NULL, default 'connected' |
| scopes | TEXT |  |
| extra | TEXT |  |
| last_error | TEXT |  |
| connected_at | INTEGER | NOT NULL |
| updated_at | INTEGER | NOT NULL |

Foreign keys: user_id → users.id (on delete cascade)

## source_media

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| project_id | TEXT | NOT NULL |
| user_id | TEXT | NOT NULL |
| adapter | TEXT | NOT NULL |
| state | TEXT | NOT NULL, default 'submitted' |
| source_url | TEXT |  |
| r2_key | TEXT |  |
| original_filename | TEXT |  |
| fingerprint | TEXT |  |
| size_bytes | INTEGER |  |
| duration_s | REAL |  |
| width | INTEGER |  |
| height | INTEGER |  |
| fps | REAL |  |
| has_audio | INTEGER |  |
| mime_type | TEXT |  |
| message | TEXT |  |
| missing_config | TEXT |  |
| created_at | INTEGER | NOT NULL |
| updated_at | INTEGER | NOT NULL |

Foreign keys: user_id → users.id (on delete cascade); project_id → projects.id (on delete cascade)

Indexes: `idx_source_project`, `idx_source_dupe`

## transcripts

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| source_id | TEXT | NOT NULL |
| job_id | TEXT |  |
| language | TEXT | NOT NULL, default 'en' |
| segments | TEXT | NOT NULL |
| full_text | TEXT |  |
| created_at | INTEGER | NOT NULL |

Foreign keys: job_id → processing_jobs.id (on delete set null); source_id → source_media.id (on delete cascade)

Indexes: `idx_transcripts_source`

## user_settings

| Column | Type | Constraints |
|---|---|---|
| user_id | TEXT | PK |
| timezone | TEXT | NOT NULL, default 'Asia/Kolkata' |
| currency | TEXT | NOT NULL, default 'INR' |
| language | TEXT | NOT NULL, default 'en' |
| default_resolution | TEXT | NOT NULL, default '1080p' |
| subtitle_style | TEXT | NOT NULL, default '{}' |
| default_privacy | TEXT | NOT NULL, default 'private' |
| queue_paused | INTEGER | NOT NULL, default 0 |
| retention_days | INTEGER | NOT NULL, default 30 |
| storage_quota_mb | INTEGER | NOT NULL, default 9000 |
| notifications | TEXT | NOT NULL, default '{}' |
| prompt_templates | TEXT | NOT NULL, default '{}' |
| updated_at | INTEGER | NOT NULL |

Foreign keys: user_id → users.id (on delete cascade)

## users

| Column | Type | Constraints |
|---|---|---|
| id | TEXT | PK |
| email | TEXT | NOT NULL |
| display_name | TEXT | NOT NULL, default 'Owner' |
| password_hash | TEXT | NOT NULL |
| role | TEXT | NOT NULL, default 'owner' |
| created_at | INTEGER | NOT NULL |
| updated_at | INTEGER | NOT NULL |

