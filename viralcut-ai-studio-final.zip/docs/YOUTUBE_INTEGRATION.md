# YouTube integration

Status in this build: **implemented, mock-tested, NOT verified against the live API.**

Flow: Google OAuth 2.0 (authorization code + PKCE, offline access) → `channels.list` (identity) → `videos.insert` resumable upload (`snippet`, `status`) → `videos.list` verification → `videos.list` statistics + YouTube Analytics API reports.

## Setup checklist
1. https://console.cloud.google.com → create a project.
2. *APIs & Services → Library*: enable **YouTube Data API v3** and **YouTube Analytics API**.
3. *OAuth consent screen*: User type External; add your Google account under **Test users** while the app is in "Testing" (refresh tokens for apps in Testing expire after 7 days — publish the app or reconnect weekly).
4. *Credentials → Create credentials → OAuth client ID → Web application*. **Authorized redirect URI**: `https://<APP_URL>/api/social/youtube/callback` (shown on the Social Accounts card; must match exactly).
5. Set secrets: `npx wrangler secret put GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`, redeploy if needed.
6. Social Accounts → YouTube → **Connect**.

Scopes requested: `youtube.upload`, `youtube.readonly`, `yt-analytics.readonly` (no broader write scope).

## Important limits (verify in Google's documentation)
- **API audit:** videos uploaded by API projects that have not passed Google's compliance audit may be restricted to **private**. The app always shows the privacy you chose, and the platform's returned status (`privacy=…`) is recorded.
- **Quota:** the Data API has a daily quota (default 10,000 units); `videos.insert` is expensive (about 1,600 units at the time of writing), so only a handful of uploads fit per day. Duplicate protection costs 1–2 units.
- Shorts: vertical video ≤ 3 minutes; the description includes `#Shorts`.
- Analytics: `shares`, `reach` and `impressions` are not available via the Data API and are shown as n/a; retention-style metrics come from the Analytics API and may lag.

## Live verification checklist
Connect → upload a 20 s clip as **private** → check it appears in YouTube Studio, the job shows `published` with the video id, then run analytics collection.
