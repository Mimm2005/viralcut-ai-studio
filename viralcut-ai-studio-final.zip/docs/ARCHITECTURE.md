# Architecture

```
Browser ──HTTPS──► Cloudflare Worker (API + static frontend)
                     │  D1 (state)   S3-compatible storage / R2 (media)   Cron every 1 / 5 min
                     │
                     ├──► Processing engine (FastAPI, Docker; HF Space / own server)
                     │        FFmpeg · Faster-Whisper · OpenCV · PySceneDetect
                     │        pulls source from R2 via short-lived presigned GET,
                     │        pushes renders to R2 via presigned PUT
                     ├──► AI providers (Gemini / OpenAI / Anthropic / OpenAI-compatible)
                     └──► Platform APIs (YouTube, Meta Graph, TikTok, X)
```

## Responsibilities

**Worker** (never renders video or transcribes): auth/sessions/CSRF, validation, D1, signed media URLs, job orchestration, the AI gateway + Cost Guard, OAuth, the publishing state machine, analytics collection. **Engine**: everything CPU-heavy. They communicate only over HTTPS with a bearer token; the engine never holds user data beyond a job's working directory (deleted after success).

## Durability (free infrastructure sleeps)

- **Engine job store** (SQLite): leases, heartbeats, exponential-backoff retries, cancellation, idempotent job ids, per-chunk **transcription checkpoints**. A job whose lease expires (Space slept/crashed) is re-queued and resumes after the last completed chunk. Disk-space guard before each job.
- **Worker scheduler** (Cron Triggers, state in D1): every minute `engine sync` + `publish due`; every 5 minutes analytics + housekeeping. Jobs are claimed atomically (`UPDATE … WHERE` + `changes==1`) with a 5-minute lease, so overlapping runs never double-publish.
- **Publishing is a resumable state machine.** Each adapter performs one idempotent *step* per invocation and persists `stage` + `external_ref` **before** the next call. Retries resume at the same stage (no re-upload). Ambiguous situations (interrupted between "publish call sent" and "id saved") end in `needs_verification` for a human, never a blind retry. YouTube additionally checks the channel's recent uploads before re-uploading after a failure.
- If the engine is asleep/unreachable, analysis and render jobs stay `queued` in D1 and the cron submits them when it answers.

## Scoring (engine/app/scoring.py, moments.py)

Weights: hook 20, emotion 20, entertainment 20, unexpectedness 15, shareability 15, storytelling 10 (sum 100). Each factor is computed from measured features (energy z-scores against the video's own baseline, a *heuristic* laughter proxy, surprise/humour/emotion lexicons, motion energy, scene cuts, sentence boundaries, energy arc). Output: total, six factors, confidence (rises with available evidence), deterministic explanation citing the evidence, suggested start/end/duration. Candidates are windows anchored on transcript boundaries, ends snapped to sentence ends, ranked after greedy non-max suppression (overlap ≤ 30 %).

Limits you should know: lexicons are English-centric; laughter detection is a heuristic, not a trained model; "smart crop" uses Haar faces then motion centroid (no object/character detection); visual understanding is signal-level, not semantic.

## Security model

HttpOnly/Secure/SameSite=Lax session cookie (only a SHA-256 of the token is stored) · CSRF double-submit header + Origin allow-list · PBKDF2-SHA256 password hashes · login/setup/upload/AI rate limits in D1 · single-owner setup gated by `SETUP_TOKEN` (no public registration) · object-level authorisation on every lookup (404 for foreign ids) · AES-GCM with row-bound AAD for provider keys and OAuth tokens · OAuth `state` (one-time, 10 min) + PKCE where supported · custom AI endpoints must be public https (SSRF guard) · upload type/size/quota checks · HMAC-signed, expiring media URLs · secrets redacted from logs · audit log.

## Extending

New media source: implement `validate/authorize/fetch` in `engine/app/sources/` and register it (the pipeline does not change). New social platform: add a module in `worker/src/lib/social/` exporting `authUrl, exchangeCode, refresh, step, metrics` and register it in `index.js`. New AI provider: add a function in `worker/src/lib/ai/providers.js`.
