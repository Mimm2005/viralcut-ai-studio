# Environment variables

Secrets are set with `npx wrangler secret put NAME` (never in `wrangler.toml`, never in git). Plain variables live in `worker/wrangler.toml`.

## Worker
| Name | Type | Required | Purpose |
|---|---|---|---|
| `ENCRYPTION_KEY` | secret | yes | 32 random bytes, base64. Encrypts provider keys and OAuth tokens. Losing it makes them unreadable. |
| `SETUP_TOKEN` | secret | yes (first run) | Authorises creation of the single owner account. |
| `ENGINE_URL` | secret | for processing | Base URL of the engine, no trailing slash. |
| `ENGINE_TOKEN` | secret | for processing | Bearer token shared with the engine. |
| `S3_ENDPOINT`, `S3_REGION`, `S3_BUCKET` | var | yes (S3 mode) | S3-compatible storage location (e.g. Backblaze B2). |
| `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY` | secret | yes (S3 mode) | Bucket-scoped application key. |
| `UPLOAD_MODE` | var | no | `proxy` = uploads go through the Worker (≤ 95 MB, no CORS needed). Omit for direct browser uploads (needs bucket CORS). |
| `R2_*`, `R2_BUCKET_NAME` + `MEDIA` binding | secret/var | only if using Cloudflare R2 | See `worker/wrangler.r2.toml.example`. |
| `APP_URL` | var | yes | Public URL of the Worker; OAuth redirect URIs are `APP_URL/api/social/<platform>/callback`. |
| `FRONTEND_ORIGIN` | var | yes | Allowed origin (same as `APP_URL` when served by the Worker). |
| `MEDIA_SIGNING_KEY` | secret | no | HMAC key for signed media URLs; defaults to `ENCRYPTION_KEY`. |
| `MAX_UPLOAD_MB` | var | no | Upload limit, default 1024. |
| `PBKDF2_ITERATIONS` | var | no | Default 100000; lower only if login exceeds the free-plan CPU limit. |
| `GOOGLE_CLIENT_ID/SECRET` | secret | YouTube | See YOUTUBE_INTEGRATION.md |
| `META_APP_ID/SECRET`, `META_GRAPH_VERSION` | secret/var | Instagram, Facebook | See META_INTEGRATION.md |
| `TIKTOK_CLIENT_KEY/SECRET` | secret | TikTok | See TIKTOK_INTEGRATION.md |
| `X_CLIENT_ID/SECRET` | secret | X | See X_INTEGRATION.md |

AI provider API keys are **not** environment variables: add them in the UI (stored encrypted in D1).

## Engine
| Name | Default | Purpose |
|---|---|---|
| `ENGINE_TOKEN` | — (required) | Bearer token; requests are refused (503) if unset. |
| `VC_DATA_DIR` | `/tmp/viralcut` | Job database and temporary work files. |
| `WHISPER_MODEL` | `tiny` | `tiny`, `base`, `small`… larger = slower on CPU. |
| `WHISPER_COMPUTE` | `int8` | CTranslate2 compute type. |
| `MAX_UPLOAD_MB` | 1024 | Max source size. |
| `CHUNK_SECONDS` | 300 | Transcription chunk length (also the checkpoint granularity). |
| `FRAME_SAMPLE_FPS` | 1.0 | Visual analysis sampling rate. |
| `JOB_LEASE_SECONDS` / `JOB_MAX_ATTEMPTS` | 120 / 3 | Lease and retry limits. |
| `MIN_FREE_DISK_MB` | 500 | Jobs wait/retry when free disk is below this. |
