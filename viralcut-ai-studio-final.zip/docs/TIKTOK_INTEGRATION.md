# TikTok integration

Status: **adapter implemented and mock-tested; NOT verified live; requires TikTok approval.**

1. https://developers.tiktok.com → Manage apps → create an app; add products **Login Kit** and **Content Posting API**.
2. Redirect URI: `https://<APP_URL>/api/social/tiktok/callback`.
3. Scopes requested: `user.info.basic`, `video.publish`, `video.upload`, `video.list`.
4. Secrets: `TIKTOK_CLIENT_KEY`, `TIKTOK_CLIENT_SECRET`.
5. Connect from Social Accounts.

## Reality check
- **Unaudited apps can only post privately (`SELF_ONLY`).** The adapter queries `creator_info` first and uses only a privacy level the account is allowed; a requested `PUBLIC_TO_EVERYONE` is downgraded and logged, never forced.
- Direct Post vs Upload-to-Draft availability depends on your app's approval; this build uses **Direct Post with FILE_UPLOAD** (chunked PUT with `Content-Range`).
- Success is reported only when the status endpoint returns `PUBLISH_COMPLETE`. If TikTok does not return a public post id (private/under review), the platform status says so and the stored id is the publish id.
- Analytics (`video.list` → views, likes, comments, shares) work only for videos with a public id; reach/impressions are n/a.
- Audit/approval can take time and may be refused; until then the card remains usable only for private test posts.
