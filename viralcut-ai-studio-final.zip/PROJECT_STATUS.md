# PROJECT_STATUS

Last updated: 2026-11-21. Version 1.0.0 (pre-release: **not production-ready until live checks are done**).

## Phases
| Phase | Scope | Status |
|---|---|---|
| 1 Foundation | structure, shell, nav, auth, dashboard, D1 schema, Cloudflare config | ✅ implemented, tested |
| 2 Video import | source adapters, upload, validation, job creation | ✅ upload; ✅ adapter architecture; ⚠️ YouTube/Drive download not implemented (honest pending states) |
| 3 Processing | FFmpeg, audio, Faster-Whisper, scenes, transcripts | ✅ implemented; ⚠️ real Whisper untested in build env |
| 4 Intelligence | candidates, scoring, explanations, ranking, results UI | ✅ implemented, tested |
| 5 Editing | trim, smart/center/manual crop, subtitles, vertical render, batch | ✅ implemented, tested (no live preview/timeline) |
| 6 AI metadata | gateway, Gemini/OpenAI/Claude/custom, templates, Cost Guard | ✅ implemented, mock-tested |
| 7 Social | YouTube, Instagram, Facebook, TikTok, X OAuth + publishing adapters | ✅ implemented; ⚠️ **live-unverified** (mocks only) |
| 8 Automation | approval, persistent scheduler, retries, history, notifications | ✅ implemented, tested incl. crash/resume |
| 9 Analytics & delivery | analytics, feedback loop, security tests, docs, ZIP | ✅ implemented; ⚠️ live analytics unverified |

## Tests
117 passing (engine 55, worker 48, frontend 14). Details and the list of what is *not* verified: `docs/TESTING_REPORT.md`.

## Changelog
- Storage is now backend-agnostic: any S3-compatible bucket (Backblaze B2 etc.) or Cloudflare R2. Default config uses S3 mode so no card-gated service is required. Mock-tested only against a fake S3 API; **live B2 unverified**.

## Known issues / risks
- Live API behaviour of all five platforms is unverified; first real run = integration testing.
- Docker image, Hugging Face deploy, wrangler config, D1/R2 behaviour unverified (simulated).
- Worker free-plan limits (CPU, subrequests, streaming large uploads) may require tuning; see `docs/FREE_TIER_LIMITATIONS.md`.
- Free HF Space sleeps and loses local disk on rebuild.

## Next tasks (suggested order)
1. Deploy per `docs/DEPLOYMENT.md`; run the live verification checklist.
2. Verify YouTube end-to-end (private upload), then Instagram/Facebook, then TikTok (needs audit) and X (paid).
3. Measure real Whisper timing; pick model size.
4. Add: YouTube/Drive download via an owner-controlled provider, timeline scrubber + live crop preview, trained audio-event model, i18n, multi-account.

## Resuming development
Open this file, run `./scripts/run-tests.sh` (all must pass), pick the first unchecked item above. API/schema docs regenerate with `node --experimental-sqlite --no-warnings scripts/gen-docs.mjs`.
